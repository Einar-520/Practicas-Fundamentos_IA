# Prácticas reorganizadas para VS Code con WSL

La carpeta activa contiene siete programas independientes, numerados del 1 al 7. Se revisó el contenido de todos los archivos Python del ZIP, incluidos los respaldos. El paquete incluye los materiales de la unidad y una copia íntegra del ZIP recibido.

## Aplicar la reorganización a tu proyecto

1. Descarga la versión corregida de `practicas_revision.zip`.
2. En la terminal WSL de VS Code, abre la carpeta de tu proyecto:

```bash
cd ~/universidad/fundamentos-ia
explorer.exe .
```

3. Copia el ZIP descargado a esa carpeta con el nombre `practicas_revision.zip`.
4. En la misma terminal, ejecuta:

```bash
revision_temporal="$(mktemp -d)" &&
python3 -m zipfile -e practicas_revision.zip "$revision_temporal" &&
python3 "$revision_temporal/instalar_en_wsl.py" .
```

Los archivos se extraen en una carpeta temporal; el instalador valida el paquete y prepara la nueva carpeta antes de sustituir la carpeta activa. Se necesita Python 3.9 o superior. No hay dependencias externas.

El instalador mueve las carpetas actuales `practicas` y `practicas_respaldo` a un respaldo nuevo fuera del proyecto. Para tu estructura, la ubicación será:

`~/universidad/fundamentos-ia-respaldos/practicas-FECHA-HORA-identificador/`

La ruta exacta se imprime al terminar. Este respaldo conserva el estado de tus archivos al instalar, incluidos cambios que hayas hecho después de enviar el ZIP. Si falla un traslado, el instalador restaura las ubicaciones originales. Repetir la instalación cuando ya está aplicada la misma versión no crea otra copia.

Los apuntes, las tareas, los ejercicios, los proyectos y los demás archivos del proyecto permanecen en sus ubicaciones. El instalador solo reorganiza las carpetas de prácticas; el ZIP también incluye una copia de los materiales de la unidad para disponer del conjunto completo.

## Orden final

| N.º | Carpeta | Programa |
| --- | --- | --- |
| 1 | practica-01-tablas-de-verdad | 01_tablas_de_verdad.py |
| 2 | practica-02-sistema-examen | 02_sistema_examen.py |
| 3 | practica-03-sistema-examen-lista-oficial | 03_sistema_examen_lista_oficial.py |
| 4 | practica-04-diagnostico-equipo | 04_diagnostico_equipo.py |
| 5 | practica-05-diagnostico-equipo-reporte | 05_diagnostico_equipo_reporte.py |
| 6 | practica-06-sistema-experto-salud | 06_sistema_experto_salud.py |
| 7 | practica-07-sistema-experto-salud-mejorado | 07_sistema_experto_salud_mejorado.py |

Las siete carpetas están dentro de `unidad-01-introduccion-ia/practicas`. Allí también hay un README con los enlaces a cada programa.

## Qué estaba desordenado y cómo se resolvió

- El archivo llamado `04_diagnostico_equipo.py` contenía las tablas de verdad. Su código pasó a la práctica 1 sin cambios.
- La práctica 2 ya contenía el examen optimizado. Se conservó su código y se ajustó el nombre de la carpeta y del archivo.
- El examen con lista oficial aparecía en respaldos con el número 2. La práctica 3 usa la versión optimizada ya entregada y conserva la misma regla de autorización. Las demostraciones adicionales de operadores de aquella versión permanecen en el respaldo original.
- El diagnóstico básico real se recuperó del código optimizado ya preparado y ocupa la práctica 4.
- El archivo ubicado como práctica 3 era un diagnóstico extenso con reporte, datos técnicos y daños físicos. Se conservó esa versión como base de la práctica 5, se corrigieron sus errores y se reorganizó su código.
- Los archivos activos de las prácticas 5, 6 y 7 estaban vacíos. Se completó la 5 con el reporte recuperado y las prácticas 6 y 7 con sus códigos optimizados.
- Se identificaron tres grupos de copias exactas no vacías: el examen introductorio, el reporte extenso y el examen con lista oficial. Los respaldos anidados quedan fuera de la carpeta activa.
- La versión introductoria del examen que figuraba como práctica 1 permanece en el respaldo. La tarea de tablas de verdad se conserva en `tareas` junto a su enunciado.

## Correcciones de la práctica 5

El código extenso se detenía por dos textos usados antes de ser definidos, una llamada accidental a una función inexistente y dos implicaciones lógicas omitidas. Se repararon esas referencias y se separaron la captura de datos, la evaluación y la generación del reporte.

Se conservaron los datos de usuario, modelo, tipo, antigüedad, RAM, almacenamiento, disco, procesador, sistema operativo, garantía y mantenimiento. También se conservaron las catorce respuestas de funcionamiento y daño físico, las observaciones y las reglas del diagnóstico.

La consistencia sigue la intención expresada en el archivo: `Q → P`, `R → Q` y `S → (Q ∧ R)`. Se restauraron las definiciones faltantes de las dos primeras implicaciones. La prioridad del diagnóstico es: respuestas contradictorias, electricidad, encendido, imagen e inicio del sistema operativo. El estado general también considera los síntomas adicionales, Internet, USB, audio y daños físicos.

Se agregaron fecha y hora al folio aleatorio, de acuerdo con el objetivo de la práctica 5 que habíamos establecido. El reporte se muestra en consola. Se validan respuestas de sí/no, campos vacíos, opciones y números finitos. Los rangos numéricos no definidos por la práctica siguen sin recibir límites nuevos.

## Verificación

- Se comprobaron 16,384 combinaciones de las catorce respuestas del reporte. Se compararon el diagnóstico, la consistencia, el daño físico, el estado general y las observaciones con el código recibido después de aplicar únicamente las reparaciones mínimas necesarias para ejecutarlo.
- Se comprobaron 64 combinaciones de las proposiciones del examen con lista oficial frente a la versión hallada en el respaldo.
- Se ejecutaron los siete programas por separado y se comprobaron las entradas inválidas y la cancelación de la captura.
- Se probó la instalación, la conservación exacta de las carpetas anteriores, los materiales ajenos a las prácticas, la segunda ejecución y la restauración ante fallos e interrupciones.
- Se comprobó que un paquete cuyo contenido fue alterado se rechaza antes de sustituir las carpetas.

`informe_reorganizacion.json` contiene la procedencia de los programas y los resultados de las verificaciones. `respaldo_unidad_original.zip` es una copia exacta del ZIP recibido. `manifiesto_practicas.json` permite al instalador verificar que los archivos están completos.

## Ejecutar una práctica

Desde `~/universidad/fundamentos-ia`, por ejemplo:

```bash
python3 unidad-01-introduccion-ia/practicas/practica-01-tablas-de-verdad/01_tablas_de_verdad.py
```

Para ejecutar otra práctica, cambia la carpeta y el nombre del archivo conforme a la tabla.
