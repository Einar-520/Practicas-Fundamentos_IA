# Práctica 5: Diagnóstico con reporte

Captura los datos del equipo y genera un reporte con folio, fecha, diagnóstico y observaciones.

Desde la raíz del proyecto:

```bash
bash unidad-01-introduccion-ia/practicas/practica-05-diagnostico-equipo-reporte/ejecutar.sh
```

Abre http://localhost:5105. Detén el servidor con Ctrl+C.

Programa independiente: todo el código, HTML, CSS y JavaScript está en esta carpeta.
Las funciones de las reglas se conservan del programa optimizado. Los campos
se validan en Python. Los resultados no se guardan en una base de datos.

Flask devuelve JSON; JavaScript muestra texto sin interpretarlo como HTML.
La práctica 5 permite descargar su reporte en TXT.
