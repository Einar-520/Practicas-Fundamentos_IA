# Práctica 7: Sistema experto de salud mejorado

Esta práctica académica evalúa siete síntomas y explica la regla activada. No sustituye una valoración médica.

Desde la raíz del proyecto:

```bash
bash unidad-01-introduccion-ia/practicas/practica-07-sistema-experto-salud-mejorado/ejecutar.sh
```

Abre http://localhost:5107. Detén el servidor con Ctrl+C.

Programa independiente: todo el código, HTML, CSS y JavaScript está en esta carpeta.
Las funciones de las reglas se conservan del programa optimizado. Los campos
se validan en Python. Los resultados no se guardan en una base de datos.

Flask devuelve JSON; JavaScript muestra texto sin interpretarlo como HTML.
La práctica 5 permite descargar su reporte en TXT.
