"""Instalar las siete prácticas y conservar las carpetas anteriores como respaldo."""

import argparse
import hashlib
import json
import shutil
import sys
import tempfile
from datetime import datetime
from pathlib import Path

UNIDAD = "unidad-01-introduccion-ia"
CARPETAS = (
    "practica-01-tablas-de-verdad",
    "practica-02-sistema-examen",
    "practica-03-sistema-examen-lista-oficial",
    "practica-04-diagnostico-equipo",
    "practica-05-diagnostico-equipo-reporte",
    "practica-06-sistema-experto-salud",
    "practica-07-sistema-experto-salud-mejorado",
)


def inventario(carpeta: Path) -> tuple[dict[str, str], set[str]]:
    """Comparar contenido y estructura; omitir únicamente la caché de Python."""
    archivos = {}
    directorios = set()
    for ruta in carpeta.rglob("*"):
        relativo = ruta.relative_to(carpeta)
        if "__pycache__" in relativo.parts:
            continue
        if ruta.is_symlink():
            raise ValueError(f"Se encontró un enlace simbólico que requiere revisión: {ruta}")
        if ruta.is_dir():
            directorios.add(relativo.as_posix())
        elif ruta.is_file():
            archivos[relativo.as_posix()] = hashlib.sha256(ruta.read_bytes()).hexdigest()
        else:
            raise ValueError(f"Se encontró una entrada que no es un archivo normal: {ruta}")
    return archivos, directorios


def validar_paquete(paquete: Path) -> tuple[Path, tuple[dict[str, str], set[str]]]:
    fuente = paquete / UNIDAD / "practicas"
    manifiesto = json.loads((paquete / "manifiesto_practicas.json").read_text(encoding="utf-8"))
    if not fuente.is_dir() or fuente.is_symlink():
        raise ValueError("El paquete no contiene la carpeta de prácticas esperada.")
    contenido = inventario(fuente)
    if contenido[0] != manifiesto["archivos"]:
        raise ValueError("El paquete está incompleto o se modificó después de su verificación.")
    if contenido[1] != set(CARPETAS):
        raise ValueError("La estructura del paquete no contiene exactamente las siete prácticas.")
    programas = sorted(fuente.rglob("*.py"))
    if len(programas) != 7:
        raise ValueError("El paquete debe contener siete programas de Python.")
    for numero, programa in enumerate(programas, 1):
        if not programa.name.startswith(f"{numero:02d}_"):
            raise ValueError(f"La numeración no coincide: {programa}")
        compile(programa.read_text(encoding="utf-8"), str(programa), "exec")
    return fuente, contenido


def instalar(proyecto: Path, paquete: Path, comprobar: bool = False) -> None:
    fuente, esperado = validar_paquete(paquete)
    proyecto = proyecto.expanduser().resolve()
    unidad = proyecto / UNIDAD
    if not unidad.is_dir() or unidad.is_symlink():
        raise ValueError(f"No se encontró una carpeta de unidad válida en: {unidad}")
    if paquete.resolve() == proyecto or paquete.resolve().is_relative_to(unidad):
        raise ValueError("Extrae el paquete en una carpeta temporal fuera del proyecto.")

    destino = unidad / "practicas"
    respaldo_anterior = unidad / "practicas_respaldo"
    for carpeta in (destino, respaldo_anterior):
        if carpeta.is_symlink() or (carpeta.exists() and not carpeta.is_dir()):
            raise ValueError(f"Se esperaba una carpeta normal en: {carpeta}")
    if destino.is_dir() and inventario(destino) == esperado and not respaldo_anterior.exists():
        print("Las siete prácticas ya están organizadas con esta versión.")
        return
    if comprobar:
        print("El paquete y el destino son válidos.")
        print("Se instalarán las siete prácticas en:", destino)
        print("Las carpetas actuales se conservarán en un respaldo fuera del proyecto.")
        return

    raiz_respaldos = proyecto.parent / f"{proyecto.name}-respaldos"
    if raiz_respaldos.is_symlink():
        raise ValueError(f"La ubicación de respaldos es un enlace simbólico: {raiz_respaldos}")
    raiz_respaldos.mkdir(exist_ok=True)
    respaldo = None

    # Preparar la copia completa antes de mover cualquier carpeta del usuario.
    with tempfile.TemporaryDirectory(prefix=".practicas-preparadas-", dir=unidad) as temporal:
        preparada = Path(temporal) / "practicas"
        shutil.copytree(fuente, preparada, ignore=shutil.ignore_patterns("__pycache__"))
        if inventario(preparada) != esperado:
            raise ValueError("No se pudo verificar la copia preparada para la instalación.")

        prefijo = f"practicas-{datetime.now():%Y%m%d-%H%M%S}-"
        respaldo = Path(tempfile.mkdtemp(prefix=prefijo, dir=raiz_respaldos))
        movidas = []
        try:
            for carpeta in (destino, respaldo_anterior):
                if carpeta.exists():
                    guardada = respaldo / carpeta.name
                    carpeta.rename(guardada)
                    movidas.append((guardada, carpeta))
            preparada.rename(destino)
        except BaseException:
            # Restaurar las carpetas originales si falla un traslado.
            if destino.is_dir() and not preparada.exists():
                destino.rename(preparada)
            for guardada, original in reversed(movidas):
                guardada.rename(original)
            if not any(respaldo.iterdir()):
                respaldo.rmdir()
            raise

    print("Las siete prácticas quedaron organizadas en:", destino)
    print("Respaldo de las carpetas anteriores:", respaldo)
    print("Para ejecutar la primera práctica desde la raíz del proyecto:")
    print(f"python3 {UNIDAD}/practicas/{CARPETAS[0]}/01_tablas_de_verdad.py")


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Organizar las siete prácticas conservando las carpetas anteriores."
    )
    parser.add_argument("proyecto", nargs="?", default=".", help="Raíz del proyecto fundamentos-ia.")
    parser.add_argument("--comprobar", action="store_true", help="Revisar el paquete y el destino sin instalar.")
    argumentos = parser.parse_args()
    try:
        instalar(Path(argumentos.proyecto), Path(__file__).resolve().parent, argumentos.comprobar)
    except (OSError, ValueError, KeyError, SyntaxError) as error:
        print(f"No se completó la instalación: {error}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nInstalación interrumpida.", file=sys.stderr)
        return 130
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
