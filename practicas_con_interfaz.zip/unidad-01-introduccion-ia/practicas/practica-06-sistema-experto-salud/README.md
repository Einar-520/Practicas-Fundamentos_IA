# Práctica 6: Sistema experto de salud

Ejercicio académico de tres síntomas. El resultado es orientativo y no sustituye una valoración médica.

Desde la raíz del proyecto:

```bash
bash unidad-01-introduccion-ia/practicas/practica-06-sistema-experto-salud/ejecutar.sh
```

Abre http://localhost:5106. Detén el servidor con Ctrl+C.

Programa independiente: todo el código, HTML, CSS y JavaScript está en esta carpeta.
Las funciones de las reglas se conservan del programa optimizado. Los campos
se validan en Python. Los resultados no se guardan en una base de datos.

Flask devuelve JSON; JavaScript muestra texto sin interpretarlo como HTML.
La práctica 5 permite descargar su reporte en TXT.
