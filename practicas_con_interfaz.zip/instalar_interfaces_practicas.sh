#!/usr/bin/env bash
# Instala interfaces independientes para las prácticas 1 a 9, con respaldo previo.
set -euo pipefail
proyecto="${1:-$HOME/universidad/fundamentos-ia}"
cd -- "$proyecto"
proyecto="$PWD"
practicas="$proyecto/unidad-01-introduccion-ia/practicas"
[[ -d "$practicas" ]] || { echo "No se encontró la carpeta de prácticas: $practicas"; exit 1; }
preparada="$(mktemp -d "$practicas/.interfaces-preparadas-XXXXXX")"
limpiar() {
  codigo=$?
  if [[ -d "$preparada" ]]; then rm -rf -- "$preparada"; fi
  exit "$codigo"
}
trap limpiar EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
mkdir -p -- "$preparada/practica-01-tablas-de-verdad/templates" "$preparada/practica-01-tablas-de-verdad/static"
mkdir -p -- "$preparada/practica-02-sistema-examen/templates" "$preparada/practica-02-sistema-examen/static"
mkdir -p -- "$preparada/practica-03-sistema-examen-lista-oficial/templates" "$preparada/practica-03-sistema-examen-lista-oficial/static"
mkdir -p -- "$preparada/practica-04-diagnostico-equipo/templates" "$preparada/practica-04-diagnostico-equipo/static"
mkdir -p -- "$preparada/practica-05-diagnostico-equipo-reporte/templates" "$preparada/practica-05-diagnostico-equipo-reporte/static"
mkdir -p -- "$preparada/practica-06-sistema-experto-salud/templates" "$preparada/practica-06-sistema-experto-salud/static"
mkdir -p -- "$preparada/practica-07-sistema-experto-salud-mejorado/templates" "$preparada/practica-07-sistema-experto-salud-mejorado/static"
mkdir -p -- "$preparada/practica-08-conexion-mongodb/templates" "$preparada/practica-08-conexion-mongodb/static"
mkdir -p -- "$preparada/practica-09-conexion-mongodb-atlas/templates" "$preparada/practica-09-conexion-mongodb-atlas/static"
cat > "$preparada/practica-01-tablas-de-verdad/01_tablas_de_verdad.py" <<'FIN_CODIGO_INTERFACES'
"""Práctica 1: interfaz independiente; reglas originales conservadas."""

from itertools import product

NUMERO = 1
PUERTO = 5101
TITULO = 'Tablas de verdad'
DESCRIPCION = 'Compara P, Q, negación, conjunción, disyunción, implicación y equivalencia.'
GRUPOS = []
BOTON = 'Mostrar tabla'


def evaluar(datos):
    filas = []
    for p, q in product((True, False), repeat=2):
        valores = (p, q, not p, p and q, p or q, (not p) or q, p == q)
        filas.append(["Verdadero" if v else "Falso" for v in valores])
    return {"titulo": "Las cuatro combinaciones de P y Q", "clase": "neutral",
            "mensajes": ["El orden es: VV, VF, FV y FF."],
            "tablas": [{"titulo": "Operaciones lógicas", "encabezados": ["P", "Q", "¬P", "P ∧ Q", "P ∨ Q", "P → Q", "P ↔ Q"], "filas": filas}]}


from pathlib import Path
import secrets
from math import isfinite
from flask import Flask, jsonify, render_template, request, session

def leer_formulario(formulario):
    datos = {}
    for grupo in GRUPOS:
        for campo in grupo["campos"]:
            clave = campo["clave"]
            valor = formulario.get(clave, "").strip()
            if not valor:
                raise ValueError(f"Completa el campo: {campo['etiqueta']}.")
            if campo["tipo"] == "booleano":
                if valor not in ("si", "no"):
                    raise ValueError(f"Selecciona Sí o No en: {campo['etiqueta']}.")
                datos[clave] = valor == "si"
            elif campo["tipo"] == "numero":
                try:
                    numero = float(valor)
                except ValueError:
                    raise ValueError(f"Ingresa un número válido en: {campo['etiqueta']}.") from None
                if not isfinite(numero):
                    raise ValueError(f"El número de {campo['etiqueta']} debe ser finito.")
                datos[clave] = numero
            elif campo["tipo"] == "opcion":
                if valor not in campo["opciones"]:
                    raise ValueError(f"Selecciona una opción válida en: {campo['etiqueta']}.")
                datos[clave] = valor
            else:
                datos[clave] = valor
    return datos

def crear_app():
    raiz = Path(__file__).resolve().parent
    app = Flask(__name__, template_folder=str(raiz / "templates"), static_folder=str(raiz / "static"))
    app.config.update(SECRET_KEY=secrets.token_hex(32), SESSION_COOKIE_HTTPONLY=True,
                      SESSION_COOKIE_SAMESITE="Strict", MAX_CONTENT_LENGTH=131072)

    @app.after_request
    def proteger(respuesta):
        respuesta.headers["Cache-Control"] = "no-store"
        respuesta.headers["X-Content-Type-Options"] = "nosniff"
        respuesta.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'"
        return respuesta

    @app.get("/")
    def inicio():
        session.setdefault("csrf", secrets.token_hex(32))
        return render_template("index.html", numero=NUMERO, titulo=TITULO, descripcion=DESCRIPCION, grupos=GRUPOS, boton=BOTON)

    @app.post("/evaluar")
    def procesar():
        token = request.form.get("csrf", "")
        if not token or not secrets.compare_digest(token.encode(), session.get("csrf", "").encode()):
            return jsonify(ok=False, mensaje="El formulario expiró. Recarga la página."), 400
        try:
            datos = leer_formulario(request.form)
        except ValueError as error:
            return jsonify(ok=False, mensaje=str(error)), 400
        return jsonify(ok=True, resultado=evaluar(datos))

    @app.errorhandler(413)
    def demasiado_grande(error):
        return jsonify(ok=False, mensaje="El formulario es demasiado grande. Reduce el texto e inténtalo de nuevo."), 413

    return app

if __name__ == "__main__":
    print(f"Abre http://localhost:{PUERTO} en tu navegador. Detén el servidor con Ctrl+C.")
    crear_app().run(host="127.0.0.1", port=PUERTO, debug=False)
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-01-tablas-de-verdad/README.md" <<'FIN_CODIGO_INTERFACES'
# Práctica 1: Tablas de verdad

Compara P, Q, negación, conjunción, disyunción, implicación y equivalencia.

Desde la raíz del proyecto:

```bash
bash unidad-01-introduccion-ia/practicas/practica-01-tablas-de-verdad/ejecutar.sh
```

Abre http://localhost:5101. Detén el servidor con Ctrl+C.

Programa independiente: todo el código, HTML, CSS y JavaScript está en esta carpeta.
Las funciones de las reglas se conservan del programa optimizado. Los campos
se validan en Python. Los resultados no se guardan en una base de datos.

Flask devuelve JSON; JavaScript muestra texto sin interpretarlo como HTML.
La práctica 5 permite descargar su reporte en TXT.
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-01-tablas-de-verdad/ejecutar.sh" <<'FIN_CODIGO_INTERFACES'
#!/usr/bin/env bash
set -euo pipefail
directorio="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
proyecto="$(cd -- "$directorio/../../.." && pwd)"
exec "$proyecto/.venv/bin/python" "$directorio/01_tablas_de_verdad.py"
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-01-tablas-de-verdad/requirements.txt" <<'FIN_CODIGO_INTERFACES'
Flask>=3.1,<4
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-01-tablas-de-verdad/static/app.js" <<'FIN_CODIGO_INTERFACES'
"use strict";
const formulario = document.querySelector("#formulario");
const boton = document.querySelector("#evaluar");
const error = document.querySelector("#error");
const resultado = document.querySelector("#resultado");
let reporte = "";
let solicitud = 0;
let edicion = 0;

function mostrar(datos) {
  resultado.hidden = false;
  document.querySelector("#espera").hidden = true;
  document.querySelector("#nota-edicion").hidden = true;
  const titulo = document.querySelector("#diagnostico");
  titulo.textContent = datos.titulo;
  titulo.className = datos.clase || "neutral";
  const mensajes = document.querySelector("#mensajes");
  mensajes.replaceChildren();
  for (const texto of datos.mensajes || []) {
    const p = document.createElement("p"); p.textContent = texto; mensajes.append(p);
  }
  const tablas = document.querySelector("#tablas"); tablas.replaceChildren();
  for (const contenido of datos.tablas || []) {
    const bloque = document.createElement("section");
    const nombre = document.createElement("h4"); nombre.textContent = contenido.titulo; bloque.append(nombre);
    const envoltura = document.createElement("div"); envoltura.className = "tabla";
    const tabla = document.createElement("table");
    const cabecera = document.createElement("thead"); const fila = document.createElement("tr");
    for (const etiqueta of contenido.encabezados) {
      const celda = document.createElement("th"); celda.scope = "col"; celda.textContent = etiqueta; fila.append(celda);
    }
    cabecera.append(fila); tabla.append(cabecera);
    const cuerpo = document.createElement("tbody");
    for (const valores of contenido.filas) {
      const fila = document.createElement("tr");
      for (const valor of valores) {
        const celda = document.createElement("td"); celda.textContent = valor; fila.append(celda);
      }
      cuerpo.append(fila);
    }
    tabla.append(cuerpo); envoltura.append(tabla); bloque.append(envoltura); tablas.append(bloque);
  }
  reporte = datos.reporte || "";
  document.querySelector("#descargar").hidden = !reporte;
}

formulario.addEventListener("submit", async (evento) => {
  evento.preventDefault();
  const actual = ++solicitud;
  const edicionEnviada = edicion;
  boton.disabled = true; formulario.setAttribute("aria-busy", "true"); error.hidden = true;
  try {
    const respuesta = await fetch(formulario.action, { method: "POST", body: new FormData(formulario), credentials: "same-origin" });
    const datos = await respuesta.json();
    if (actual !== solicitud) return;
    if (!respuesta.ok || !datos.ok) throw new Error(datos.mensaje || "No se pudo evaluar el formulario.");
    mostrar(datos.resultado);
    document.querySelector("#nota-edicion").hidden = edicion === edicionEnviada;
  } catch (fallo) {
    if (actual !== solicitud) return;
    error.textContent = fallo instanceof TypeError ? "No se pudo contactar con Python. Comprueba la terminal del servidor." : fallo.message;
    error.hidden = false;
  } finally {
    if (actual === solicitud) { boton.disabled = false; formulario.setAttribute("aria-busy", "false"); }
  }
});
formulario.addEventListener("input", () => {
  edicion++;
  if (!resultado.hidden) document.querySelector("#nota-edicion").hidden = false;
});
formulario.addEventListener("reset", () => {
  solicitud++; boton.disabled = false; formulario.setAttribute("aria-busy", "false");
  resultado.hidden = true; document.querySelector("#espera").hidden = false; error.hidden = true; reporte = "";
});
document.querySelector("#descargar").addEventListener("click", () => {
  const url = URL.createObjectURL(new Blob([reporte], {type: "text/plain;charset=utf-8"}));
  const enlace = document.createElement("a"); enlace.href = url; enlace.download = "reporte_diagnostico.txt"; enlace.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});
if (document.querySelector("main").dataset.numero === "1") formulario.requestSubmit();
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-01-tablas-de-verdad/static/estilos.css" <<'FIN_CODIGO_INTERFACES'

:root { font-family: "Segoe UI", system-ui, sans-serif; color: #25354a; background: #f4f6fa; line-height: 1.5; }
* { box-sizing: border-box; } body { margin: 0; } [hidden] { display: none !important; }
main { max-width: 1240px; margin: auto; padding: 26px 30px; }
header { display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid #dce3ed; padding-bottom: 22px; gap: 15px; }
.marca { display: flex; align-items: center; gap: 10px; font-size: 13px; font-weight: 650; text-decoration: none; color: #405675; }
.marca span { display: grid; place-items: center; width: 38px; height: 38px; border-radius: 10px; background: #315c91; color: white; }
.etiqueta { font-size: 11px; letter-spacing: 1px; color: #5b7394; border: 1px solid #c9d5e5; border-radius: 30px; padding: 6px 12px; }
.introduccion { padding: 31px 0; } .supertitulo { font-size: 10px; letter-spacing: 2px; font-weight: 700; color: #6585ac; }
h1 { font-size: clamp(28px, 3vw, 40px); line-height: 1.18; letter-spacing: -1px; margin: 9px 0 12px; }
.introduccion > p:last-child { color: #687d95; font-size: 14px; max-width: 830px; margin-bottom: 0; }
.paneles { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1.05fr); align-items: start; gap: 25px; }
.tarjeta { padding: 26px; border: 1px solid #dce4ed; border-radius: 15px; background: white; box-shadow: 0 4px 14px #273c5506; }
.titulo-panel { display: flex; align-items: center; gap: 10px; margin-bottom: 23px; } .paso { font-size: 11px; padding: 5px 7px; border-radius: 7px; color: #506c99; background: #edf2fb; }
h2 { font-size: 19px; margin: 0; letter-spacing: -.4px; } h3 { font-size: 19px; line-height: 1.5; margin: 0 0 16px; padding: 16px; border-radius: 9px; }
h4 { font-size: 13px; margin: 23px 0 10px; color: #4f6787; }
fieldset { border: 0; padding: 0; margin: 0 0 24px; } legend { font-size: 12px; color: #657b96; font-weight: 650; padding: 0 0 12px; }
.campos { display: grid; gap: 16px; } label { display: block; font-size: 13px; font-weight: 550; margin-bottom: 7px; }
input, select { width: 100%; font: inherit; font-size: 13px; color: #304561; padding: 11px 12px; background: #fafbfd; border: 1px solid #c4d2e1; border-radius: 7px; }
input:focus-visible, select:focus-visible, button:focus-visible, a:focus-visible { outline: 3px solid #a3c4eb; outline-offset: 3px; }
.acciones { display: flex; gap: 10px; flex-wrap: wrap; } button { border: 0; font: inherit; font-size: 12px; font-weight: 650; color: white; background: #315c91; padding: 12px 17px; border-radius: 8px; cursor: pointer; }
#evaluar { flex: 1; display: flex; align-items: center; justify-content: space-between; gap: 20px; } button:hover { background: #244c7e; } button:disabled { opacity: .6; cursor: wait; }
.secundario { background: #f0f4f9; color: #4f6d96; border: 1px solid #d4dfed; } .secundario:hover { background: #e5edf8; }
.vacio { padding: 45px 24px; text-align: center; background: #fafbfd; border: 1px dashed #ced9e6; border-radius: 10px; color: #788ca3; font-size: 13px; }
.positivo { background: #eaf5ee; color: #286345; } .aviso { background: #fff5e8; color: #91682e; } .neutral { background: #edf3fc; color: #385b8a; }
.error { color: #923c32; background: #ffefeb; padding: 12px; border-radius: 8px; font-size: 13px; }
#nota-edicion { padding: 12px; font-size: 12px; border-radius: 7px; } #mensajes p { font-size: 13px; color: #5c728b; white-space: pre-wrap; }
.tabla { overflow-x: auto; } table { width: 100%; border-collapse: collapse; font-size: 12px; } th { background: #eef3f9; color: #527197; text-align: left; padding: 10px; white-space: nowrap; } td { padding: 11px 10px; border-bottom: 1px solid #e5ebf2; vertical-align: top; overflow-wrap: anywhere; }
#descargar { margin-top: 22px; } footer { font-size: 10px; color: #8496ac; text-align: center; padding-top: 27px; }
@media(max-width: 850px) { main { padding: 20px 16px; } .paneles { grid-template-columns: 1fr; } .tarjeta { padding: 22px; } }
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-01-tablas-de-verdad/templates/index.html" <<'FIN_CODIGO_INTERFACES'
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{{ titulo }} · Práctica {{ numero }}</title>
  <link rel="stylesheet" href="{{ url_for('static', filename='estilos.css') }}">
  <script src="{{ url_for('static', filename='app.js') }}" defer></script>
</head>
<body>
<main data-numero="{{ numero }}">
  <header><a class="marca" href="{{ url_for('inicio') }}"><span>IA</span> Fundamentos de IA</a><span class="etiqueta">PRÁCTICA {{ '%02d'|format(numero) }}</span></header>
  <section class="introduccion"><p class="supertitulo">APRENDER HACIENDO</p><h1>{{ titulo }}</h1><p>{{ descripcion }}</p></section>
  <div class="paneles">
    <section class="tarjeta captura"><div class="titulo-panel"><span class="paso">01</span><h2>{{ 'Explorar' if not grupos else 'Ingresa los datos' }}</h2></div>
      <form id="formulario" action="{{ url_for('procesar') }}" method="post">
        <input type="hidden" name="csrf" value="{{ session['csrf'] }}">
        {% for grupo in grupos %}<fieldset><legend>{{ grupo.titulo }}</legend><div class="campos">
          {% for campo in grupo.campos %}<div class="campo"><label for="{{ campo.clave }}">{{ campo.etiqueta }}</label>
            {% if campo.tipo == 'booleano' %}
            <select id="{{ campo.clave }}" name="{{ campo.clave }}" required><option value="">Selecciona una respuesta</option><option value="si">Sí</option><option value="no">No</option></select>
            {% elif campo.tipo == 'opcion' %}
            <select id="{{ campo.clave }}" name="{{ campo.clave }}" required><option value="">Selecciona una opción</option>{% for clave, etiqueta in campo.opciones.items() %}<option value="{{ clave }}">{{ etiqueta }}</option>{% endfor %}</select>
            {% else %}
            <input id="{{ campo.clave }}" name="{{ campo.clave }}" type="text" {% if campo.tipo == 'numero' %}inputmode="decimal"{% endif %} required autocomplete="off">
            {% endif %}
          </div>{% endfor %}
        </div></fieldset>{% else %}<p class="ayuda">Compara las cuatro combinaciones de P y Q y el resultado de cada operación lógica.</p>{% endfor %}
        <div class="acciones"><button type="submit" id="evaluar">{{ boton }} <span aria-hidden="true">→</span></button>{% if grupos %}<button type="reset" class="secundario">Limpiar</button>{% endif %}</div>
      </form>
      <p id="error" class="error" role="alert" hidden></p>
    </section>
    <section class="tarjeta salida" aria-labelledby="titulo-resultado">
      <div class="titulo-panel"><span class="paso">02</span><h2 id="titulo-resultado">Resultado</h2></div>
      <p id="espera" class="vacio">{{ 'La tabla se mostrará aquí.' if not grupos else 'Completa el formulario para ver el resultado.' }}</p>
      <div id="resultado" aria-live="polite" hidden><p id="nota-edicion" class="aviso" hidden>Modificaste el formulario. Vuelve a evaluar para actualizar este resultado.</p><h3 id="diagnostico"></h3><div id="mensajes"></div><div id="tablas"></div><button id="descargar" class="secundario" type="button" hidden>Descargar reporte TXT</button></div>
    </section>
  </div>
  <footer>Práctica {{ numero }} · Python y una interfaz para aprender</footer>
</main>
</body>
</html>
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-02-sistema-examen/02_sistema_examen.py" <<'FIN_CODIGO_INTERFACES'
"""Práctica 2: interfaz independiente; reglas originales conservadas."""

ASISTENCIA_MINIMA = 80

PROMEDIO_MINIMO = 8

def puede_presentar_examen(
    asistencia: float,
    promedio: float,
    proyecto: bool,
    adeudos: bool,
    autorizacion: bool,
) -> bool:
    cumple_asistencia = asistencia >= ASISTENCIA_MINIMA  # P
    cumple_promedio = promedio >= PROMEDIO_MINIMO  # Q
    sin_adeudos = not adeudos  # S; proyecto es R y autorización es T.

    # Regla original: (P ∧ Q ∧ R ∧ S) ∨ T.
    return (
        cumple_asistencia and cumple_promedio and proyecto and sin_adeudos
    ) or autorizacion

NUMERO = 2
PUERTO = 5102
TITULO = 'Sistema de examen'
DESCRIPCION = 'Evalúa la autorización para presentar el examen con las condiciones de la práctica.'
GRUPOS = [{'titulo': 'Condiciones del alumno',
  'campos': [{'clave': 'asistencia',
              'etiqueta': 'Porcentaje de asistencia',
              'tipo': 'numero'},
             {'clave': 'promedio', 'etiqueta': 'Promedio', 'tipo': 'numero'},
             {'clave': 'proyecto',
              'etiqueta': '¿Entregó el proyecto?',
              'tipo': 'booleano'},
             {'clave': 'adeudos', 'etiqueta': '¿Tiene adeudos?', 'tipo': 'booleano'},
             {'clave': 'autorizacion',
              'etiqueta': '¿Tiene autorización especial?',
              'tipo': 'booleano'}]}]
BOTON = 'Evaluar autorización'


def evaluar(datos):
    autorizado = puede_presentar_examen(**datos)
    return {"titulo": "El alumno PUEDE presentar el examen." if autorizado else "El alumno NO puede presentar el examen.",
            "clase": "positivo" if autorizado else "aviso", "mensajes": [], "tablas": []}


from pathlib import Path
import secrets
from math import isfinite
from flask import Flask, jsonify, render_template, request, session

def leer_formulario(formulario):
    datos = {}
    for grupo in GRUPOS:
        for campo in grupo["campos"]:
            clave = campo["clave"]
            valor = formulario.get(clave, "").strip()
            if not valor:
                raise ValueError(f"Completa el campo: {campo['etiqueta']}.")
            if campo["tipo"] == "booleano":
                if valor not in ("si", "no"):
                    raise ValueError(f"Selecciona Sí o No en: {campo['etiqueta']}.")
                datos[clave] = valor == "si"
            elif campo["tipo"] == "numero":
                try:
                    numero = float(valor)
                except ValueError:
                    raise ValueError(f"Ingresa un número válido en: {campo['etiqueta']}.") from None
                if not isfinite(numero):
                    raise ValueError(f"El número de {campo['etiqueta']} debe ser finito.")
                datos[clave] = numero
            elif campo["tipo"] == "opcion":
                if valor not in campo["opciones"]:
                    raise ValueError(f"Selecciona una opción válida en: {campo['etiqueta']}.")
                datos[clave] = valor
            else:
                datos[clave] = valor
    return datos

def crear_app():
    raiz = Path(__file__).resolve().parent
    app = Flask(__name__, template_folder=str(raiz / "templates"), static_folder=str(raiz / "static"))
    app.config.update(SECRET_KEY=secrets.token_hex(32), SESSION_COOKIE_HTTPONLY=True,
                      SESSION_COOKIE_SAMESITE="Strict", MAX_CONTENT_LENGTH=131072)

    @app.after_request
    def proteger(respuesta):
        respuesta.headers["Cache-Control"] = "no-store"
        respuesta.headers["X-Content-Type-Options"] = "nosniff"
        respuesta.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'"
        return respuesta

    @app.get("/")
    def inicio():
        session.setdefault("csrf", secrets.token_hex(32))
        return render_template("index.html", numero=NUMERO, titulo=TITULO, descripcion=DESCRIPCION, grupos=GRUPOS, boton=BOTON)

    @app.post("/evaluar")
    def procesar():
        token = request.form.get("csrf", "")
        if not token or not secrets.compare_digest(token.encode(), session.get("csrf", "").encode()):
            return jsonify(ok=False, mensaje="El formulario expiró. Recarga la página."), 400
        try:
            datos = leer_formulario(request.form)
        except ValueError as error:
            return jsonify(ok=False, mensaje=str(error)), 400
        return jsonify(ok=True, resultado=evaluar(datos))

    @app.errorhandler(413)
    def demasiado_grande(error):
        return jsonify(ok=False, mensaje="El formulario es demasiado grande. Reduce el texto e inténtalo de nuevo."), 413

    return app

if __name__ == "__main__":
    print(f"Abre http://localhost:{PUERTO} en tu navegador. Detén el servidor con Ctrl+C.")
    crear_app().run(host="127.0.0.1", port=PUERTO, debug=False)
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-02-sistema-examen/README.md" <<'FIN_CODIGO_INTERFACES'
# Práctica 2: Sistema de examen

Evalúa la autorización para presentar el examen con las condiciones de la práctica.

Desde la raíz del proyecto:

```bash
bash unidad-01-introduccion-ia/practicas/practica-02-sistema-examen/ejecutar.sh
```

Abre http://localhost:5102. Detén el servidor con Ctrl+C.

Programa independiente: todo el código, HTML, CSS y JavaScript está en esta carpeta.
Las funciones de las reglas se conservan del programa optimizado. Los campos
se validan en Python. Los resultados no se guardan en una base de datos.

Flask devuelve JSON; JavaScript muestra texto sin interpretarlo como HTML.
La práctica 5 permite descargar su reporte en TXT.
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-02-sistema-examen/ejecutar.sh" <<'FIN_CODIGO_INTERFACES'
#!/usr/bin/env bash
set -euo pipefail
directorio="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
proyecto="$(cd -- "$directorio/../../.." && pwd)"
exec "$proyecto/.venv/bin/python" "$directorio/02_sistema_examen.py"
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-02-sistema-examen/requirements.txt" <<'FIN_CODIGO_INTERFACES'
Flask>=3.1,<4
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-02-sistema-examen/static/app.js" <<'FIN_CODIGO_INTERFACES'
"use strict";
const formulario = document.querySelector("#formulario");
const boton = document.querySelector("#evaluar");
const error = document.querySelector("#error");
const resultado = document.querySelector("#resultado");
let reporte = "";
let solicitud = 0;
let edicion = 0;

function mostrar(datos) {
  resultado.hidden = false;
  document.querySelector("#espera").hidden = true;
  document.querySelector("#nota-edicion").hidden = true;
  const titulo = document.querySelector("#diagnostico");
  titulo.textContent = datos.titulo;
  titulo.className = datos.clase || "neutral";
  const mensajes = document.querySelector("#mensajes");
  mensajes.replaceChildren();
  for (const texto of datos.mensajes || []) {
    const p = document.createElement("p"); p.textContent = texto; mensajes.append(p);
  }
  const tablas = document.querySelector("#tablas"); tablas.replaceChildren();
  for (const contenido of datos.tablas || []) {
    const bloque = document.createElement("section");
    const nombre = document.createElement("h4"); nombre.textContent = contenido.titulo; bloque.append(nombre);
    const envoltura = document.createElement("div"); envoltura.className = "tabla";
    const tabla = document.createElement("table");
    const cabecera = document.createElement("thead"); const fila = document.createElement("tr");
    for (const etiqueta of contenido.encabezados) {
      const celda = document.createElement("th"); celda.scope = "col"; celda.textContent = etiqueta; fila.append(celda);
    }
    cabecera.append(fila); tabla.append(cabecera);
    const cuerpo = document.createElement("tbody");
    for (const valores of contenido.filas) {
      const fila = document.createElement("tr");
      for (const valor of valores) {
        const celda = document.createElement("td"); celda.textContent = valor; fila.append(celda);
      }
      cuerpo.append(fila);
    }
    tabla.append(cuerpo); envoltura.append(tabla); bloque.append(envoltura); tablas.append(bloque);
  }
  reporte = datos.reporte || "";
  document.querySelector("#descargar").hidden = !reporte;
}

formulario.addEventListener("submit", async (evento) => {
  evento.preventDefault();
  const actual = ++solicitud;
  const edicionEnviada = edicion;
  boton.disabled = true; formulario.setAttribute("aria-busy", "true"); error.hidden = true;
  try {
    const respuesta = await fetch(formulario.action, { method: "POST", body: new FormData(formulario), credentials: "same-origin" });
    const datos = await respuesta.json();
    if (actual !== solicitud) return;
    if (!respuesta.ok || !datos.ok) throw new Error(datos.mensaje || "No se pudo evaluar el formulario.");
    mostrar(datos.resultado);
    document.querySelector("#nota-edicion").hidden = edicion === edicionEnviada;
  } catch (fallo) {
    if (actual !== solicitud) return;
    error.textContent = fallo instanceof TypeError ? "No se pudo contactar con Python. Comprueba la terminal del servidor." : fallo.message;
    error.hidden = false;
  } finally {
    if (actual === solicitud) { boton.disabled = false; formulario.setAttribute("aria-busy", "false"); }
  }
});
formulario.addEventListener("input", () => {
  edicion++;
  if (!resultado.hidden) document.querySelector("#nota-edicion").hidden = false;
});
formulario.addEventListener("reset", () => {
  solicitud++; boton.disabled = false; formulario.setAttribute("aria-busy", "false");
  resultado.hidden = true; document.querySelector("#espera").hidden = false; error.hidden = true; reporte = "";
});
document.querySelector("#descargar").addEventListener("click", () => {
  const url = URL.createObjectURL(new Blob([reporte], {type: "text/plain;charset=utf-8"}));
  const enlace = document.createElement("a"); enlace.href = url; enlace.download = "reporte_diagnostico.txt"; enlace.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});
if (document.querySelector("main").dataset.numero === "1") formulario.requestSubmit();
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-02-sistema-examen/static/estilos.css" <<'FIN_CODIGO_INTERFACES'

:root { font-family: "Segoe UI", system-ui, sans-serif; color: #25354a; background: #f4f6fa; line-height: 1.5; }
* { box-sizing: border-box; } body { margin: 0; } [hidden] { display: none !important; }
main { max-width: 1240px; margin: auto; padding: 26px 30px; }
header { display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid #dce3ed; padding-bottom: 22px; gap: 15px; }
.marca { display: flex; align-items: center; gap: 10px; font-size: 13px; font-weight: 650; text-decoration: none; color: #405675; }
.marca span { display: grid; place-items: center; width: 38px; height: 38px; border-radius: 10px; background: #315c91; color: white; }
.etiqueta { font-size: 11px; letter-spacing: 1px; color: #5b7394; border: 1px solid #c9d5e5; border-radius: 30px; padding: 6px 12px; }
.introduccion { padding: 31px 0; } .supertitulo { font-size: 10px; letter-spacing: 2px; font-weight: 700; color: #6585ac; }
h1 { font-size: clamp(28px, 3vw, 40px); line-height: 1.18; letter-spacing: -1px; margin: 9px 0 12px; }
.introduccion > p:last-child { color: #687d95; font-size: 14px; max-width: 830px; margin-bottom: 0; }
.paneles { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1.05fr); align-items: start; gap: 25px; }
.tarjeta { padding: 26px; border: 1px solid #dce4ed; border-radius: 15px; background: white; box-shadow: 0 4px 14px #273c5506; }
.titulo-panel { display: flex; align-items: center; gap: 10px; margin-bottom: 23px; } .paso { font-size: 11px; padding: 5px 7px; border-radius: 7px; color: #506c99; background: #edf2fb; }
h2 { font-size: 19px; margin: 0; letter-spacing: -.4px; } h3 { font-size: 19px; line-height: 1.5; margin: 0 0 16px; padding: 16px; border-radius: 9px; }
h4 { font-size: 13px; margin: 23px 0 10px; color: #4f6787; }
fieldset { border: 0; padding: 0; margin: 0 0 24px; } legend { font-size: 12px; color: #657b96; font-weight: 650; padding: 0 0 12px; }
.campos { display: grid; gap: 16px; } label { display: block; font-size: 13px; font-weight: 550; margin-bottom: 7px; }
input, select { width: 100%; font: inherit; font-size: 13px; color: #304561; padding: 11px 12px; background: #fafbfd; border: 1px solid #c4d2e1; border-radius: 7px; }
input:focus-visible, select:focus-visible, button:focus-visible, a:focus-visible { outline: 3px solid #a3c4eb; outline-offset: 3px; }
.acciones { display: flex; gap: 10px; flex-wrap: wrap; } button { border: 0; font: inherit; font-size: 12px; font-weight: 650; color: white; background: #315c91; padding: 12px 17px; border-radius: 8px; cursor: pointer; }
#evaluar { flex: 1; display: flex; align-items: center; justify-content: space-between; gap: 20px; } button:hover { background: #244c7e; } button:disabled { opacity: .6; cursor: wait; }
.secundario { background: #f0f4f9; color: #4f6d96; border: 1px solid #d4dfed; } .secundario:hover { background: #e5edf8; }
.vacio { padding: 45px 24px; text-align: center; background: #fafbfd; border: 1px dashed #ced9e6; border-radius: 10px; color: #788ca3; font-size: 13px; }
.positivo { background: #eaf5ee; color: #286345; } .aviso { background: #fff5e8; color: #91682e; } .neutral { background: #edf3fc; color: #385b8a; }
.error { color: #923c32; background: #ffefeb; padding: 12px; border-radius: 8px; font-size: 13px; }
#nota-edicion { padding: 12px; font-size: 12px; border-radius: 7px; } #mensajes p { font-size: 13px; color: #5c728b; white-space: pre-wrap; }
.tabla { overflow-x: auto; } table { width: 100%; border-collapse: collapse; font-size: 12px; } th { background: #eef3f9; color: #527197; text-align: left; padding: 10px; white-space: nowrap; } td { padding: 11px 10px; border-bottom: 1px solid #e5ebf2; vertical-align: top; overflow-wrap: anywhere; }
#descargar { margin-top: 22px; } footer { font-size: 10px; color: #8496ac; text-align: center; padding-top: 27px; }
@media(max-width: 850px) { main { padding: 20px 16px; } .paneles { grid-template-columns: 1fr; } .tarjeta { padding: 22px; } }
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-02-sistema-examen/templates/index.html" <<'FIN_CODIGO_INTERFACES'
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{{ titulo }} · Práctica {{ numero }}</title>
  <link rel="stylesheet" href="{{ url_for('static', filename='estilos.css') }}">
  <script src="{{ url_for('static', filename='app.js') }}" defer></script>
</head>
<body>
<main data-numero="{{ numero }}">
  <header><a class="marca" href="{{ url_for('inicio') }}"><span>IA</span> Fundamentos de IA</a><span class="etiqueta">PRÁCTICA {{ '%02d'|format(numero) }}</span></header>
  <section class="introduccion"><p class="supertitulo">APRENDER HACIENDO</p><h1>{{ titulo }}</h1><p>{{ descripcion }}</p></section>
  <div class="paneles">
    <section class="tarjeta captura"><div class="titulo-panel"><span class="paso">01</span><h2>{{ 'Explorar' if not grupos else 'Ingresa los datos' }}</h2></div>
      <form id="formulario" action="{{ url_for('procesar') }}" method="post">
        <input type="hidden" name="csrf" value="{{ session['csrf'] }}">
        {% for grupo in grupos %}<fieldset><legend>{{ grupo.titulo }}</legend><div class="campos">
          {% for campo in grupo.campos %}<div class="campo"><label for="{{ campo.clave }}">{{ campo.etiqueta }}</label>
            {% if campo.tipo == 'booleano' %}
            <select id="{{ campo.clave }}" name="{{ campo.clave }}" required><option value="">Selecciona una respuesta</option><option value="si">Sí</option><option value="no">No</option></select>
            {% elif campo.tipo == 'opcion' %}
            <select id="{{ campo.clave }}" name="{{ campo.clave }}" required><option value="">Selecciona una opción</option>{% for clave, etiqueta in campo.opciones.items() %}<option value="{{ clave }}">{{ etiqueta }}</option>{% endfor %}</select>
            {% else %}
            <input id="{{ campo.clave }}" name="{{ campo.clave }}" type="text" {% if campo.tipo == 'numero' %}inputmode="decimal"{% endif %} required autocomplete="off">
            {% endif %}
          </div>{% endfor %}
        </div></fieldset>{% else %}<p class="ayuda">Compara las cuatro combinaciones de P y Q y el resultado de cada operación lógica.</p>{% endfor %}
        <div class="acciones"><button type="submit" id="evaluar">{{ boton }} <span aria-hidden="true">→</span></button>{% if grupos %}<button type="reset" class="secundario">Limpiar</button>{% endif %}</div>
      </form>
      <p id="error" class="error" role="alert" hidden></p>
    </section>
    <section class="tarjeta salida" aria-labelledby="titulo-resultado">
      <div class="titulo-panel"><span class="paso">02</span><h2 id="titulo-resultado">Resultado</h2></div>
      <p id="espera" class="vacio">{{ 'La tabla se mostrará aquí.' if not grupos else 'Completa el formulario para ver el resultado.' }}</p>
      <div id="resultado" aria-live="polite" hidden><p id="nota-edicion" class="aviso" hidden>Modificaste el formulario. Vuelve a evaluar para actualizar este resultado.</p><h3 id="diagnostico"></h3><div id="mensajes"></div><div id="tablas"></div><button id="descargar" class="secundario" type="button" hidden>Descargar reporte TXT</button></div>
    </section>
  </div>
  <footer>Práctica {{ numero }} · Python y una interfaz para aprender</footer>
</main>
</body>
</html>
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-03-sistema-examen-lista-oficial/03_sistema_examen_lista_oficial.py" <<'FIN_CODIGO_INTERFACES'
"""Práctica 3: interfaz independiente; reglas originales conservadas."""

ASISTENCIA_MINIMA = 80

PROMEDIO_MINIMO = 8

def puede_presentar_examen(
    asistencia: float,
    promedio: float,
    proyecto: bool,
    adeudos: bool,
    autorizacion: bool,
    lista_oficial: bool,
) -> bool:
    cumple_asistencia = asistencia >= ASISTENCIA_MINIMA  # P
    cumple_promedio = promedio >= PROMEDIO_MINIMO  # Q
    sin_adeudos = not adeudos  # S; proyecto es R y autorización es T.

    # Regla original: ((P ∧ Q ∧ R ∧ S) ∨ T) ∧ U.
    # U (lista oficial) es obligatorio incluso con autorización especial.
    return (
        (cumple_asistencia and cumple_promedio and proyecto and sin_adeudos)
        or autorizacion
    ) and lista_oficial

NUMERO = 3
PUERTO = 5103
TITULO = 'Examen con lista oficial'
DESCRIPCION = 'La lista oficial es obligatoria, incluso cuando existe autorización especial.'
GRUPOS = [{'titulo': 'Condiciones del alumno',
  'campos': [{'clave': 'asistencia',
              'etiqueta': 'Porcentaje de asistencia',
              'tipo': 'numero'},
             {'clave': 'promedio', 'etiqueta': 'Promedio', 'tipo': 'numero'},
             {'clave': 'proyecto',
              'etiqueta': '¿Entregó el proyecto?',
              'tipo': 'booleano'},
             {'clave': 'adeudos', 'etiqueta': '¿Tiene adeudos?', 'tipo': 'booleano'},
             {'clave': 'autorizacion',
              'etiqueta': '¿Tiene autorización especial?',
              'tipo': 'booleano'},
             {'clave': 'lista_oficial',
              'etiqueta': '¿Aparece en la lista oficial?',
              'tipo': 'booleano'}]}]
BOTON = 'Evaluar autorización'


def evaluar(datos):
    autorizado = puede_presentar_examen(**datos)
    mensajes = [] if datos["lista_oficial"] else ["Motivo: El alumno NO aparece en la lista oficial."]
    return {"titulo": "El alumno PUEDE presentar el examen." if autorizado else "El alumno NO puede presentar el examen.",
            "clase": "positivo" if autorizado else "aviso", "mensajes": mensajes, "tablas": []}


from pathlib import Path
import secrets
from math import isfinite
from flask import Flask, jsonify, render_template, request, session

def leer_formulario(formulario):
    datos = {}
    for grupo in GRUPOS:
        for campo in grupo["campos"]:
            clave = campo["clave"]
            valor = formulario.get(clave, "").strip()
            if not valor:
                raise ValueError(f"Completa el campo: {campo['etiqueta']}.")
            if campo["tipo"] == "booleano":
                if valor not in ("si", "no"):
                    raise ValueError(f"Selecciona Sí o No en: {campo['etiqueta']}.")
                datos[clave] = valor == "si"
            elif campo["tipo"] == "numero":
                try:
                    numero = float(valor)
                except ValueError:
                    raise ValueError(f"Ingresa un número válido en: {campo['etiqueta']}.") from None
                if not isfinite(numero):
                    raise ValueError(f"El número de {campo['etiqueta']} debe ser finito.")
                datos[clave] = numero
            elif campo["tipo"] == "opcion":
                if valor not in campo["opciones"]:
                    raise ValueError(f"Selecciona una opción válida en: {campo['etiqueta']}.")
                datos[clave] = valor
            else:
                datos[clave] = valor
    return datos

def crear_app():
    raiz = Path(__file__).resolve().parent
    app = Flask(__name__, template_folder=str(raiz / "templates"), static_folder=str(raiz / "static"))
    app.config.update(SECRET_KEY=secrets.token_hex(32), SESSION_COOKIE_HTTPONLY=True,
                      SESSION_COOKIE_SAMESITE="Strict", MAX_CONTENT_LENGTH=131072)

    @app.after_request
    def proteger(respuesta):
        respuesta.headers["Cache-Control"] = "no-store"
        respuesta.headers["X-Content-Type-Options"] = "nosniff"
        respuesta.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'"
        return respuesta

    @app.get("/")
    def inicio():
        session.setdefault("csrf", secrets.token_hex(32))
        return render_template("index.html", numero=NUMERO, titulo=TITULO, descripcion=DESCRIPCION, grupos=GRUPOS, boton=BOTON)

    @app.post("/evaluar")
    def procesar():
        token = request.form.get("csrf", "")
        if not token or not secrets.compare_digest(token.encode(), session.get("csrf", "").encode()):
            return jsonify(ok=False, mensaje="El formulario expiró. Recarga la página."), 400
        try:
            datos = leer_formulario(request.form)
        except ValueError as error:
            return jsonify(ok=False, mensaje=str(error)), 400
        return jsonify(ok=True, resultado=evaluar(datos))

    @app.errorhandler(413)
    def demasiado_grande(error):
        return jsonify(ok=False, mensaje="El formulario es demasiado grande. Reduce el texto e inténtalo de nuevo."), 413

    return app

if __name__ == "__main__":
    print(f"Abre http://localhost:{PUERTO} en tu navegador. Detén el servidor con Ctrl+C.")
    crear_app().run(host="127.0.0.1", port=PUERTO, debug=False)
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-03-sistema-examen-lista-oficial/README.md" <<'FIN_CODIGO_INTERFACES'
# Práctica 3: Examen con lista oficial

La lista oficial es obligatoria, incluso cuando existe autorización especial.

Desde la raíz del proyecto:

```bash
bash unidad-01-introduccion-ia/practicas/practica-03-sistema-examen-lista-oficial/ejecutar.sh
```

Abre http://localhost:5103. Detén el servidor con Ctrl+C.

Programa independiente: todo el código, HTML, CSS y JavaScript está en esta carpeta.
Las funciones de las reglas se conservan del programa optimizado. Los campos
se validan en Python. Los resultados no se guardan en una base de datos.

Flask devuelve JSON; JavaScript muestra texto sin interpretarlo como HTML.
La práctica 5 permite descargar su reporte en TXT.
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-03-sistema-examen-lista-oficial/ejecutar.sh" <<'FIN_CODIGO_INTERFACES'
#!/usr/bin/env bash
set -euo pipefail
directorio="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
proyecto="$(cd -- "$directorio/../../.." && pwd)"
exec "$proyecto/.venv/bin/python" "$directorio/03_sistema_examen_lista_oficial.py"
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-03-sistema-examen-lista-oficial/requirements.txt" <<'FIN_CODIGO_INTERFACES'
Flask>=3.1,<4
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-03-sistema-examen-lista-oficial/static/app.js" <<'FIN_CODIGO_INTERFACES'
"use strict";
const formulario = document.querySelector("#formulario");
const boton = document.querySelector("#evaluar");
const error = document.querySelector("#error");
const resultado = document.querySelector("#resultado");
let reporte = "";
let solicitud = 0;
let edicion = 0;

function mostrar(datos) {
  resultado.hidden = false;
  document.querySelector("#espera").hidden = true;
  document.querySelector("#nota-edicion").hidden = true;
  const titulo = document.querySelector("#diagnostico");
  titulo.textContent = datos.titulo;
  titulo.className = datos.clase || "neutral";
  const mensajes = document.querySelector("#mensajes");
  mensajes.replaceChildren();
  for (const texto of datos.mensajes || []) {
    const p = document.createElement("p"); p.textContent = texto; mensajes.append(p);
  }
  const tablas = document.querySelector("#tablas"); tablas.replaceChildren();
  for (const contenido of datos.tablas || []) {
    const bloque = document.createElement("section");
    const nombre = document.createElement("h4"); nombre.textContent = contenido.titulo; bloque.append(nombre);
    const envoltura = document.createElement("div"); envoltura.className = "tabla";
    const tabla = document.createElement("table");
    const cabecera = document.createElement("thead"); const fila = document.createElement("tr");
    for (const etiqueta of contenido.encabezados) {
      const celda = document.createElement("th"); celda.scope = "col"; celda.textContent = etiqueta; fila.append(celda);
    }
    cabecera.append(fila); tabla.append(cabecera);
    const cuerpo = document.createElement("tbody");
    for (const valores of contenido.filas) {
      const fila = document.createElement("tr");
      for (const valor of valores) {
        const celda = document.createElement("td"); celda.textContent = valor; fila.append(celda);
      }
      cuerpo.append(fila);
    }
    tabla.append(cuerpo); envoltura.append(tabla); bloque.append(envoltura); tablas.append(bloque);
  }
  reporte = datos.reporte || "";
  document.querySelector("#descargar").hidden = !reporte;
}

formulario.addEventListener("submit", async (evento) => {
  evento.preventDefault();
  const actual = ++solicitud;
  const edicionEnviada = edicion;
  boton.disabled = true; formulario.setAttribute("aria-busy", "true"); error.hidden = true;
  try {
    const respuesta = await fetch(formulario.action, { method: "POST", body: new FormData(formulario), credentials: "same-origin" });
    const datos = await respuesta.json();
    if (actual !== solicitud) return;
    if (!respuesta.ok || !datos.ok) throw new Error(datos.mensaje || "No se pudo evaluar el formulario.");
    mostrar(datos.resultado);
    document.querySelector("#nota-edicion").hidden = edicion === edicionEnviada;
  } catch (fallo) {
    if (actual !== solicitud) return;
    error.textContent = fallo instanceof TypeError ? "No se pudo contactar con Python. Comprueba la terminal del servidor." : fallo.message;
    error.hidden = false;
  } finally {
    if (actual === solicitud) { boton.disabled = false; formulario.setAttribute("aria-busy", "false"); }
  }
});
formulario.addEventListener("input", () => {
  edicion++;
  if (!resultado.hidden) document.querySelector("#nota-edicion").hidden = false;
});
formulario.addEventListener("reset", () => {
  solicitud++; boton.disabled = false; formulario.setAttribute("aria-busy", "false");
  resultado.hidden = true; document.querySelector("#espera").hidden = false; error.hidden = true; reporte = "";
});
document.querySelector("#descargar").addEventListener("click", () => {
  const url = URL.createObjectURL(new Blob([reporte], {type: "text/plain;charset=utf-8"}));
  const enlace = document.createElement("a"); enlace.href = url; enlace.download = "reporte_diagnostico.txt"; enlace.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});
if (document.querySelector("main").dataset.numero === "1") formulario.requestSubmit();
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-03-sistema-examen-lista-oficial/static/estilos.css" <<'FIN_CODIGO_INTERFACES'

:root { font-family: "Segoe UI", system-ui, sans-serif; color: #25354a; background: #f4f6fa; line-height: 1.5; }
* { box-sizing: border-box; } body { margin: 0; } [hidden] { display: none !important; }
main { max-width: 1240px; margin: auto; padding: 26px 30px; }
header { display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid #dce3ed; padding-bottom: 22px; gap: 15px; }
.marca { display: flex; align-items: center; gap: 10px; font-size: 13px; font-weight: 650; text-decoration: none; color: #405675; }
.marca span { display: grid; place-items: center; width: 38px; height: 38px; border-radius: 10px; background: #315c91; color: white; }
.etiqueta { font-size: 11px; letter-spacing: 1px; color: #5b7394; border: 1px solid #c9d5e5; border-radius: 30px; padding: 6px 12px; }
.introduccion { padding: 31px 0; } .supertitulo { font-size: 10px; letter-spacing: 2px; font-weight: 700; color: #6585ac; }
h1 { font-size: clamp(28px, 3vw, 40px); line-height: 1.18; letter-spacing: -1px; margin: 9px 0 12px; }
.introduccion > p:last-child { color: #687d95; font-size: 14px; max-width: 830px; margin-bottom: 0; }
.paneles { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1.05fr); align-items: start; gap: 25px; }
.tarjeta { padding: 26px; border: 1px solid #dce4ed; border-radius: 15px; background: white; box-shadow: 0 4px 14px #273c5506; }
.titulo-panel { display: flex; align-items: center; gap: 10px; margin-bottom: 23px; } .paso { font-size: 11px; padding: 5px 7px; border-radius: 7px; color: #506c99; background: #edf2fb; }
h2 { font-size: 19px; margin: 0; letter-spacing: -.4px; } h3 { font-size: 19px; line-height: 1.5; margin: 0 0 16px; padding: 16px; border-radius: 9px; }
h4 { font-size: 13px; margin: 23px 0 10px; color: #4f6787; }
fieldset { border: 0; padding: 0; margin: 0 0 24px; } legend { font-size: 12px; color: #657b96; font-weight: 650; padding: 0 0 12px; }
.campos { display: grid; gap: 16px; } label { display: block; font-size: 13px; font-weight: 550; margin-bottom: 7px; }
input, select { width: 100%; font: inherit; font-size: 13px; color: #304561; padding: 11px 12px; background: #fafbfd; border: 1px solid #c4d2e1; border-radius: 7px; }
input:focus-visible, select:focus-visible, button:focus-visible, a:focus-visible { outline: 3px solid #a3c4eb; outline-offset: 3px; }
.acciones { display: flex; gap: 10px; flex-wrap: wrap; } button { border: 0; font: inherit; font-size: 12px; font-weight: 650; color: white; background: #315c91; padding: 12px 17px; border-radius: 8px; cursor: pointer; }
#evaluar { flex: 1; display: flex; align-items: center; justify-content: space-between; gap: 20px; } button:hover { background: #244c7e; } button:disabled { opacity: .6; cursor: wait; }
.secundario { background: #f0f4f9; color: #4f6d96; border: 1px solid #d4dfed; } .secundario:hover { background: #e5edf8; }
.vacio { padding: 45px 24px; text-align: center; background: #fafbfd; border: 1px dashed #ced9e6; border-radius: 10px; color: #788ca3; font-size: 13px; }
.positivo { background: #eaf5ee; color: #286345; } .aviso { background: #fff5e8; color: #91682e; } .neutral { background: #edf3fc; color: #385b8a; }
.error { color: #923c32; background: #ffefeb; padding: 12px; border-radius: 8px; font-size: 13px; }
#nota-edicion { padding: 12px; font-size: 12px; border-radius: 7px; } #mensajes p { font-size: 13px; color: #5c728b; white-space: pre-wrap; }
.tabla { overflow-x: auto; } table { width: 100%; border-collapse: collapse; font-size: 12px; } th { background: #eef3f9; color: #527197; text-align: left; padding: 10px; white-space: nowrap; } td { padding: 11px 10px; border-bottom: 1px solid #e5ebf2; vertical-align: top; overflow-wrap: anywhere; }
#descargar { margin-top: 22px; } footer { font-size: 10px; color: #8496ac; text-align: center; padding-top: 27px; }
@media(max-width: 850px) { main { padding: 20px 16px; } .paneles { grid-template-columns: 1fr; } .tarjeta { padding: 22px; } }
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-03-sistema-examen-lista-oficial/templates/index.html" <<'FIN_CODIGO_INTERFACES'
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{{ titulo }} · Práctica {{ numero }}</title>
  <link rel="stylesheet" href="{{ url_for('static', filename='estilos.css') }}">
  <script src="{{ url_for('static', filename='app.js') }}" defer></script>
</head>
<body>
<main data-numero="{{ numero }}">
  <header><a class="marca" href="{{ url_for('inicio') }}"><span>IA</span> Fundamentos de IA</a><span class="etiqueta">PRÁCTICA {{ '%02d'|format(numero) }}</span></header>
  <section class="introduccion"><p class="supertitulo">APRENDER HACIENDO</p><h1>{{ titulo }}</h1><p>{{ descripcion }}</p></section>
  <div class="paneles">
    <section class="tarjeta captura"><div class="titulo-panel"><span class="paso">01</span><h2>{{ 'Explorar' if not grupos else 'Ingresa los datos' }}</h2></div>
      <form id="formulario" action="{{ url_for('procesar') }}" method="post">
        <input type="hidden" name="csrf" value="{{ session['csrf'] }}">
        {% for grupo in grupos %}<fieldset><legend>{{ grupo.titulo }}</legend><div class="campos">
          {% for campo in grupo.campos %}<div class="campo"><label for="{{ campo.clave }}">{{ campo.etiqueta }}</label>
            {% if campo.tipo == 'booleano' %}
            <select id="{{ campo.clave }}" name="{{ campo.clave }}" required><option value="">Selecciona una respuesta</option><option value="si">Sí</option><option value="no">No</option></select>
            {% elif campo.tipo == 'opcion' %}
            <select id="{{ campo.clave }}" name="{{ campo.clave }}" required><option value="">Selecciona una opción</option>{% for clave, etiqueta in campo.opciones.items() %}<option value="{{ clave }}">{{ etiqueta }}</option>{% endfor %}</select>
            {% else %}
            <input id="{{ campo.clave }}" name="{{ campo.clave }}" type="text" {% if campo.tipo == 'numero' %}inputmode="decimal"{% endif %} required autocomplete="off">
            {% endif %}
          </div>{% endfor %}
        </div></fieldset>{% else %}<p class="ayuda">Compara las cuatro combinaciones de P y Q y el resultado de cada operación lógica.</p>{% endfor %}
        <div class="acciones"><button type="submit" id="evaluar">{{ boton }} <span aria-hidden="true">→</span></button>{% if grupos %}<button type="reset" class="secundario">Limpiar</button>{% endif %}</div>
      </form>
      <p id="error" class="error" role="alert" hidden></p>
    </section>
    <section class="tarjeta salida" aria-labelledby="titulo-resultado">
      <div class="titulo-panel"><span class="paso">02</span><h2 id="titulo-resultado">Resultado</h2></div>
      <p id="espera" class="vacio">{{ 'La tabla se mostrará aquí.' if not grupos else 'Completa el formulario para ver el resultado.' }}</p>
      <div id="resultado" aria-live="polite" hidden><p id="nota-edicion" class="aviso" hidden>Modificaste el formulario. Vuelve a evaluar para actualizar este resultado.</p><h3 id="diagnostico"></h3><div id="mensajes"></div><div id="tablas"></div><button id="descargar" class="secundario" type="button" hidden>Descargar reporte TXT</button></div>
    </section>
  </div>
  <footer>Práctica {{ numero }} · Python y una interfaz para aprender</footer>
</main>
</body>
</html>
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-04-diagnostico-equipo/04_diagnostico_equipo.py" <<'FIN_CODIGO_INTERFACES'
"""Práctica 4: interfaz independiente; reglas originales conservadas."""

TIPOS_EQUIPO = ("pc", "laptop", "servidor", "tablet")

def diagnosticar_equipo(electricidad: bool, enciende: bool, imagen: bool) -> str:
    """Aplicar la primera condición que corresponda, en el orden original."""
    if not electricidad:
        return "El equipo NO recibe electricidad."
    if not enciende:
        return "El equipo tiene electricidad, pero NO enciende."
    if not imagen:
        return "El equipo enciende, pero NO muestra imagen."
    return "El equipo funciona correctamente."

NUMERO = 4
PUERTO = 5104
TITULO = 'Diagnóstico de equipo'
DESCRIPCION = 'Evalúa electricidad, encendido, imagen y presencia de daños físicos.'
GRUPOS = [{'titulo': 'Equipo',
  'campos': [{'clave': 'modelo', 'etiqueta': 'Modelo del equipo', 'tipo': 'texto'},
             {'clave': 'tipo_equipo',
              'etiqueta': 'Tipo de equipo',
              'tipo': 'opcion',
              'opciones': {'pc': 'PC',
                           'laptop': 'Laptop',
                           'servidor': 'Servidor',
                           'tablet': 'Tablet'}}]},
 {'titulo': 'Estado del equipo',
  'campos': [{'clave': 'electricidad',
              'etiqueta': '¿Tiene electricidad?',
              'tipo': 'booleano'},
             {'clave': 'enciende', 'etiqueta': '¿Enciende?', 'tipo': 'booleano'},
             {'clave': 'imagen', 'etiqueta': '¿Muestra imagen?', 'tipo': 'booleano'},
             {'clave': 'golpes', 'etiqueta': '¿Recibió golpes?', 'tipo': 'booleano'},
             {'clave': 'agua', 'etiqueta': '¿Le cayó agua?', 'tipo': 'booleano'},
             {'clave': 'otro_dano',
              'etiqueta': '¿Tiene otro daño visible?',
              'tipo': 'booleano'}]}]
BOTON = 'Diagnosticar equipo'


def evaluar(datos):
    diagnostico = diagnosticar_equipo(datos["electricidad"], datos["enciende"], datos["imagen"])
    dano = datos["golpes"] or datos["agua"] or datos["otro_dano"]
    mensajes = [f"Equipo: {datos['modelo']} ({datos['tipo_equipo']})"]
    if dano:
        mensajes.append("También se detectó daño físico.")
    correcto = datos["electricidad"] and datos["enciende"] and datos["imagen"] and not dano
    return {"titulo": diagnostico, "clase": "positivo" if correcto else "aviso", "mensajes": mensajes, "tablas": []}


from pathlib import Path
import secrets
from math import isfinite
from flask import Flask, jsonify, render_template, request, session

def leer_formulario(formulario):
    datos = {}
    for grupo in GRUPOS:
        for campo in grupo["campos"]:
            clave = campo["clave"]
            valor = formulario.get(clave, "").strip()
            if not valor:
                raise ValueError(f"Completa el campo: {campo['etiqueta']}.")
            if campo["tipo"] == "booleano":
                if valor not in ("si", "no"):
                    raise ValueError(f"Selecciona Sí o No en: {campo['etiqueta']}.")
                datos[clave] = valor == "si"
            elif campo["tipo"] == "numero":
                try:
                    numero = float(valor)
                except ValueError:
                    raise ValueError(f"Ingresa un número válido en: {campo['etiqueta']}.") from None
                if not isfinite(numero):
                    raise ValueError(f"El número de {campo['etiqueta']} debe ser finito.")
                datos[clave] = numero
            elif campo["tipo"] == "opcion":
                if valor not in campo["opciones"]:
                    raise ValueError(f"Selecciona una opción válida en: {campo['etiqueta']}.")
                datos[clave] = valor
            else:
                datos[clave] = valor
    return datos

def crear_app():
    raiz = Path(__file__).resolve().parent
    app = Flask(__name__, template_folder=str(raiz / "templates"), static_folder=str(raiz / "static"))
    app.config.update(SECRET_KEY=secrets.token_hex(32), SESSION_COOKIE_HTTPONLY=True,
                      SESSION_COOKIE_SAMESITE="Strict", MAX_CONTENT_LENGTH=131072)

    @app.after_request
    def proteger(respuesta):
        respuesta.headers["Cache-Control"] = "no-store"
        respuesta.headers["X-Content-Type-Options"] = "nosniff"
        respuesta.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'"
        return respuesta

    @app.get("/")
    def inicio():
        session.setdefault("csrf", secrets.token_hex(32))
        return render_template("index.html", numero=NUMERO, titulo=TITULO, descripcion=DESCRIPCION, grupos=GRUPOS, boton=BOTON)

    @app.post("/evaluar")
    def procesar():
        token = request.form.get("csrf", "")
        if not token or not secrets.compare_digest(token.encode(), session.get("csrf", "").encode()):
            return jsonify(ok=False, mensaje="El formulario expiró. Recarga la página."), 400
        try:
            datos = leer_formulario(request.form)
        except ValueError as error:
            return jsonify(ok=False, mensaje=str(error)), 400
        return jsonify(ok=True, resultado=evaluar(datos))

    @app.errorhandler(413)
    def demasiado_grande(error):
        return jsonify(ok=False, mensaje="El formulario es demasiado grande. Reduce el texto e inténtalo de nuevo."), 413

    return app

if __name__ == "__main__":
    print(f"Abre http://localhost:{PUERTO} en tu navegador. Detén el servidor con Ctrl+C.")
    crear_app().run(host="127.0.0.1", port=PUERTO, debug=False)
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-04-diagnostico-equipo/README.md" <<'FIN_CODIGO_INTERFACES'
# Práctica 4: Diagnóstico de equipo

Evalúa electricidad, encendido, imagen y presencia de daños físicos.

Desde la raíz del proyecto:

```bash
bash unidad-01-introduccion-ia/practicas/practica-04-diagnostico-equipo/ejecutar.sh
```

Abre http://localhost:5104. Detén el servidor con Ctrl+C.

Programa independiente: todo el código, HTML, CSS y JavaScript está en esta carpeta.
Las funciones de las reglas se conservan del programa optimizado. Los campos
se validan en Python. Los resultados no se guardan en una base de datos.

Flask devuelve JSON; JavaScript muestra texto sin interpretarlo como HTML.
La práctica 5 permite descargar su reporte en TXT.
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-04-diagnostico-equipo/ejecutar.sh" <<'FIN_CODIGO_INTERFACES'
#!/usr/bin/env bash
set -euo pipefail
directorio="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
proyecto="$(cd -- "$directorio/../../.." && pwd)"
exec "$proyecto/.venv/bin/python" "$directorio/04_diagnostico_equipo.py"
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-04-diagnostico-equipo/requirements.txt" <<'FIN_CODIGO_INTERFACES'
Flask>=3.1,<4
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-04-diagnostico-equipo/static/app.js" <<'FIN_CODIGO_INTERFACES'
"use strict";
const formulario = document.querySelector("#formulario");
const boton = document.querySelector("#evaluar");
const error = document.querySelector("#error");
const resultado = document.querySelector("#resultado");
let reporte = "";
let solicitud = 0;
let edicion = 0;

function mostrar(datos) {
  resultado.hidden = false;
  document.querySelector("#espera").hidden = true;
  document.querySelector("#nota-edicion").hidden = true;
  const titulo = document.querySelector("#diagnostico");
  titulo.textContent = datos.titulo;
  titulo.className = datos.clase || "neutral";
  const mensajes = document.querySelector("#mensajes");
  mensajes.replaceChildren();
  for (const texto of datos.mensajes || []) {
    const p = document.createElement("p"); p.textContent = texto; mensajes.append(p);
  }
  const tablas = document.querySelector("#tablas"); tablas.replaceChildren();
  for (const contenido of datos.tablas || []) {
    const bloque = document.createElement("section");
    const nombre = document.createElement("h4"); nombre.textContent = contenido.titulo; bloque.append(nombre);
    const envoltura = document.createElement("div"); envoltura.className = "tabla";
    const tabla = document.createElement("table");
    const cabecera = document.createElement("thead"); const fila = document.createElement("tr");
    for (const etiqueta of contenido.encabezados) {
      const celda = document.createElement("th"); celda.scope = "col"; celda.textContent = etiqueta; fila.append(celda);
    }
    cabecera.append(fila); tabla.append(cabecera);
    const cuerpo = document.createElement("tbody");
    for (const valores of contenido.filas) {
      const fila = document.createElement("tr");
      for (const valor of valores) {
        const celda = document.createElement("td"); celda.textContent = valor; fila.append(celda);
      }
      cuerpo.append(fila);
    }
    tabla.append(cuerpo); envoltura.append(tabla); bloque.append(envoltura); tablas.append(bloque);
  }
  reporte = datos.reporte || "";
  document.querySelector("#descargar").hidden = !reporte;
}

formulario.addEventListener("submit", async (evento) => {
  evento.preventDefault();
  const actual = ++solicitud;
  const edicionEnviada = edicion;
  boton.disabled = true; formulario.setAttribute("aria-busy", "true"); error.hidden = true;
  try {
    const respuesta = await fetch(formulario.action, { method: "POST", body: new FormData(formulario), credentials: "same-origin" });
    const datos = await respuesta.json();
    if (actual !== solicitud) return;
    if (!respuesta.ok || !datos.ok) throw new Error(datos.mensaje || "No se pudo evaluar el formulario.");
    mostrar(datos.resultado);
    document.querySelector("#nota-edicion").hidden = edicion === edicionEnviada;
  } catch (fallo) {
    if (actual !== solicitud) return;
    error.textContent = fallo instanceof TypeError ? "No se pudo contactar con Python. Comprueba la terminal del servidor." : fallo.message;
    error.hidden = false;
  } finally {
    if (actual === solicitud) { boton.disabled = false; formulario.setAttribute("aria-busy", "false"); }
  }
});
formulario.addEventListener("input", () => {
  edicion++;
  if (!resultado.hidden) document.querySelector("#nota-edicion").hidden = false;
});
formulario.addEventListener("reset", () => {
  solicitud++; boton.disabled = false; formulario.setAttribute("aria-busy", "false");
  resultado.hidden = true; document.querySelector("#espera").hidden = false; error.hidden = true; reporte = "";
});
document.querySelector("#descargar").addEventListener("click", () => {
  const url = URL.createObjectURL(new Blob([reporte], {type: "text/plain;charset=utf-8"}));
  const enlace = document.createElement("a"); enlace.href = url; enlace.download = "reporte_diagnostico.txt"; enlace.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});
if (document.querySelector("main").dataset.numero === "1") formulario.requestSubmit();
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-04-diagnostico-equipo/static/estilos.css" <<'FIN_CODIGO_INTERFACES'

:root { font-family: "Segoe UI", system-ui, sans-serif; color: #25354a; background: #f4f6fa; line-height: 1.5; }
* { box-sizing: border-box; } body { margin: 0; } [hidden] { display: none !important; }
main { max-width: 1240px; margin: auto; padding: 26px 30px; }
header { display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid #dce3ed; padding-bottom: 22px; gap: 15px; }
.marca { display: flex; align-items: center; gap: 10px; font-size: 13px; font-weight: 650; text-decoration: none; color: #405675; }
.marca span { display: grid; place-items: center; width: 38px; height: 38px; border-radius: 10px; background: #315c91; color: white; }
.etiqueta { font-size: 11px; letter-spacing: 1px; color: #5b7394; border: 1px solid #c9d5e5; border-radius: 30px; padding: 6px 12px; }
.introduccion { padding: 31px 0; } .supertitulo { font-size: 10px; letter-spacing: 2px; font-weight: 700; color: #6585ac; }
h1 { font-size: clamp(28px, 3vw, 40px); line-height: 1.18; letter-spacing: -1px; margin: 9px 0 12px; }
.introduccion > p:last-child { color: #687d95; font-size: 14px; max-width: 830px; margin-bottom: 0; }
.paneles { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1.05fr); align-items: start; gap: 25px; }
.tarjeta { padding: 26px; border: 1px solid #dce4ed; border-radius: 15px; background: white; box-shadow: 0 4px 14px #273c5506; }
.titulo-panel { display: flex; align-items: center; gap: 10px; margin-bottom: 23px; } .paso { font-size: 11px; padding: 5px 7px; border-radius: 7px; color: #506c99; background: #edf2fb; }
h2 { font-size: 19px; margin: 0; letter-spacing: -.4px; } h3 { font-size: 19px; line-height: 1.5; margin: 0 0 16px; padding: 16px; border-radius: 9px; }
h4 { font-size: 13px; margin: 23px 0 10px; color: #4f6787; }
fieldset { border: 0; padding: 0; margin: 0 0 24px; } legend { font-size: 12px; color: #657b96; font-weight: 650; padding: 0 0 12px; }
.campos { display: grid; gap: 16px; } label { display: block; font-size: 13px; font-weight: 550; margin-bottom: 7px; }
input, select { width: 100%; font: inherit; font-size: 13px; color: #304561; padding: 11px 12px; background: #fafbfd; border: 1px solid #c4d2e1; border-radius: 7px; }
input:focus-visible, select:focus-visible, button:focus-visible, a:focus-visible { outline: 3px solid #a3c4eb; outline-offset: 3px; }
.acciones { display: flex; gap: 10px; flex-wrap: wrap; } button { border: 0; font: inherit; font-size: 12px; font-weight: 650; color: white; background: #315c91; padding: 12px 17px; border-radius: 8px; cursor: pointer; }
#evaluar { flex: 1; display: flex; align-items: center; justify-content: space-between; gap: 20px; } button:hover { background: #244c7e; } button:disabled { opacity: .6; cursor: wait; }
.secundario { background: #f0f4f9; color: #4f6d96; border: 1px solid #d4dfed; } .secundario:hover { background: #e5edf8; }
.vacio { padding: 45px 24px; text-align: center; background: #fafbfd; border: 1px dashed #ced9e6; border-radius: 10px; color: #788ca3; font-size: 13px; }
.positivo { background: #eaf5ee; color: #286345; } .aviso { background: #fff5e8; color: #91682e; } .neutral { background: #edf3fc; color: #385b8a; }
.error { color: #923c32; background: #ffefeb; padding: 12px; border-radius: 8px; font-size: 13px; }
#nota-edicion { padding: 12px; font-size: 12px; border-radius: 7px; } #mensajes p { font-size: 13px; color: #5c728b; white-space: pre-wrap; }
.tabla { overflow-x: auto; } table { width: 100%; border-collapse: collapse; font-size: 12px; } th { background: #eef3f9; color: #527197; text-align: left; padding: 10px; white-space: nowrap; } td { padding: 11px 10px; border-bottom: 1px solid #e5ebf2; vertical-align: top; overflow-wrap: anywhere; }
#descargar { margin-top: 22px; } footer { font-size: 10px; color: #8496ac; text-align: center; padding-top: 27px; }
@media(max-width: 850px) { main { padding: 20px 16px; } .paneles { grid-template-columns: 1fr; } .tarjeta { padding: 22px; } }
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-04-diagnostico-equipo/templates/index.html" <<'FIN_CODIGO_INTERFACES'
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{{ titulo }} · Práctica {{ numero }}</title>
  <link rel="stylesheet" href="{{ url_for('static', filename='estilos.css') }}">
  <script src="{{ url_for('static', filename='app.js') }}" defer></script>
</head>
<body>
<main data-numero="{{ numero }}">
  <header><a class="marca" href="{{ url_for('inicio') }}"><span>IA</span> Fundamentos de IA</a><span class="etiqueta">PRÁCTICA {{ '%02d'|format(numero) }}</span></header>
  <section class="introduccion"><p class="supertitulo">APRENDER HACIENDO</p><h1>{{ titulo }}</h1><p>{{ descripcion }}</p></section>
  <div class="paneles">
    <section class="tarjeta captura"><div class="titulo-panel"><span class="paso">01</span><h2>{{ 'Explorar' if not grupos else 'Ingresa los datos' }}</h2></div>
      <form id="formulario" action="{{ url_for('procesar') }}" method="post">
        <input type="hidden" name="csrf" value="{{ session['csrf'] }}">
        {% for grupo in grupos %}<fieldset><legend>{{ grupo.titulo }}</legend><div class="campos">
          {% for campo in grupo.campos %}<div class="campo"><label for="{{ campo.clave }}">{{ campo.etiqueta }}</label>
            {% if campo.tipo == 'booleano' %}
            <select id="{{ campo.clave }}" name="{{ campo.clave }}" required><option value="">Selecciona una respuesta</option><option value="si">Sí</option><option value="no">No</option></select>
            {% elif campo.tipo == 'opcion' %}
            <select id="{{ campo.clave }}" name="{{ campo.clave }}" required><option value="">Selecciona una opción</option>{% for clave, etiqueta in campo.opciones.items() %}<option value="{{ clave }}">{{ etiqueta }}</option>{% endfor %}</select>
            {% else %}
            <input id="{{ campo.clave }}" name="{{ campo.clave }}" type="text" {% if campo.tipo == 'numero' %}inputmode="decimal"{% endif %} required autocomplete="off">
            {% endif %}
          </div>{% endfor %}
        </div></fieldset>{% else %}<p class="ayuda">Compara las cuatro combinaciones de P y Q y el resultado de cada operación lógica.</p>{% endfor %}
        <div class="acciones"><button type="submit" id="evaluar">{{ boton }} <span aria-hidden="true">→</span></button>{% if grupos %}<button type="reset" class="secundario">Limpiar</button>{% endif %}</div>
      </form>
      <p id="error" class="error" role="alert" hidden></p>
    </section>
    <section class="tarjeta salida" aria-labelledby="titulo-resultado">
      <div class="titulo-panel"><span class="paso">02</span><h2 id="titulo-resultado">Resultado</h2></div>
      <p id="espera" class="vacio">{{ 'La tabla se mostrará aquí.' if not grupos else 'Completa el formulario para ver el resultado.' }}</p>
      <div id="resultado" aria-live="polite" hidden><p id="nota-edicion" class="aviso" hidden>Modificaste el formulario. Vuelve a evaluar para actualizar este resultado.</p><h3 id="diagnostico"></h3><div id="mensajes"></div><div id="tablas"></div><button id="descargar" class="secundario" type="button" hidden>Descargar reporte TXT</button></div>
    </section>
  </div>
  <footer>Práctica {{ numero }} · Python y una interfaz para aprender</footer>
</main>
</body>
</html>
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-05-diagnostico-equipo-reporte/05_diagnostico_equipo_reporte.py" <<'FIN_CODIGO_INTERFACES'
"""Práctica 5: interfaz independiente; reglas originales conservadas."""

import random

from dataclasses import dataclass

from datetime import datetime

TIPOS_EQUIPO = {"pc": "PC", "laptop": "Laptop", "servidor": "Servidor", "tablet": "Tablet"}

TIPOS_DISCO = {
    "hdd": "Disco duro HDD",
    "ssd": "Disco de estado sólido SSD",
    "otro": "Otro tipo de almacenamiento",
}

PROCESADORES = {"intel": "Intel", "amd": "AMD", "arm": "ARM", "otro": "Otro"}

PREGUNTAS = (
    ("electricidad", "P", "¿El equipo tiene electricidad?", "Tiene electricidad"),
    ("enciende", "Q", "¿El equipo enciende?", "Enciende"),
    ("imagen", "R", "¿El equipo muestra imagen?", "Muestra imagen"),
    ("sistema_inicia", "S", "¿El sistema operativo inicia correctamente?", "Inicia sistema operativo"),
    ("se_reinicia", "T", "¿El equipo se reinicia o apaga solo?", "Se reinicia solo"),
    ("sobrecalentamiento", "U", "¿El equipo se calienta demasiado?", "Sobrecalentamiento"),
    ("ruido", "V", "¿El equipo hace ruidos extraños?", "Ruidos extraños"),
    ("lento", "W", "¿El equipo funciona muy lento?", "Funciona lento"),
    ("internet", "X", "¿El equipo puede conectarse a Internet?", "Tiene Internet"),
    ("usb", "Y", "¿Los puertos USB funcionan correctamente?", "USB funciona"),
    ("audio", "Z", "¿El equipo reproduce sonido correctamente?", "Audio funciona"),
    ("golpes", "", "¿El equipo recibió golpes?", "Recibió golpes"),
    ("agua", "", "¿Al equipo le cayó agua?", "Tuvo contacto con agua"),
    ("otro_dano", "", "¿El equipo tiene algún otro daño visible?", "Otro daño visible"),
)

OBSERVACIONES = (
    ("se_reinicia", True, "El equipo se reinicia o apaga solo.",
     "Puede estar relacionado con temperatura, energía o componentes internos."),
    ("sobrecalentamiento", True, "El equipo presenta sobrecalentamiento.",
     "Revisar ventilación, ventiladores y mantenimiento."),
    ("ruido", True, "El equipo presenta ruidos extraños.",
     "Revisar ventiladores o unidades de almacenamiento."),
    ("lento", True, "El equipo presenta lentitud.",
     "Revisar memoria RAM, almacenamiento y funcionamiento del sistema."),
    ("internet", False, "El equipo no tiene conexión a Internet.",
     "Revisar Wi-Fi, cable de red o configuración de red."),
    ("usb", False, "Los puertos USB presentan problemas.", ""),
    ("audio", False, "El sistema de audio presenta problemas.", ""),
    ("golpes", True, "El equipo recibió golpes.", ""),
    ("agua", True, "El equipo tuvo contacto con agua.", ""),
    ("otro_dano", True, "El equipo presenta otro daño físico visible.", ""),
)

@dataclass(frozen=True)
class Evaluacion:
    funcionamiento_basico: bool
    dano_fisico: bool
    respuestas_consistentes: bool
    equipo_correcto: bool
    diagnostico: str
    recomendacion: str
    observaciones: tuple[tuple[str, str], ...]

def si_no(valor: bool) -> str:
    return "Sí" if valor else "No"

def evaluar_equipo(estado: dict[str, bool]) -> Evaluacion:
    p = estado["electricidad"]
    q = estado["enciende"]
    r = estado["imagen"]
    s = estado["sistema_inicia"]

    # Estas implicaciones se utilizaban sin estar definidas en el original.
    q_implica_p = (not q) or p
    r_implica_q = (not r) or q
    sistema_consistente = (not s) or (q and r)
    consistentes = q_implica_p and r_implica_q and sistema_consistente
    dano_fisico = estado["golpes"] or estado["agua"] or estado["otro_dano"]

    if not consistentes:
        diagnostico = "Las respuestas proporcionadas son contradictorias."
        recomendacion = "Revisa las respuestas proporcionadas e intenta nuevamente."
    elif not p:
        diagnostico = "El equipo NO recibe electricidad."
        recomendacion = "Revisar cable de corriente, cargador, fuente de poder o conexión eléctrica."
    elif not q:
        diagnostico = "El equipo recibe electricidad, pero NO enciende."
        recomendacion = "Posible problema de fuente de poder, batería o componentes internos."
    elif not r:
        diagnostico = "El equipo enciende, pero NO muestra imagen."
        recomendacion = "Revisar monitor, pantalla, cable de video o componentes de video."
    elif not s:
        diagnostico = "El equipo enciende y muestra imagen, pero el sistema operativo NO inicia."
        recomendacion = "Posible problema del sistema operativo o almacenamiento."
    else:
        diagnostico = "El funcionamiento básico es correcto."
        recomendacion = ""

    sin_fallas_adicionales = (
        not estado["se_reinicia"]
        and not estado["sobrecalentamiento"]
        and not estado["ruido"]
        and not estado["lento"]
        and estado["internet"]
        and estado["usb"]
        and estado["audio"]
        and not dano_fisico
    )
    observaciones = tuple(
        (texto, orientacion)
        for clave, valor, texto, orientacion in OBSERVACIONES
        if estado[clave] == valor
    )
    return Evaluacion(
        funcionamiento_basico=p and q and r,
        dano_fisico=dano_fisico,
        respuestas_consistentes=consistentes,
        equipo_correcto=p and q and r and s and sin_fallas_adicionales,
        diagnostico=diagnostico,
        recomendacion=recomendacion,
        observaciones=observaciones,
    )

def generar_reporte(
    datos: dict[str, str],
    estado: dict[str, bool],
    folio: str,
    fecha: datetime,
) -> str:
    evaluacion = evaluar_equipo(estado)
    lineas = [
        "",
        "=" * 60,
        "REPORTE DE DIAGNÓSTICO",
        "=" * 60,
        f"Número de reporte: {folio}",
        f"Fecha: {fecha:%d/%m/%Y}",
        f"Hora: {fecha:%H:%M:%S}",
        "",
        "DATOS DEL USUARIO Y DEL EQUIPO",
    ]
    lineas.extend(f"{etiqueta}: {valor}" for etiqueta, valor in datos.items())
    lineas.extend(["", "ESTADO DEL EQUIPO"])
    lineas.extend(
        f"{etiqueta}: {si_no(estado[clave])}"
        for clave, _, _, etiqueta in PREGUNTAS
    )
    lineas.extend(["", "VALORES DE LAS PROPOSICIONES"])
    lineas.extend(
        f"{simbolo} - {etiqueta}: {estado[clave]}"
        for clave, simbolo, _, etiqueta in PREGUNTAS
        if simbolo
    )
    lineas.extend([
        f"P ∧ Q ∧ R = {evaluacion.funcionamiento_basico}",
        f"Golpe ∨ Agua ∨ Otro daño = {evaluacion.dano_fisico}",
        f"Respuestas consistentes: {si_no(evaluacion.respuestas_consistentes)}",
        "",
        "RESULTADO DEL DIAGNÓSTICO",
        "ESTADO: EQUIPO FUNCIONANDO CORRECTAMENTE"
        if evaluacion.equipo_correcto else "ESTADO: EQUIPO CON FALLAS",
        f"Diagnóstico: {evaluacion.diagnostico}",
    ])
    if evaluacion.recomendacion:
        lineas.append(evaluacion.recomendacion)
    lineas.extend(["", "OBSERVACIONES"])
    for texto, orientacion in evaluacion.observaciones:
        lineas.append(f"- {texto}")
        if orientacion:
            lineas.append(f"  {orientacion}")
    lineas.extend(["", f"Número de reporte: {folio}", "FIN DEL REPORTE"])
    return "\n".join(lineas)

NUMERO = 5
PUERTO = 5105
TITULO = 'Diagnóstico con reporte'
DESCRIPCION = 'Captura los datos del equipo y genera un reporte con folio, fecha, diagnóstico y observaciones.'
GRUPOS = [{'titulo': 'Datos del usuario',
  'campos': [{'clave': 'usuario', 'etiqueta': 'Nombre de usuario', 'tipo': 'texto'},
             {'clave': 'nombre', 'etiqueta': 'Nombre completo', 'tipo': 'texto'},
             {'clave': 'direccion', 'etiqueta': 'Dirección', 'tipo': 'texto'}]},
 {'titulo': 'Datos del equipo',
  'campos': [{'clave': 'modelo', 'etiqueta': 'Modelo', 'tipo': 'texto'},
             {'clave': 'tipo',
              'etiqueta': 'Tipo de equipo',
              'tipo': 'opcion',
              'opciones': {'pc': 'PC',
                           'laptop': 'Laptop',
                           'servidor': 'Servidor',
                           'tablet': 'Tablet'}},
             {'clave': 'antiguedad', 'etiqueta': 'Antigüedad en años', 'tipo': 'numero'},
             {'clave': 'ram', 'etiqueta': 'Memoria RAM en GB', 'tipo': 'numero'},
             {'clave': 'almacenamiento',
              'etiqueta': 'Almacenamiento en GB',
              'tipo': 'numero'},
             {'clave': 'disco',
              'etiqueta': 'Tipo de almacenamiento',
              'tipo': 'opcion',
              'opciones': {'hdd': 'Disco duro HDD',
                           'ssd': 'Disco de estado sólido SSD',
                           'otro': 'Otro tipo de almacenamiento'}},
             {'clave': 'procesador',
              'etiqueta': 'Marca de procesador',
              'tipo': 'opcion',
              'opciones': {'intel': 'Intel', 'amd': 'AMD', 'arm': 'ARM', 'otro': 'Otro'}},
             {'clave': 'sistema_operativo',
              'etiqueta': 'Sistema operativo',
              'tipo': 'texto'},
             {'clave': 'garantia',
              'etiqueta': '¿Tiene garantía vigente?',
              'tipo': 'booleano'},
             {'clave': 'mantenimiento',
              'etiqueta': '¿Ha recibido mantenimiento?',
              'tipo': 'booleano'}]},
 {'titulo': 'Funcionamiento y daños',
  'campos': [{'clave': 'electricidad',
              'etiqueta': '¿El equipo tiene electricidad?',
              'tipo': 'booleano'},
             {'clave': 'enciende',
              'etiqueta': '¿El equipo enciende?',
              'tipo': 'booleano'},
             {'clave': 'imagen',
              'etiqueta': '¿El equipo muestra imagen?',
              'tipo': 'booleano'},
             {'clave': 'sistema_inicia',
              'etiqueta': '¿El sistema operativo inicia correctamente?',
              'tipo': 'booleano'},
             {'clave': 'se_reinicia',
              'etiqueta': '¿El equipo se reinicia o apaga solo?',
              'tipo': 'booleano'},
             {'clave': 'sobrecalentamiento',
              'etiqueta': '¿El equipo se calienta demasiado?',
              'tipo': 'booleano'},
             {'clave': 'ruido',
              'etiqueta': '¿El equipo hace ruidos extraños?',
              'tipo': 'booleano'},
             {'clave': 'lento',
              'etiqueta': '¿El equipo funciona muy lento?',
              'tipo': 'booleano'},
             {'clave': 'internet',
              'etiqueta': '¿El equipo puede conectarse a Internet?',
              'tipo': 'booleano'},
             {'clave': 'usb',
              'etiqueta': '¿Los puertos USB funcionan correctamente?',
              'tipo': 'booleano'},
             {'clave': 'audio',
              'etiqueta': '¿El equipo reproduce sonido correctamente?',
              'tipo': 'booleano'},
             {'clave': 'golpes',
              'etiqueta': '¿El equipo recibió golpes?',
              'tipo': 'booleano'},
             {'clave': 'agua',
              'etiqueta': '¿Al equipo le cayó agua?',
              'tipo': 'booleano'},
             {'clave': 'otro_dano',
              'etiqueta': '¿El equipo tiene algún otro daño visible?',
              'tipo': 'booleano'}]}]
BOTON = 'Generar reporte'


def evaluar(datos):
    informacion = {
        "Usuario": datos["usuario"], "Nombre": datos["nombre"], "Dirección": datos["direccion"],
        "Modelo": datos["modelo"], "Tipo": TIPOS_EQUIPO[datos["tipo"]],
        "Antigüedad": f"{datos['antiguedad']} años", "RAM": f"{datos['ram']} GB",
        "Almacenamiento": f"{datos['almacenamiento']} GB", "Disco": TIPOS_DISCO[datos["disco"]],
        "Procesador": PROCESADORES[datos["procesador"]], "Sistema operativo": datos["sistema_operativo"],
        "Garantía": si_no(datos["garantia"]), "Mantenimiento": si_no(datos["mantenimiento"]),
    }
    estado = {clave: datos[clave] for clave, _, _, _ in PREGUNTAS}
    evaluacion = evaluar_equipo(estado)
    folio = f"REP-{random.randint(1000, 9999)}"
    fecha = datetime.now()
    mensajes = [f"Reporte: {folio} · {fecha:%d/%m/%Y %H:%M:%S}",
                "ESTADO: EQUIPO FUNCIONANDO CORRECTAMENTE" if evaluacion.equipo_correcto else "ESTADO: EQUIPO CON FALLAS"]
    if evaluacion.recomendacion:
        mensajes.append(evaluacion.recomendacion)
    proposiciones = [[f"{simbolo} · {etiqueta}", str(estado[clave])] for clave, simbolo, _, etiqueta in PREGUNTAS if simbolo]
    proposiciones.extend([["P ∧ Q ∧ R", str(evaluacion.funcionamiento_basico)],
                          ["Golpe ∨ Agua ∨ Otro daño", str(evaluacion.dano_fisico)],
                          ["Respuestas consistentes", si_no(evaluacion.respuestas_consistentes)]])
    tablas = [
        {"titulo": "Usuario y equipo", "encabezados": ["Dato", "Valor"], "filas": list(informacion.items())},
        {"titulo": "Estado del equipo", "encabezados": ["Pregunta", "Respuesta"], "filas": [[etiqueta, si_no(estado[clave])] for clave, _, _, etiqueta in PREGUNTAS]},
        {"titulo": "Proposiciones", "encabezados": ["Proposición", "Valor"], "filas": proposiciones},
    ]
    if evaluacion.observaciones:
        tablas.append({"titulo": "Observaciones", "encabezados": ["Observación", "Orientación"], "filas": list(evaluacion.observaciones)})
    return {"titulo": evaluacion.diagnostico, "clase": "positivo" if evaluacion.equipo_correcto else "aviso",
            "mensajes": mensajes, "tablas": tablas, "reporte": generar_reporte(informacion, estado, folio, fecha)}


from pathlib import Path
import secrets
from math import isfinite
from flask import Flask, jsonify, render_template, request, session

def leer_formulario(formulario):
    datos = {}
    for grupo in GRUPOS:
        for campo in grupo["campos"]:
            clave = campo["clave"]
            valor = formulario.get(clave, "").strip()
            if not valor:
                raise ValueError(f"Completa el campo: {campo['etiqueta']}.")
            if campo["tipo"] == "booleano":
                if valor not in ("si", "no"):
                    raise ValueError(f"Selecciona Sí o No en: {campo['etiqueta']}.")
                datos[clave] = valor == "si"
            elif campo["tipo"] == "numero":
                try:
                    numero = float(valor)
                except ValueError:
                    raise ValueError(f"Ingresa un número válido en: {campo['etiqueta']}.") from None
                if not isfinite(numero):
                    raise ValueError(f"El número de {campo['etiqueta']} debe ser finito.")
                datos[clave] = numero
            elif campo["tipo"] == "opcion":
                if valor not in campo["opciones"]:
                    raise ValueError(f"Selecciona una opción válida en: {campo['etiqueta']}.")
                datos[clave] = valor
            else:
                datos[clave] = valor
    return datos

def crear_app():
    raiz = Path(__file__).resolve().parent
    app = Flask(__name__, template_folder=str(raiz / "templates"), static_folder=str(raiz / "static"))
    app.config.update(SECRET_KEY=secrets.token_hex(32), SESSION_COOKIE_HTTPONLY=True,
                      SESSION_COOKIE_SAMESITE="Strict", MAX_CONTENT_LENGTH=131072)

    @app.after_request
    def proteger(respuesta):
        respuesta.headers["Cache-Control"] = "no-store"
        respuesta.headers["X-Content-Type-Options"] = "nosniff"
        respuesta.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'"
        return respuesta

    @app.get("/")
    def inicio():
        session.setdefault("csrf", secrets.token_hex(32))
        return render_template("index.html", numero=NUMERO, titulo=TITULO, descripcion=DESCRIPCION, grupos=GRUPOS, boton=BOTON)

    @app.post("/evaluar")
    def procesar():
        token = request.form.get("csrf", "")
        if not token or not secrets.compare_digest(token.encode(), session.get("csrf", "").encode()):
            return jsonify(ok=False, mensaje="El formulario expiró. Recarga la página."), 400
        try:
            datos = leer_formulario(request.form)
        except ValueError as error:
            return jsonify(ok=False, mensaje=str(error)), 400
        return jsonify(ok=True, resultado=evaluar(datos))

    @app.errorhandler(413)
    def demasiado_grande(error):
        return jsonify(ok=False, mensaje="El formulario es demasiado grande. Reduce el texto e inténtalo de nuevo."), 413

    return app

if __name__ == "__main__":
    print(f"Abre http://localhost:{PUERTO} en tu navegador. Detén el servidor con Ctrl+C.")
    crear_app().run(host="127.0.0.1", port=PUERTO, debug=False)
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-05-diagnostico-equipo-reporte/README.md" <<'FIN_CODIGO_INTERFACES'
# Práctica 5: Diagnóstico con reporte

Captura los datos del equipo y genera un reporte con folio, fecha, diagnóstico y observaciones.

Desde la raíz del proyecto:

```bash
bash unidad-01-introduccion-ia/practicas/practica-05-diagnostico-equipo-reporte/ejecutar.sh
```

Abre http://localhost:5105. Detén el servidor con Ctrl+C.

Programa independiente: todo el código, HTML, CSS y JavaScript está en esta carpeta.
Las funciones de las reglas se conservan del programa optimizado. Los campos
se validan en Python. Los resultados no se guardan en una base de datos.

Flask devuelve JSON; JavaScript muestra texto sin interpretarlo como HTML.
La práctica 5 permite descargar su reporte en TXT.
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-05-diagnostico-equipo-reporte/ejecutar.sh" <<'FIN_CODIGO_INTERFACES'
#!/usr/bin/env bash
set -euo pipefail
directorio="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
proyecto="$(cd -- "$directorio/../../.." && pwd)"
exec "$proyecto/.venv/bin/python" "$directorio/05_diagnostico_equipo_reporte.py"
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-05-diagnostico-equipo-reporte/requirements.txt" <<'FIN_CODIGO_INTERFACES'
Flask>=3.1,<4
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-05-diagnostico-equipo-reporte/static/app.js" <<'FIN_CODIGO_INTERFACES'
"use strict";
const formulario = document.querySelector("#formulario");
const boton = document.querySelector("#evaluar");
const error = document.querySelector("#error");
const resultado = document.querySelector("#resultado");
let reporte = "";
let solicitud = 0;
let edicion = 0;

function mostrar(datos) {
  resultado.hidden = false;
  document.querySelector("#espera").hidden = true;
  document.querySelector("#nota-edicion").hidden = true;
  const titulo = document.querySelector("#diagnostico");
  titulo.textContent = datos.titulo;
  titulo.className = datos.clase || "neutral";
  const mensajes = document.querySelector("#mensajes");
  mensajes.replaceChildren();
  for (const texto of datos.mensajes || []) {
    const p = document.createElement("p"); p.textContent = texto; mensajes.append(p);
  }
  const tablas = document.querySelector("#tablas"); tablas.replaceChildren();
  for (const contenido of datos.tablas || []) {
    const bloque = document.createElement("section");
    const nombre = document.createElement("h4"); nombre.textContent = contenido.titulo; bloque.append(nombre);
    const envoltura = document.createElement("div"); envoltura.className = "tabla";
    const tabla = document.createElement("table");
    const cabecera = document.createElement("thead"); const fila = document.createElement("tr");
    for (const etiqueta of contenido.encabezados) {
      const celda = document.createElement("th"); celda.scope = "col"; celda.textContent = etiqueta; fila.append(celda);
    }
    cabecera.append(fila); tabla.append(cabecera);
    const cuerpo = document.createElement("tbody");
    for (const valores of contenido.filas) {
      const fila = document.createElement("tr");
      for (const valor of valores) {
        const celda = document.createElement("td"); celda.textContent = valor; fila.append(celda);
      }
      cuerpo.append(fila);
    }
    tabla.append(cuerpo); envoltura.append(tabla); bloque.append(envoltura); tablas.append(bloque);
  }
  reporte = datos.reporte || "";
  document.querySelector("#descargar").hidden = !reporte;
}

formulario.addEventListener("submit", async (evento) => {
  evento.preventDefault();
  const actual = ++solicitud;
  const edicionEnviada = edicion;
  boton.disabled = true; formulario.setAttribute("aria-busy", "true"); error.hidden = true;
  try {
    const respuesta = await fetch(formulario.action, { method: "POST", body: new FormData(formulario), credentials: "same-origin" });
    const datos = await respuesta.json();
    if (actual !== solicitud) return;
    if (!respuesta.ok || !datos.ok) throw new Error(datos.mensaje || "No se pudo evaluar el formulario.");
    mostrar(datos.resultado);
    document.querySelector("#nota-edicion").hidden = edicion === edicionEnviada;
  } catch (fallo) {
    if (actual !== solicitud) return;
    error.textContent = fallo instanceof TypeError ? "No se pudo contactar con Python. Comprueba la terminal del servidor." : fallo.message;
    error.hidden = false;
  } finally {
    if (actual === solicitud) { boton.disabled = false; formulario.setAttribute("aria-busy", "false"); }
  }
});
formulario.addEventListener("input", () => {
  edicion++;
  if (!resultado.hidden) document.querySelector("#nota-edicion").hidden = false;
});
formulario.addEventListener("reset", () => {
  solicitud++; boton.disabled = false; formulario.setAttribute("aria-busy", "false");
  resultado.hidden = true; document.querySelector("#espera").hidden = false; error.hidden = true; reporte = "";
});
document.querySelector("#descargar").addEventListener("click", () => {
  const url = URL.createObjectURL(new Blob([reporte], {type: "text/plain;charset=utf-8"}));
  const enlace = document.createElement("a"); enlace.href = url; enlace.download = "reporte_diagnostico.txt"; enlace.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});
if (document.querySelector("main").dataset.numero === "1") formulario.requestSubmit();
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-05-diagnostico-equipo-reporte/static/estilos.css" <<'FIN_CODIGO_INTERFACES'

:root { font-family: "Segoe UI", system-ui, sans-serif; color: #25354a; background: #f4f6fa; line-height: 1.5; }
* { box-sizing: border-box; } body { margin: 0; } [hidden] { display: none !important; }
main { max-width: 1240px; margin: auto; padding: 26px 30px; }
header { display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid #dce3ed; padding-bottom: 22px; gap: 15px; }
.marca { display: flex; align-items: center; gap: 10px; font-size: 13px; font-weight: 650; text-decoration: none; color: #405675; }
.marca span { display: grid; place-items: center; width: 38px; height: 38px; border-radius: 10px; background: #315c91; color: white; }
.etiqueta { font-size: 11px; letter-spacing: 1px; color: #5b7394; border: 1px solid #c9d5e5; border-radius: 30px; padding: 6px 12px; }
.introduccion { padding: 31px 0; } .supertitulo { font-size: 10px; letter-spacing: 2px; font-weight: 700; color: #6585ac; }
h1 { font-size: clamp(28px, 3vw, 40px); line-height: 1.18; letter-spacing: -1px; margin: 9px 0 12px; }
.introduccion > p:last-child { color: #687d95; font-size: 14px; max-width: 830px; margin-bottom: 0; }
.paneles { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1.05fr); align-items: start; gap: 25px; }
.tarjeta { padding: 26px; border: 1px solid #dce4ed; border-radius: 15px; background: white; box-shadow: 0 4px 14px #273c5506; }
.titulo-panel { display: flex; align-items: center; gap: 10px; margin-bottom: 23px; } .paso { font-size: 11px; padding: 5px 7px; border-radius: 7px; color: #506c99; background: #edf2fb; }
h2 { font-size: 19px; margin: 0; letter-spacing: -.4px; } h3 { font-size: 19px; line-height: 1.5; margin: 0 0 16px; padding: 16px; border-radius: 9px; }
h4 { font-size: 13px; margin: 23px 0 10px; color: #4f6787; }
fieldset { border: 0; padding: 0; margin: 0 0 24px; } legend { font-size: 12px; color: #657b96; font-weight: 650; padding: 0 0 12px; }
.campos { display: grid; gap: 16px; } label { display: block; font-size: 13px; font-weight: 550; margin-bottom: 7px; }
input, select { width: 100%; font: inherit; font-size: 13px; color: #304561; padding: 11px 12px; background: #fafbfd; border: 1px solid #c4d2e1; border-radius: 7px; }
input:focus-visible, select:focus-visible, button:focus-visible, a:focus-visible { outline: 3px solid #a3c4eb; outline-offset: 3px; }
.acciones { display: flex; gap: 10px; flex-wrap: wrap; } button { border: 0; font: inherit; font-size: 12px; font-weight: 650; color: white; background: #315c91; padding: 12px 17px; border-radius: 8px; cursor: pointer; }
#evaluar { flex: 1; display: flex; align-items: center; justify-content: space-between; gap: 20px; } button:hover { background: #244c7e; } button:disabled { opacity: .6; cursor: wait; }
.secundario { background: #f0f4f9; color: #4f6d96; border: 1px solid #d4dfed; } .secundario:hover { background: #e5edf8; }
.vacio { padding: 45px 24px; text-align: center; background: #fafbfd; border: 1px dashed #ced9e6; border-radius: 10px; color: #788ca3; font-size: 13px; }
.positivo { background: #eaf5ee; color: #286345; } .aviso { background: #fff5e8; color: #91682e; } .neutral { background: #edf3fc; color: #385b8a; }
.error { color: #923c32; background: #ffefeb; padding: 12px; border-radius: 8px; font-size: 13px; }
#nota-edicion { padding: 12px; font-size: 12px; border-radius: 7px; } #mensajes p { font-size: 13px; color: #5c728b; white-space: pre-wrap; }
.tabla { overflow-x: auto; } table { width: 100%; border-collapse: collapse; font-size: 12px; } th { background: #eef3f9; color: #527197; text-align: left; padding: 10px; white-space: nowrap; } td { padding: 11px 10px; border-bottom: 1px solid #e5ebf2; vertical-align: top; overflow-wrap: anywhere; }
#descargar { margin-top: 22px; } footer { font-size: 10px; color: #8496ac; text-align: center; padding-top: 27px; }
@media(max-width: 850px) { main { padding: 20px 16px; } .paneles { grid-template-columns: 1fr; } .tarjeta { padding: 22px; } }
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-05-diagnostico-equipo-reporte/templates/index.html" <<'FIN_CODIGO_INTERFACES'
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{{ titulo }} · Práctica {{ numero }}</title>
  <link rel="stylesheet" href="{{ url_for('static', filename='estilos.css') }}">
  <script src="{{ url_for('static', filename='app.js') }}" defer></script>
</head>
<body>
<main data-numero="{{ numero }}">
  <header><a class="marca" href="{{ url_for('inicio') }}"><span>IA</span> Fundamentos de IA</a><span class="etiqueta">PRÁCTICA {{ '%02d'|format(numero) }}</span></header>
  <section class="introduccion"><p class="supertitulo">APRENDER HACIENDO</p><h1>{{ titulo }}</h1><p>{{ descripcion }}</p></section>
  <div class="paneles">
    <section class="tarjeta captura"><div class="titulo-panel"><span class="paso">01</span><h2>{{ 'Explorar' if not grupos else 'Ingresa los datos' }}</h2></div>
      <form id="formulario" action="{{ url_for('procesar') }}" method="post">
        <input type="hidden" name="csrf" value="{{ session['csrf'] }}">
        {% for grupo in grupos %}<fieldset><legend>{{ grupo.titulo }}</legend><div class="campos">
          {% for campo in grupo.campos %}<div class="campo"><label for="{{ campo.clave }}">{{ campo.etiqueta }}</label>
            {% if campo.tipo == 'booleano' %}
            <select id="{{ campo.clave }}" name="{{ campo.clave }}" required><option value="">Selecciona una respuesta</option><option value="si">Sí</option><option value="no">No</option></select>
            {% elif campo.tipo == 'opcion' %}
            <select id="{{ campo.clave }}" name="{{ campo.clave }}" required><option value="">Selecciona una opción</option>{% for clave, etiqueta in campo.opciones.items() %}<option value="{{ clave }}">{{ etiqueta }}</option>{% endfor %}</select>
            {% else %}
            <input id="{{ campo.clave }}" name="{{ campo.clave }}" type="text" {% if campo.tipo == 'numero' %}inputmode="decimal"{% endif %} required autocomplete="off">
            {% endif %}
          </div>{% endfor %}
        </div></fieldset>{% else %}<p class="ayuda">Compara las cuatro combinaciones de P y Q y el resultado de cada operación lógica.</p>{% endfor %}
        <div class="acciones"><button type="submit" id="evaluar">{{ boton }} <span aria-hidden="true">→</span></button>{% if grupos %}<button type="reset" class="secundario">Limpiar</button>{% endif %}</div>
      </form>
      <p id="error" class="error" role="alert" hidden></p>
    </section>
    <section class="tarjeta salida" aria-labelledby="titulo-resultado">
      <div class="titulo-panel"><span class="paso">02</span><h2 id="titulo-resultado">Resultado</h2></div>
      <p id="espera" class="vacio">{{ 'La tabla se mostrará aquí.' if not grupos else 'Completa el formulario para ver el resultado.' }}</p>
      <div id="resultado" aria-live="polite" hidden><p id="nota-edicion" class="aviso" hidden>Modificaste el formulario. Vuelve a evaluar para actualizar este resultado.</p><h3 id="diagnostico"></h3><div id="mensajes"></div><div id="tablas"></div><button id="descargar" class="secundario" type="button" hidden>Descargar reporte TXT</button></div>
    </section>
  </div>
  <footer>Práctica {{ numero }} · Python y una interfaz para aprender</footer>
</main>
</body>
</html>
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-06-sistema-experto-salud/06_sistema_experto_salud.py" <<'FIN_CODIGO_INTERFACES'
"""Práctica 6: interfaz independiente; reglas originales conservadas."""

def evaluar_sintomas(fiebre: bool, tos: bool, dolor_garganta: bool) -> str:
    """Devolver el primer resultado aplicable, con la prioridad original."""
    if fiebre and tos:
        return "Posible infección respiratoria"
    if tos and dolor_garganta:
        return "Posible irritación respiratoria"
    if fiebre:
        return "Se recomienda valoración profesional"
    return "No se identificó un patrón"

NUMERO = 6
PUERTO = 5106
TITULO = 'Sistema experto de salud'
DESCRIPCION = 'Ejercicio académico de tres síntomas. El resultado es orientativo y no sustituye una valoración médica.'
GRUPOS = [{'titulo': 'Síntomas',
  'campos': [{'clave': 'fiebre', 'etiqueta': '¿Tiene fiebre?', 'tipo': 'booleano'},
             {'clave': 'tos', 'etiqueta': '¿Tiene tos?', 'tipo': 'booleano'},
             {'clave': 'dolor_garganta',
              'etiqueta': '¿Tiene dolor de garganta?',
              'tipo': 'booleano'}]}]
BOTON = 'Evaluar síntomas'


def evaluar(datos):
    return {"titulo": evaluar_sintomas(**datos), "clase": "neutral",
            "mensajes": ["Resultado orientativo de las reglas de la práctica."], "tablas": []}


from pathlib import Path
import secrets
from math import isfinite
from flask import Flask, jsonify, render_template, request, session

def leer_formulario(formulario):
    datos = {}
    for grupo in GRUPOS:
        for campo in grupo["campos"]:
            clave = campo["clave"]
            valor = formulario.get(clave, "").strip()
            if not valor:
                raise ValueError(f"Completa el campo: {campo['etiqueta']}.")
            if campo["tipo"] == "booleano":
                if valor not in ("si", "no"):
                    raise ValueError(f"Selecciona Sí o No en: {campo['etiqueta']}.")
                datos[clave] = valor == "si"
            elif campo["tipo"] == "numero":
                try:
                    numero = float(valor)
                except ValueError:
                    raise ValueError(f"Ingresa un número válido en: {campo['etiqueta']}.") from None
                if not isfinite(numero):
                    raise ValueError(f"El número de {campo['etiqueta']} debe ser finito.")
                datos[clave] = numero
            elif campo["tipo"] == "opcion":
                if valor not in campo["opciones"]:
                    raise ValueError(f"Selecciona una opción válida en: {campo['etiqueta']}.")
                datos[clave] = valor
            else:
                datos[clave] = valor
    return datos

def crear_app():
    raiz = Path(__file__).resolve().parent
    app = Flask(__name__, template_folder=str(raiz / "templates"), static_folder=str(raiz / "static"))
    app.config.update(SECRET_KEY=secrets.token_hex(32), SESSION_COOKIE_HTTPONLY=True,
                      SESSION_COOKIE_SAMESITE="Strict", MAX_CONTENT_LENGTH=131072)

    @app.after_request
    def proteger(respuesta):
        respuesta.headers["Cache-Control"] = "no-store"
        respuesta.headers["X-Content-Type-Options"] = "nosniff"
        respuesta.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'"
        return respuesta

    @app.get("/")
    def inicio():
        session.setdefault("csrf", secrets.token_hex(32))
        return render_template("index.html", numero=NUMERO, titulo=TITULO, descripcion=DESCRIPCION, grupos=GRUPOS, boton=BOTON)

    @app.post("/evaluar")
    def procesar():
        token = request.form.get("csrf", "")
        if not token or not secrets.compare_digest(token.encode(), session.get("csrf", "").encode()):
            return jsonify(ok=False, mensaje="El formulario expiró. Recarga la página."), 400
        try:
            datos = leer_formulario(request.form)
        except ValueError as error:
            return jsonify(ok=False, mensaje=str(error)), 400
        return jsonify(ok=True, resultado=evaluar(datos))

    @app.errorhandler(413)
    def demasiado_grande(error):
        return jsonify(ok=False, mensaje="El formulario es demasiado grande. Reduce el texto e inténtalo de nuevo."), 413

    return app

if __name__ == "__main__":
    print(f"Abre http://localhost:{PUERTO} en tu navegador. Detén el servidor con Ctrl+C.")
    crear_app().run(host="127.0.0.1", port=PUERTO, debug=False)
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-06-sistema-experto-salud/README.md" <<'FIN_CODIGO_INTERFACES'
# Práctica 6: Sistema experto de salud

Ejercicio académico de tres síntomas. El resultado es orientativo y no sustituye una valoración médica.

Desde la raíz del proyecto:

```bash
bash unidad-01-introduccion-ia/practicas/practica-06-sistema-experto-salud/ejecutar.sh
```

Abre http://localhost:5106. Detén el servidor con Ctrl+C.

Programa independiente: todo el código, HTML, CSS y JavaScript está en esta carpeta.
Las funciones de las reglas se conservan del programa optimizado. Los campos
se validan en Python. Los resultados no se guardan en una base de datos.

Flask devuelve JSON; JavaScript muestra texto sin interpretarlo como HTML.
La práctica 5 permite descargar su reporte en TXT.
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-06-sistema-experto-salud/ejecutar.sh" <<'FIN_CODIGO_INTERFACES'
#!/usr/bin/env bash
set -euo pipefail
directorio="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
proyecto="$(cd -- "$directorio/../../.." && pwd)"
exec "$proyecto/.venv/bin/python" "$directorio/06_sistema_experto_salud.py"
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-06-sistema-experto-salud/requirements.txt" <<'FIN_CODIGO_INTERFACES'
Flask>=3.1,<4
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-06-sistema-experto-salud/static/app.js" <<'FIN_CODIGO_INTERFACES'
"use strict";
const formulario = document.querySelector("#formulario");
const boton = document.querySelector("#evaluar");
const error = document.querySelector("#error");
const resultado = document.querySelector("#resultado");
let reporte = "";
let solicitud = 0;
let edicion = 0;

function mostrar(datos) {
  resultado.hidden = false;
  document.querySelector("#espera").hidden = true;
  document.querySelector("#nota-edicion").hidden = true;
  const titulo = document.querySelector("#diagnostico");
  titulo.textContent = datos.titulo;
  titulo.className = datos.clase || "neutral";
  const mensajes = document.querySelector("#mensajes");
  mensajes.replaceChildren();
  for (const texto of datos.mensajes || []) {
    const p = document.createElement("p"); p.textContent = texto; mensajes.append(p);
  }
  const tablas = document.querySelector("#tablas"); tablas.replaceChildren();
  for (const contenido of datos.tablas || []) {
    const bloque = document.createElement("section");
    const nombre = document.createElement("h4"); nombre.textContent = contenido.titulo; bloque.append(nombre);
    const envoltura = document.createElement("div"); envoltura.className = "tabla";
    const tabla = document.createElement("table");
    const cabecera = document.createElement("thead"); const fila = document.createElement("tr");
    for (const etiqueta of contenido.encabezados) {
      const celda = document.createElement("th"); celda.scope = "col"; celda.textContent = etiqueta; fila.append(celda);
    }
    cabecera.append(fila); tabla.append(cabecera);
    const cuerpo = document.createElement("tbody");
    for (const valores of contenido.filas) {
      const fila = document.createElement("tr");
      for (const valor of valores) {
        const celda = document.createElement("td"); celda.textContent = valor; fila.append(celda);
      }
      cuerpo.append(fila);
    }
    tabla.append(cuerpo); envoltura.append(tabla); bloque.append(envoltura); tablas.append(bloque);
  }
  reporte = datos.reporte || "";
  document.querySelector("#descargar").hidden = !reporte;
}

formulario.addEventListener("submit", async (evento) => {
  evento.preventDefault();
  const actual = ++solicitud;
  const edicionEnviada = edicion;
  boton.disabled = true; formulario.setAttribute("aria-busy", "true"); error.hidden = true;
  try {
    const respuesta = await fetch(formulario.action, { method: "POST", body: new FormData(formulario), credentials: "same-origin" });
    const datos = await respuesta.json();
    if (actual !== solicitud) return;
    if (!respuesta.ok || !datos.ok) throw new Error(datos.mensaje || "No se pudo evaluar el formulario.");
    mostrar(datos.resultado);
    document.querySelector("#nota-edicion").hidden = edicion === edicionEnviada;
  } catch (fallo) {
    if (actual !== solicitud) return;
    error.textContent = fallo instanceof TypeError ? "No se pudo contactar con Python. Comprueba la terminal del servidor." : fallo.message;
    error.hidden = false;
  } finally {
    if (actual === solicitud) { boton.disabled = false; formulario.setAttribute("aria-busy", "false"); }
  }
});
formulario.addEventListener("input", () => {
  edicion++;
  if (!resultado.hidden) document.querySelector("#nota-edicion").hidden = false;
});
formulario.addEventListener("reset", () => {
  solicitud++; boton.disabled = false; formulario.setAttribute("aria-busy", "false");
  resultado.hidden = true; document.querySelector("#espera").hidden = false; error.hidden = true; reporte = "";
});
document.querySelector("#descargar").addEventListener("click", () => {
  const url = URL.createObjectURL(new Blob([reporte], {type: "text/plain;charset=utf-8"}));
  const enlace = document.createElement("a"); enlace.href = url; enlace.download = "reporte_diagnostico.txt"; enlace.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});
if (document.querySelector("main").dataset.numero === "1") formulario.requestSubmit();
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-06-sistema-experto-salud/static/estilos.css" <<'FIN_CODIGO_INTERFACES'

:root { font-family: "Segoe UI", system-ui, sans-serif; color: #25354a; background: #f4f6fa; line-height: 1.5; }
* { box-sizing: border-box; } body { margin: 0; } [hidden] { display: none !important; }
main { max-width: 1240px; margin: auto; padding: 26px 30px; }
header { display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid #dce3ed; padding-bottom: 22px; gap: 15px; }
.marca { display: flex; align-items: center; gap: 10px; font-size: 13px; font-weight: 650; text-decoration: none; color: #405675; }
.marca span { display: grid; place-items: center; width: 38px; height: 38px; border-radius: 10px; background: #315c91; color: white; }
.etiqueta { font-size: 11px; letter-spacing: 1px; color: #5b7394; border: 1px solid #c9d5e5; border-radius: 30px; padding: 6px 12px; }
.introduccion { padding: 31px 0; } .supertitulo { font-size: 10px; letter-spacing: 2px; font-weight: 700; color: #6585ac; }
h1 { font-size: clamp(28px, 3vw, 40px); line-height: 1.18; letter-spacing: -1px; margin: 9px 0 12px; }
.introduccion > p:last-child { color: #687d95; font-size: 14px; max-width: 830px; margin-bottom: 0; }
.paneles { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1.05fr); align-items: start; gap: 25px; }
.tarjeta { padding: 26px; border: 1px solid #dce4ed; border-radius: 15px; background: white; box-shadow: 0 4px 14px #273c5506; }
.titulo-panel { display: flex; align-items: center; gap: 10px; margin-bottom: 23px; } .paso { font-size: 11px; padding: 5px 7px; border-radius: 7px; color: #506c99; background: #edf2fb; }
h2 { font-size: 19px; margin: 0; letter-spacing: -.4px; } h3 { font-size: 19px; line-height: 1.5; margin: 0 0 16px; padding: 16px; border-radius: 9px; }
h4 { font-size: 13px; margin: 23px 0 10px; color: #4f6787; }
fieldset { border: 0; padding: 0; margin: 0 0 24px; } legend { font-size: 12px; color: #657b96; font-weight: 650; padding: 0 0 12px; }
.campos { display: grid; gap: 16px; } label { display: block; font-size: 13px; font-weight: 550; margin-bottom: 7px; }
input, select { width: 100%; font: inherit; font-size: 13px; color: #304561; padding: 11px 12px; background: #fafbfd; border: 1px solid #c4d2e1; border-radius: 7px; }
input:focus-visible, select:focus-visible, button:focus-visible, a:focus-visible { outline: 3px solid #a3c4eb; outline-offset: 3px; }
.acciones { display: flex; gap: 10px; flex-wrap: wrap; } button { border: 0; font: inherit; font-size: 12px; font-weight: 650; color: white; background: #315c91; padding: 12px 17px; border-radius: 8px; cursor: pointer; }
#evaluar { flex: 1; display: flex; align-items: center; justify-content: space-between; gap: 20px; } button:hover { background: #244c7e; } button:disabled { opacity: .6; cursor: wait; }
.secundario { background: #f0f4f9; color: #4f6d96; border: 1px solid #d4dfed; } .secundario:hover { background: #e5edf8; }
.vacio { padding: 45px 24px; text-align: center; background: #fafbfd; border: 1px dashed #ced9e6; border-radius: 10px; color: #788ca3; font-size: 13px; }
.positivo { background: #eaf5ee; color: #286345; } .aviso { background: #fff5e8; color: #91682e; } .neutral { background: #edf3fc; color: #385b8a; }
.error { color: #923c32; background: #ffefeb; padding: 12px; border-radius: 8px; font-size: 13px; }
#nota-edicion { padding: 12px; font-size: 12px; border-radius: 7px; } #mensajes p { font-size: 13px; color: #5c728b; white-space: pre-wrap; }
.tabla { overflow-x: auto; } table { width: 100%; border-collapse: collapse; font-size: 12px; } th { background: #eef3f9; color: #527197; text-align: left; padding: 10px; white-space: nowrap; } td { padding: 11px 10px; border-bottom: 1px solid #e5ebf2; vertical-align: top; overflow-wrap: anywhere; }
#descargar { margin-top: 22px; } footer { font-size: 10px; color: #8496ac; text-align: center; padding-top: 27px; }
@media(max-width: 850px) { main { padding: 20px 16px; } .paneles { grid-template-columns: 1fr; } .tarjeta { padding: 22px; } }
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-06-sistema-experto-salud/templates/index.html" <<'FIN_CODIGO_INTERFACES'
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{{ titulo }} · Práctica {{ numero }}</title>
  <link rel="stylesheet" href="{{ url_for('static', filename='estilos.css') }}">
  <script src="{{ url_for('static', filename='app.js') }}" defer></script>
</head>
<body>
<main data-numero="{{ numero }}">
  <header><a class="marca" href="{{ url_for('inicio') }}"><span>IA</span> Fundamentos de IA</a><span class="etiqueta">PRÁCTICA {{ '%02d'|format(numero) }}</span></header>
  <section class="introduccion"><p class="supertitulo">APRENDER HACIENDO</p><h1>{{ titulo }}</h1><p>{{ descripcion }}</p></section>
  <div class="paneles">
    <section class="tarjeta captura"><div class="titulo-panel"><span class="paso">01</span><h2>{{ 'Explorar' if not grupos else 'Ingresa los datos' }}</h2></div>
      <form id="formulario" action="{{ url_for('procesar') }}" method="post">
        <input type="hidden" name="csrf" value="{{ session['csrf'] }}">
        {% for grupo in grupos %}<fieldset><legend>{{ grupo.titulo }}</legend><div class="campos">
          {% for campo in grupo.campos %}<div class="campo"><label for="{{ campo.clave }}">{{ campo.etiqueta }}</label>
            {% if campo.tipo == 'booleano' %}
            <select id="{{ campo.clave }}" name="{{ campo.clave }}" required><option value="">Selecciona una respuesta</option><option value="si">Sí</option><option value="no">No</option></select>
            {% elif campo.tipo == 'opcion' %}
            <select id="{{ campo.clave }}" name="{{ campo.clave }}" required><option value="">Selecciona una opción</option>{% for clave, etiqueta in campo.opciones.items() %}<option value="{{ clave }}">{{ etiqueta }}</option>{% endfor %}</select>
            {% else %}
            <input id="{{ campo.clave }}" name="{{ campo.clave }}" type="text" {% if campo.tipo == 'numero' %}inputmode="decimal"{% endif %} required autocomplete="off">
            {% endif %}
          </div>{% endfor %}
        </div></fieldset>{% else %}<p class="ayuda">Compara las cuatro combinaciones de P y Q y el resultado de cada operación lógica.</p>{% endfor %}
        <div class="acciones"><button type="submit" id="evaluar">{{ boton }} <span aria-hidden="true">→</span></button>{% if grupos %}<button type="reset" class="secundario">Limpiar</button>{% endif %}</div>
      </form>
      <p id="error" class="error" role="alert" hidden></p>
    </section>
    <section class="tarjeta salida" aria-labelledby="titulo-resultado">
      <div class="titulo-panel"><span class="paso">02</span><h2 id="titulo-resultado">Resultado</h2></div>
      <p id="espera" class="vacio">{{ 'La tabla se mostrará aquí.' if not grupos else 'Completa el formulario para ver el resultado.' }}</p>
      <div id="resultado" aria-live="polite" hidden><p id="nota-edicion" class="aviso" hidden>Modificaste el formulario. Vuelve a evaluar para actualizar este resultado.</p><h3 id="diagnostico"></h3><div id="mensajes"></div><div id="tablas"></div><button id="descargar" class="secundario" type="button" hidden>Descargar reporte TXT</button></div>
    </section>
  </div>
  <footer>Práctica {{ numero }} · Python y una interfaz para aprender</footer>
</main>
</body>
</html>
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-07-sistema-experto-salud-mejorado/07_sistema_experto_salud_mejorado.py" <<'FIN_CODIGO_INTERFACES'
"""Práctica 7: interfaz independiente; reglas originales conservadas."""

from dataclasses import dataclass

@dataclass(frozen=True)
class Regla:
    """Agrupar las condiciones y los tres textos de una regla académica."""

    sintomas_requeridos: tuple[str, ...]
    diagnostico: str
    recomendacion: str
    descripcion: str

PREGUNTAS = (
    ("fiebre", "¿Tiene fiebre? (s/n): "),
    ("tos", "¿Tiene tos? (s/n): "),
    ("dolor_garganta", "¿Tiene dolor de garganta? (s/n): "),
    ("congestion", "¿Tiene congestión nasal? (s/n): "),
    ("dolor_cabeza", "¿Tiene dolor de cabeza? (s/n): "),
    ("cansancio", "¿Presenta cansancio? (s/n): "),
    ("dificultad_respirar", "¿Tiene dificultad para respirar? (s/n): "),
)

REGLAS = (
    Regla(
        sintomas_requeridos=("dificultad_respirar",),
        diagnostico="Se detectó dificultad para respirar.",
        recomendacion=(
            "Se recomienda buscar valoración profesional de forma prioritaria."
        ),
        descripcion="Regla 1: dificultad respiratoria",
    ),
    Regla(
        sintomas_requeridos=("fiebre", "tos", "cansancio"),
        diagnostico="Patrón de síntomas respiratorios con fiebre y cansancio.",
        recomendacion="Se recomienda valoración profesional.",
        descripcion="Regla 2: fiebre AND tos AND cansancio",
    ),
    Regla(
        sintomas_requeridos=("tos", "dolor_garganta", "congestion"),
        diagnostico="Patrón de irritación de vías respiratorias.",
        recomendacion=(
            "Dar seguimiento a los síntomas y considerar valoración profesional."
        ),
        descripcion="Regla 3: tos AND dolor de garganta AND congestión",
    ),
    Regla(
        sintomas_requeridos=("fiebre", "dolor_cabeza"),
        diagnostico="Fiebre acompañada de dolor de cabeza.",
        recomendacion="Vigilar los síntomas y solicitar valoración si continúan.",
        descripcion="Regla 4: fiebre AND dolor de cabeza",
    ),
    Regla(
        sintomas_requeridos=("congestion", "dolor_garganta"),
        diagnostico="Molestias en vías respiratorias superiores.",
        recomendacion="Mantener vigilancia de los síntomas.",
        descripcion="Regla 5: congestión AND dolor de garganta",
    ),
    Regla(
        sintomas_requeridos=("fiebre",),
        diagnostico="Fiebre sin un patrón adicional suficiente.",
        recomendacion=(
            "Se recomienda valoración profesional si la fiebre persiste."
        ),
        descripcion="Regla 6: fiebre",
    ),
)

REGLA_POR_DEFECTO = Regla(
    sintomas_requeridos=(),
    diagnostico="No se identificó un patrón con las reglas actuales.",
    recomendacion="Continuar observando los síntomas.",
    descripcion="Regla por defecto",
)

def evaluar_sintomas(sintomas: dict[str, bool]) -> Regla:
    """Seleccionar la primera regla cuyos síntomas requeridos estén presentes."""
    for regla in REGLAS:
        if all(sintomas[sintoma] for sintoma in regla.sintomas_requeridos):
            return regla
    return REGLA_POR_DEFECTO

NUMERO = 7
PUERTO = 5107
TITULO = 'Sistema experto de salud mejorado'
DESCRIPCION = 'Esta práctica académica evalúa siete síntomas y explica la regla activada. No sustituye una valoración médica.'
GRUPOS = [{'titulo': 'Síntomas',
  'campos': [{'clave': 'fiebre', 'etiqueta': '¿Tiene fiebre?', 'tipo': 'booleano'},
             {'clave': 'tos', 'etiqueta': '¿Tiene tos?', 'tipo': 'booleano'},
             {'clave': 'dolor_garganta',
              'etiqueta': '¿Tiene dolor de garganta?',
              'tipo': 'booleano'},
             {'clave': 'congestion',
              'etiqueta': '¿Tiene congestión nasal?',
              'tipo': 'booleano'},
             {'clave': 'dolor_cabeza',
              'etiqueta': '¿Tiene dolor de cabeza?',
              'tipo': 'booleano'},
             {'clave': 'cansancio',
              'etiqueta': '¿Presenta cansancio?',
              'tipo': 'booleano'},
             {'clave': 'dificultad_respirar',
              'etiqueta': '¿Tiene dificultad para respirar?',
              'tipo': 'booleano'}]}]
BOTON = 'Evaluar y explicar'


def evaluar(datos):
    regla = evaluar_sintomas(datos)
    return {"titulo": regla.diagnostico, "clase": "neutral",
            "mensajes": [regla.descripcion, "Recomendación: " + regla.recomendacion], "tablas": []}


from pathlib import Path
import secrets
from math import isfinite
from flask import Flask, jsonify, render_template, request, session

def leer_formulario(formulario):
    datos = {}
    for grupo in GRUPOS:
        for campo in grupo["campos"]:
            clave = campo["clave"]
            valor = formulario.get(clave, "").strip()
            if not valor:
                raise ValueError(f"Completa el campo: {campo['etiqueta']}.")
            if campo["tipo"] == "booleano":
                if valor not in ("si", "no"):
                    raise ValueError(f"Selecciona Sí o No en: {campo['etiqueta']}.")
                datos[clave] = valor == "si"
            elif campo["tipo"] == "numero":
                try:
                    numero = float(valor)
                except ValueError:
                    raise ValueError(f"Ingresa un número válido en: {campo['etiqueta']}.") from None
                if not isfinite(numero):
                    raise ValueError(f"El número de {campo['etiqueta']} debe ser finito.")
                datos[clave] = numero
            elif campo["tipo"] == "opcion":
                if valor not in campo["opciones"]:
                    raise ValueError(f"Selecciona una opción válida en: {campo['etiqueta']}.")
                datos[clave] = valor
            else:
                datos[clave] = valor
    return datos

def crear_app():
    raiz = Path(__file__).resolve().parent
    app = Flask(__name__, template_folder=str(raiz / "templates"), static_folder=str(raiz / "static"))
    app.config.update(SECRET_KEY=secrets.token_hex(32), SESSION_COOKIE_HTTPONLY=True,
                      SESSION_COOKIE_SAMESITE="Strict", MAX_CONTENT_LENGTH=131072)

    @app.after_request
    def proteger(respuesta):
        respuesta.headers["Cache-Control"] = "no-store"
        respuesta.headers["X-Content-Type-Options"] = "nosniff"
        respuesta.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'"
        return respuesta

    @app.get("/")
    def inicio():
        session.setdefault("csrf", secrets.token_hex(32))
        return render_template("index.html", numero=NUMERO, titulo=TITULO, descripcion=DESCRIPCION, grupos=GRUPOS, boton=BOTON)

    @app.post("/evaluar")
    def procesar():
        token = request.form.get("csrf", "")
        if not token or not secrets.compare_digest(token.encode(), session.get("csrf", "").encode()):
            return jsonify(ok=False, mensaje="El formulario expiró. Recarga la página."), 400
        try:
            datos = leer_formulario(request.form)
        except ValueError as error:
            return jsonify(ok=False, mensaje=str(error)), 400
        return jsonify(ok=True, resultado=evaluar(datos))

    @app.errorhandler(413)
    def demasiado_grande(error):
        return jsonify(ok=False, mensaje="El formulario es demasiado grande. Reduce el texto e inténtalo de nuevo."), 413

    return app

if __name__ == "__main__":
    print(f"Abre http://localhost:{PUERTO} en tu navegador. Detén el servidor con Ctrl+C.")
    crear_app().run(host="127.0.0.1", port=PUERTO, debug=False)
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-07-sistema-experto-salud-mejorado/README.md" <<'FIN_CODIGO_INTERFACES'
# Práctica 7: Sistema experto de salud mejorado

Esta práctica académica evalúa siete síntomas y explica la regla activada. No sustituye una valoración médica.

Desde la raíz del proyecto:

```bash
bash unidad-01-introduccion-ia/practicas/practica-07-sistema-experto-salud-mejorado/ejecutar.sh
```

Abre http://localhost:5107. Detén el servidor con Ctrl+C.

Programa independiente: todo el código, HTML, CSS y JavaScript está en esta carpeta.
Las funciones de las reglas se conservan del programa optimizado. Los campos
se validan en Python. Los resultados no se guardan en una base de datos.

Flask devuelve JSON; JavaScript muestra texto sin interpretarlo como HTML.
La práctica 5 permite descargar su reporte en TXT.
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-07-sistema-experto-salud-mejorado/ejecutar.sh" <<'FIN_CODIGO_INTERFACES'
#!/usr/bin/env bash
set -euo pipefail
directorio="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
proyecto="$(cd -- "$directorio/../../.." && pwd)"
exec "$proyecto/.venv/bin/python" "$directorio/07_sistema_experto_salud_mejorado.py"
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-07-sistema-experto-salud-mejorado/requirements.txt" <<'FIN_CODIGO_INTERFACES'
Flask>=3.1,<4
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-07-sistema-experto-salud-mejorado/static/app.js" <<'FIN_CODIGO_INTERFACES'
"use strict";
const formulario = document.querySelector("#formulario");
const boton = document.querySelector("#evaluar");
const error = document.querySelector("#error");
const resultado = document.querySelector("#resultado");
let reporte = "";
let solicitud = 0;
let edicion = 0;

function mostrar(datos) {
  resultado.hidden = false;
  document.querySelector("#espera").hidden = true;
  document.querySelector("#nota-edicion").hidden = true;
  const titulo = document.querySelector("#diagnostico");
  titulo.textContent = datos.titulo;
  titulo.className = datos.clase || "neutral";
  const mensajes = document.querySelector("#mensajes");
  mensajes.replaceChildren();
  for (const texto of datos.mensajes || []) {
    const p = document.createElement("p"); p.textContent = texto; mensajes.append(p);
  }
  const tablas = document.querySelector("#tablas"); tablas.replaceChildren();
  for (const contenido of datos.tablas || []) {
    const bloque = document.createElement("section");
    const nombre = document.createElement("h4"); nombre.textContent = contenido.titulo; bloque.append(nombre);
    const envoltura = document.createElement("div"); envoltura.className = "tabla";
    const tabla = document.createElement("table");
    const cabecera = document.createElement("thead"); const fila = document.createElement("tr");
    for (const etiqueta of contenido.encabezados) {
      const celda = document.createElement("th"); celda.scope = "col"; celda.textContent = etiqueta; fila.append(celda);
    }
    cabecera.append(fila); tabla.append(cabecera);
    const cuerpo = document.createElement("tbody");
    for (const valores of contenido.filas) {
      const fila = document.createElement("tr");
      for (const valor of valores) {
        const celda = document.createElement("td"); celda.textContent = valor; fila.append(celda);
      }
      cuerpo.append(fila);
    }
    tabla.append(cuerpo); envoltura.append(tabla); bloque.append(envoltura); tablas.append(bloque);
  }
  reporte = datos.reporte || "";
  document.querySelector("#descargar").hidden = !reporte;
}

formulario.addEventListener("submit", async (evento) => {
  evento.preventDefault();
  const actual = ++solicitud;
  const edicionEnviada = edicion;
  boton.disabled = true; formulario.setAttribute("aria-busy", "true"); error.hidden = true;
  try {
    const respuesta = await fetch(formulario.action, { method: "POST", body: new FormData(formulario), credentials: "same-origin" });
    const datos = await respuesta.json();
    if (actual !== solicitud) return;
    if (!respuesta.ok || !datos.ok) throw new Error(datos.mensaje || "No se pudo evaluar el formulario.");
    mostrar(datos.resultado);
    document.querySelector("#nota-edicion").hidden = edicion === edicionEnviada;
  } catch (fallo) {
    if (actual !== solicitud) return;
    error.textContent = fallo instanceof TypeError ? "No se pudo contactar con Python. Comprueba la terminal del servidor." : fallo.message;
    error.hidden = false;
  } finally {
    if (actual === solicitud) { boton.disabled = false; formulario.setAttribute("aria-busy", "false"); }
  }
});
formulario.addEventListener("input", () => {
  edicion++;
  if (!resultado.hidden) document.querySelector("#nota-edicion").hidden = false;
});
formulario.addEventListener("reset", () => {
  solicitud++; boton.disabled = false; formulario.setAttribute("aria-busy", "false");
  resultado.hidden = true; document.querySelector("#espera").hidden = false; error.hidden = true; reporte = "";
});
document.querySelector("#descargar").addEventListener("click", () => {
  const url = URL.createObjectURL(new Blob([reporte], {type: "text/plain;charset=utf-8"}));
  const enlace = document.createElement("a"); enlace.href = url; enlace.download = "reporte_diagnostico.txt"; enlace.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});
if (document.querySelector("main").dataset.numero === "1") formulario.requestSubmit();
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-07-sistema-experto-salud-mejorado/static/estilos.css" <<'FIN_CODIGO_INTERFACES'

:root { font-family: "Segoe UI", system-ui, sans-serif; color: #25354a; background: #f4f6fa; line-height: 1.5; }
* { box-sizing: border-box; } body { margin: 0; } [hidden] { display: none !important; }
main { max-width: 1240px; margin: auto; padding: 26px 30px; }
header { display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid #dce3ed; padding-bottom: 22px; gap: 15px; }
.marca { display: flex; align-items: center; gap: 10px; font-size: 13px; font-weight: 650; text-decoration: none; color: #405675; }
.marca span { display: grid; place-items: center; width: 38px; height: 38px; border-radius: 10px; background: #315c91; color: white; }
.etiqueta { font-size: 11px; letter-spacing: 1px; color: #5b7394; border: 1px solid #c9d5e5; border-radius: 30px; padding: 6px 12px; }
.introduccion { padding: 31px 0; } .supertitulo { font-size: 10px; letter-spacing: 2px; font-weight: 700; color: #6585ac; }
h1 { font-size: clamp(28px, 3vw, 40px); line-height: 1.18; letter-spacing: -1px; margin: 9px 0 12px; }
.introduccion > p:last-child { color: #687d95; font-size: 14px; max-width: 830px; margin-bottom: 0; }
.paneles { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1.05fr); align-items: start; gap: 25px; }
.tarjeta { padding: 26px; border: 1px solid #dce4ed; border-radius: 15px; background: white; box-shadow: 0 4px 14px #273c5506; }
.titulo-panel { display: flex; align-items: center; gap: 10px; margin-bottom: 23px; } .paso { font-size: 11px; padding: 5px 7px; border-radius: 7px; color: #506c99; background: #edf2fb; }
h2 { font-size: 19px; margin: 0; letter-spacing: -.4px; } h3 { font-size: 19px; line-height: 1.5; margin: 0 0 16px; padding: 16px; border-radius: 9px; }
h4 { font-size: 13px; margin: 23px 0 10px; color: #4f6787; }
fieldset { border: 0; padding: 0; margin: 0 0 24px; } legend { font-size: 12px; color: #657b96; font-weight: 650; padding: 0 0 12px; }
.campos { display: grid; gap: 16px; } label { display: block; font-size: 13px; font-weight: 550; margin-bottom: 7px; }
input, select { width: 100%; font: inherit; font-size: 13px; color: #304561; padding: 11px 12px; background: #fafbfd; border: 1px solid #c4d2e1; border-radius: 7px; }
input:focus-visible, select:focus-visible, button:focus-visible, a:focus-visible { outline: 3px solid #a3c4eb; outline-offset: 3px; }
.acciones { display: flex; gap: 10px; flex-wrap: wrap; } button { border: 0; font: inherit; font-size: 12px; font-weight: 650; color: white; background: #315c91; padding: 12px 17px; border-radius: 8px; cursor: pointer; }
#evaluar { flex: 1; display: flex; align-items: center; justify-content: space-between; gap: 20px; } button:hover { background: #244c7e; } button:disabled { opacity: .6; cursor: wait; }
.secundario { background: #f0f4f9; color: #4f6d96; border: 1px solid #d4dfed; } .secundario:hover { background: #e5edf8; }
.vacio { padding: 45px 24px; text-align: center; background: #fafbfd; border: 1px dashed #ced9e6; border-radius: 10px; color: #788ca3; font-size: 13px; }
.positivo { background: #eaf5ee; color: #286345; } .aviso { background: #fff5e8; color: #91682e; } .neutral { background: #edf3fc; color: #385b8a; }
.error { color: #923c32; background: #ffefeb; padding: 12px; border-radius: 8px; font-size: 13px; }
#nota-edicion { padding: 12px; font-size: 12px; border-radius: 7px; } #mensajes p { font-size: 13px; color: #5c728b; white-space: pre-wrap; }
.tabla { overflow-x: auto; } table { width: 100%; border-collapse: collapse; font-size: 12px; } th { background: #eef3f9; color: #527197; text-align: left; padding: 10px; white-space: nowrap; } td { padding: 11px 10px; border-bottom: 1px solid #e5ebf2; vertical-align: top; overflow-wrap: anywhere; }
#descargar { margin-top: 22px; } footer { font-size: 10px; color: #8496ac; text-align: center; padding-top: 27px; }
@media(max-width: 850px) { main { padding: 20px 16px; } .paneles { grid-template-columns: 1fr; } .tarjeta { padding: 22px; } }
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-07-sistema-experto-salud-mejorado/templates/index.html" <<'FIN_CODIGO_INTERFACES'
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{{ titulo }} · Práctica {{ numero }}</title>
  <link rel="stylesheet" href="{{ url_for('static', filename='estilos.css') }}">
  <script src="{{ url_for('static', filename='app.js') }}" defer></script>
</head>
<body>
<main data-numero="{{ numero }}">
  <header><a class="marca" href="{{ url_for('inicio') }}"><span>IA</span> Fundamentos de IA</a><span class="etiqueta">PRÁCTICA {{ '%02d'|format(numero) }}</span></header>
  <section class="introduccion"><p class="supertitulo">APRENDER HACIENDO</p><h1>{{ titulo }}</h1><p>{{ descripcion }}</p></section>
  <div class="paneles">
    <section class="tarjeta captura"><div class="titulo-panel"><span class="paso">01</span><h2>{{ 'Explorar' if not grupos else 'Ingresa los datos' }}</h2></div>
      <form id="formulario" action="{{ url_for('procesar') }}" method="post">
        <input type="hidden" name="csrf" value="{{ session['csrf'] }}">
        {% for grupo in grupos %}<fieldset><legend>{{ grupo.titulo }}</legend><div class="campos">
          {% for campo in grupo.campos %}<div class="campo"><label for="{{ campo.clave }}">{{ campo.etiqueta }}</label>
            {% if campo.tipo == 'booleano' %}
            <select id="{{ campo.clave }}" name="{{ campo.clave }}" required><option value="">Selecciona una respuesta</option><option value="si">Sí</option><option value="no">No</option></select>
            {% elif campo.tipo == 'opcion' %}
            <select id="{{ campo.clave }}" name="{{ campo.clave }}" required><option value="">Selecciona una opción</option>{% for clave, etiqueta in campo.opciones.items() %}<option value="{{ clave }}">{{ etiqueta }}</option>{% endfor %}</select>
            {% else %}
            <input id="{{ campo.clave }}" name="{{ campo.clave }}" type="text" {% if campo.tipo == 'numero' %}inputmode="decimal"{% endif %} required autocomplete="off">
            {% endif %}
          </div>{% endfor %}
        </div></fieldset>{% else %}<p class="ayuda">Compara las cuatro combinaciones de P y Q y el resultado de cada operación lógica.</p>{% endfor %}
        <div class="acciones"><button type="submit" id="evaluar">{{ boton }} <span aria-hidden="true">→</span></button>{% if grupos %}<button type="reset" class="secundario">Limpiar</button>{% endif %}</div>
      </form>
      <p id="error" class="error" role="alert" hidden></p>
    </section>
    <section class="tarjeta salida" aria-labelledby="titulo-resultado">
      <div class="titulo-panel"><span class="paso">02</span><h2 id="titulo-resultado">Resultado</h2></div>
      <p id="espera" class="vacio">{{ 'La tabla se mostrará aquí.' if not grupos else 'Completa el formulario para ver el resultado.' }}</p>
      <div id="resultado" aria-live="polite" hidden><p id="nota-edicion" class="aviso" hidden>Modificaste el formulario. Vuelve a evaluar para actualizar este resultado.</p><h3 id="diagnostico"></h3><div id="mensajes"></div><div id="tablas"></div><button id="descargar" class="secundario" type="button" hidden>Descargar reporte TXT</button></div>
    </section>
  </div>
  <footer>Práctica {{ numero }} · Python y una interfaz para aprender</footer>
</main>
</body>
</html>
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-08-conexion-mongodb/08_conexion_mongodb.py" <<'FIN_CODIGO_INTERFACES'
"""Práctica 8: interfaz web local para guardar y consultar en MongoDB."""

import atexit
import re
import secrets
from pathlib import Path

from flask import Flask, flash, redirect, render_template, request, session, url_for
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, PyMongoError

URI_MONGODB = "mongodb://127.0.0.1:27017/"
BASE_DATOS = "fundamentos_ia"
COLECCION = "practicas"
DIRECTORIO = Path(__file__).resolve().parent


def validar(datos):
    """Validar también en Python, aunque el navegador valide el formulario."""
    numero = datos["numero"]
    if not re.fullmatch(r"[0-9]{1,19}", numero):
        raise ValueError("El número debe ser un entero positivo.")
    numero = int(numero)
    if not 1 <= numero <= 9223372036854775807:
        raise ValueError("El número está fuera del rango permitido.")
    if not 1 <= len(datos["nombre"]) <= 120:
        raise ValueError("Escribe un nombre de entre 1 y 120 caracteres.")
    if not 1 <= len(datos["lenguaje"]) <= 40:
        raise ValueError("Escribe un lenguaje de entre 1 y 40 caracteres.")
    if not 1 <= len(datos["dato"]) <= 1000:
        raise ValueError("Escribe un dato de entre 1 y 1000 caracteres.")
    return numero, {campo: datos[campo] for campo in ("nombre", "lenguaje", "dato")}


def crear_app(coleccion=None):
    app = Flask(__name__, template_folder=str(DIRECTORIO / "templates"),
                static_folder=str(DIRECTORIO / "static"))
    app.config.update(SECRET_KEY=secrets.token_hex(32), MAX_CONTENT_LENGTH=16384,
                      SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")

    if coleccion is None:
        cliente = MongoClient(URI_MONGODB, serverSelectionTimeoutMS=3000,
                              connectTimeoutMS=3000, socketTimeoutMS=3000)
        atexit.register(cliente.close)
        coleccion = cliente[BASE_DATOS][COLECCION]

    def pagina(datos=None, error=None, estado=200):
        session.setdefault("csrf", secrets.token_hex(32))
        try:
            registros = list(coleccion.find({}, {"nombre": 1, "lenguaje": 1, "dato": 1})
                             .sort("_id", 1).limit(100))
            conectado = True
        except PyMongoError:
            registros, conectado = [], False
            error = error or "No se pudo consultar MongoDB. Comprueba el servidor y los permisos."
            estado = 503
        return render_template("index.html", registros=registros, conectado=conectado,
                               error=error, datos=datos or {"numero": "8", "nombre": "Conexión con MongoDB", "lenguaje": "Python", "dato": ""}), estado

    @app.get("/")
    def inicio():
        return pagina()

    @app.post("/guardar")
    def guardar():
        datos = {campo: request.form.get(campo, "").strip()
                 for campo in ("numero", "nombre", "lenguaje", "dato")}
        token = request.form.get("csrf", "")
        if not token or not secrets.compare_digest(token.encode(), session.get("csrf", "").encode()):
            return pagina(datos, "El formulario expiró. Vuelve a enviarlo desde esta página.", 400)
        try:
            numero, documento = validar(datos)
        except ValueError as error:
            return pagina(datos, str(error), 400)

        try:
            resultado = coleccion.update_one({"_id": numero}, {"$set": documento}, upsert=True)
        except ConnectionFailure:
            return pagina(datos, "Se interrumpió la comunicación con MongoDB. Consulta los registros antes de reintentar.", 503)
        except PyMongoError:
            return pagina(datos, "No se pudo completar el guardado. Revisa los permisos de MongoDB.", 503)

        if resultado.upserted_id is not None:
            mensaje = f"Práctica {numero} guardada correctamente."
        elif resultado.modified_count:
            mensaje = f"Práctica {numero} actualizada correctamente."
        else:
            mensaje = f"La práctica {numero} ya contiene esos datos."
        flash(mensaje)
        return redirect(url_for("inicio"), code=303)

    @app.errorhandler(413)
    def formulario_grande(error):
        return pagina(error="El formulario es demasiado grande.", estado=413)

    return app


if __name__ == "__main__":
    print("Abre http://localhost:5000 en tu navegador. Detén la página con Ctrl+C.")
    crear_app().run(host="127.0.0.1", port=5000, debug=False)
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-08-conexion-mongodb/README.md" <<'FIN_CODIGO_INTERFACES'
# Práctica 8: Python, MongoDB y una página local

## Estructura

| Componente | Ubicación o función |
| --- | --- |
| Python + Flask | `08_conexion_mongodb.py`: formulario, validación y rutas. |
| PyMongo | Conexión y operaciones con el servidor local. |
| MongoDB Server | `mongodb://127.0.0.1:27017/`, en WSL. |
| Base de datos | `fundamentos_ia`. |
| Colección | `practicas`. |
| Interfaz | `templates/index.html` y `static/estilos.css`. |
| Compass | Aplicación independiente para consultar el mismo servidor. |

## Ejecutar desde WSL

Desde `~/universidad/fundamentos-ia`:

```bash
.venv/bin/python -m pip install -r unidad-01-introduccion-ia/practicas/practica-08-conexion-mongodb/requirements.txt
bash unidad-01-introduccion-ia/practicas/practica-08-conexion-mongodb/ejecutar.sh
```

Abre http://localhost:5000 en Windows. Mantén la terminal abierta. Detén Flask con Ctrl+C.
El servidor web escucha en 127.0.0.1, con depuración desactivada.

En VS Code selecciona Python: Select Interpreter y el intérprete
`/home/einar/universidad/fundamentos-ia/.venv/bin/python`.
Si `launch.json` define `python`, debe utilizar ese mismo intérprete.

## Guardar y consultar

El formulario comienza con número `8`, nombre `Conexión con MongoDB` y lenguaje `Python`.
Escribe en «Dato que deseas guardar» un texto como «Estoy aprendiendo MongoDB».
Pulsa Guardar dato. MongoDB crea la base y la colección en la primera escritura
si aún no existen. El número se guarda como `_id`: volver a usarlo actualiza ese
documento, conservando campos adicionales. El texto se guarda en el campo `dato`.
Para crear otro documento, usa otro número. La tabla muestra también «Dato guardado».
Abrir la página no inserta datos. La tabla consulta hasta 100 documentos ordenados
por número; Actualizar vuelve a consultar. No hay operaciones de borrado.

Los datos se conservan en MongoDB al cerrar la página. Se validan el número positivo
y las longitudes de nombre (1–120), lenguaje (1–40) y dato (1–1000), también desde Python.
Las plantillas escapan HTML. El formulario usa un token de sesión y el cliente de
MongoDB se reutiliza y se cierra al terminar el proceso normalmente.

## Ver los datos en Compass

Conecta Compass al mismo servidor usando `mongodb://localhost:27017`.
En una configuración habitual de WSL, Windows puede acceder a servicios WSL por
localhost. Si Compass está en Windows y no conecta, confirma el reenvío de localhost
de WSL. Si conecta pero no aparecen los datos, comprueba que no esté accediendo a
otra instalación de MongoDB en Windows.

Selecciona `fundamentos_ia`, después `practicas` y actualiza la pestaña Documents.
Compass es un cliente visual: Python se conecta directamente a MongoDB Server.

## Problemas comunes

- `ModuleNotFoundError`: instala con `.venv/bin/python -m pip` y ejecuta con el mismo intérprete.
- MongoDB no disponible: verifica en WSL `mongosh --quiet --eval 'db.runCommand({ping: 1})'`.
- Puerto 5000 ocupado: detén la instancia anterior con Ctrl+C.
- El guardado perdió la conexión: consulta antes de reintentar; una pérdida de respuesta
  puede ocurrir después de que el servidor haya escrito el documento.

## Verificación de esta entrega

Se comprueban formulario, inserción/actualización, validación, escape HTML y errores
con el cliente de pruebas de Flask y una colección simulada. La conexión real al
servidor de tu laptop se comprueba al ejecutar esta entrega allí.

Documentación:
- https://flask.palletsprojects.com/en/stable/quickstart/
- https://www.mongodb.com/docs/languages/python/pymongo-driver/current/crud/update/
- https://learn.microsoft.com/en-us/windows/wsl/networking
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-08-conexion-mongodb/ejecutar.sh" <<'FIN_CODIGO_INTERFACES'
#!/usr/bin/env bash
set -euo pipefail
directorio="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
proyecto="$(cd -- "$directorio/../../.." && pwd)"
exec "$proyecto/.venv/bin/python" "$directorio/08_conexion_mongodb.py"
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-08-conexion-mongodb/requirements.txt" <<'FIN_CODIGO_INTERFACES'
Flask>=3.1,<4
pymongo>=4.6,<5
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-08-conexion-mongodb/static/estilos.css" <<'FIN_CODIGO_INTERFACES'
:root {
  font-family:system-ui,-apple-system,"Segoe UI",sans-serif;
  color:#17352e;
  background:#f4f7f4;
  font-synthesis:none;
  line-height:1.5;
}
textarea { resize: vertical; }
.dato-guardado { white-space: pre-wrap; min-width: 140px; }
* {
  box-sizing:border-box;
}
body {
  margin:0;
}
main {
  max-width:1160px;
  padding:28px 30px 20px;
  margin:auto;
}
header {
  display:flex;
  align-items:center;
  justify-content:space-between;
  border-bottom:1px solid #d9e2dc;
  padding-bottom:22px;
  gap:16px;
}
.marca {
  display:flex;
  align-items:center;
  gap:12px;
  font-size:12px;
  font-weight:750;
  letter-spacing:1.6px;
}
.icono {
  background:#174d3d;
  color:#fff;
  border-radius:10px;
  padding:9px;
  letter-spacing:0;
}
.etiqueta {
  font-size:11px;
  letter-spacing:1px;
  border:1px solid #c9d7ce;
  border-radius:30px;
  padding:7px 12px;
}
.introduccion {
  padding:36px 0 28px;
  position:relative;
}
.subtitulo {
  color:#517161;
  font-size:11px;
  font-weight:750;
  letter-spacing:1.8px;
  margin:0 0 8px;
}
h1 {
  font-size:44px;
  letter-spacing:-1.8px;
  margin:0 0 6px;
  line-height:1.2;
}
h2 {
  font-size:21px;
  letter-spacing:-.5px;
  margin:0 0 10px;
}
.introduccion>p:not(.subtitulo) {
  color:#576c60;
  margin:0;
}
.estado {
  display:inline-flex;
  gap:8px;
  align-items:center;
  border-radius:30px;
  padding:7px 13px;
  font-size:12px;
  font-weight:650;
  margin-top:18px;
}
.estado:before {
  content:"";
  width:7px;
  height:7px;
  border-radius:50%;
  background:currentColor;
}
.activo {
  background:#e1efdf;
  color:#245b34;
}
.inactivo {
  background:#f8e6df;
  color:#8b392c;
}
.paneles {
  display:grid;
  grid-template-columns:minmax(260px,.85fr) minmax(0,1.35fr);
  gap:24px;
  align-items:start;
}
.tarjeta {
  background:#fff;
  border:1px solid #dbe4dd;
  border-radius:17px;
  padding:28px;
  box-shadow:0 4px 15px #183a2510;
}
.ayuda {
  font-size:13px;
  color:#647568;
  margin:0 0 24px;
}
label {
  display:block;
  font-size:13px;
  font-weight:650;
  margin:18px 0 7px;
}
input, textarea {
  display:block;
  width:100%;
  font:inherit;
  font-size:14px;
  color:#18392d;
  border:1px solid #bdcdc1;
  border-radius:8px;
  background:#fbfcfa;
  padding:11px 12px;
}
input:focus-visible,textarea:focus-visible,button:focus-visible,a:focus-visible {
  outline:3px solid #8eae38;
  outline-offset:3px;
}
button {
  margin-top:25px;
  width:100%;
  border:0;
  background:#184f3d;
  color:#fff;
  border-radius:9px;
  padding:13px 16px;
  font:inherit;
  font-weight:650;
  cursor:pointer;
  display:flex;
  justify-content:space-between;
  align-items:center;
}
button:hover {
  background:#0d3d2d;
}
.cabecera-listado {
  display:flex;
  justify-content:space-between;
  align-items:center;
  gap:12px;
}
.actualizar {
  color:#245943;
  font-size:12px;
  font-weight:650;
  text-decoration:underline;
  text-underline-offset:4px;
}
.tabla-contenedor {
  overflow-x:auto;
}
table {
  width:100%;
  border-collapse:collapse;
  text-align:left;
  font-size:13px;
}
th {
  background:#f0f5ef;
  color:#506a57;
  font-size:11px;
  letter-spacing:.5px;
  padding:12px;
}
td {
  padding:16px 12px;
  border-bottom:1px solid #e7ede7;
  overflow-wrap:anywhere;
}
td:first-child {
  font-weight:750;
}
td:last-child {
  color:#58725e;
}
.vacio {
  border:1px dashed #b7cbbd;
  background:#f8faf6;
  border-radius:12px;
  text-align:center;
  padding:48px 22px;
  margin-top:8px;
}
.vacio strong {
  font-size:15px;
}
.vacio p {
  font-size:13px;
  color:#657467;
  margin:8px 0 0;
}
.aviso {
  padding:14px 18px;
  border-radius:10px;
  font-size:14px;
  margin:0 0 20px;
}
.exito {
  background:#e2efd9;
  border:1px solid #baceac;
  color:#31532a;
}
.error {
  background:#fbeae4;
  border:1px solid #e2b6a7;
  color:#852c1e;
}
footer {
  text-align:center;
  font-size:11px;
  color:#69806d;
  padding:28px 0 0;
}
.solo-lectores {
  position:absolute;
  width:1px;
  height:1px;
  overflow:hidden;
  clip-path:inset(50%);
}
@media(max-width:760px) {
  main {
    padding:20px 16px;
  }
  .paneles {
    grid-template-columns:1fr;
  }
  .tarjeta {
    padding:22px;
  }
  h1 {
    font-size:36px;
  }
  .introduccion {
    padding:28px 0;
  }
  .marca {
    font-size:10px;
    letter-spacing:.8px;
  }
  .etiqueta {
    font-size:9px;
  }
  .cabecera-listado {
    flex-wrap:wrap;
  }
}
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-08-conexion-mongodb/templates/index.html" <<'FIN_CODIGO_INTERFACES'
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Prácticas | Fundamentos de IA</title>
  <link rel="stylesheet" href="{{ url_for('static', filename='estilos.css') }}">
</head>
<body>
  <main>
    <header>
      <div class="marca"><span class="icono">IA</span> FUNDAMENTOS DE IA</div>
      <span class="etiqueta">PRÁCTICA 08</span>
    </header>
    <section class="introduccion">
      <p class="subtitulo">PYTHON + MONGODB</p>
      <h1>Mis prácticas</h1>
      <p>Escribe un dato, guárdalo en MongoDB y consulta el resultado.</p>
      <span class="estado {{ 'activo' if conectado else 'inactivo' }}">
        {{ 'MongoDB conectado' if conectado else 'MongoDB no disponible' }}
      </span>
    </section>
    {% for mensaje in get_flashed_messages() %}
      <div class="aviso exito" role="status">{{ mensaje }}</div>
    {% endfor %}
    {% if error %}<div class="aviso error" role="alert">{{ error }}</div>{% endif %}
    <div class="paneles">
      <section class="tarjeta">
        <p class="subtitulo">01 / REGISTRO</p>
        <h2>Guardar una práctica</h2>
        <p class="ayuda">Si usas un número existente, actualizarás esa práctica.</p>
        <form action="{{ url_for('guardar') }}" method="post">
          <input type="hidden" name="csrf" value="{{ session['csrf'] }}">
          <label for="numero">Número de práctica</label>
          <input id="numero" name="numero" inputmode="numeric" pattern="[0-9]+"
                 maxlength="19" required value="{{ datos.numero }}">
          <label for="nombre">Nombre</label>
          <input id="nombre" name="nombre" maxlength="120" required value="{{ datos.nombre }}">
          <label for="lenguaje">Lenguaje</label>
          <input id="lenguaje" name="lenguaje" maxlength="40" required value="{{ datos.lenguaje }}">
          <label for="dato">Dato que deseas guardar</label>
          <textarea id="dato" name="dato" rows="4" required aria-describedby="ayuda-dato"
                    placeholder="Estoy aprendiendo a guardar datos en MongoDB.">{{ datos.dato }}</textarea>
          <p id="ayuda-dato" class="ayuda">Escribe de 1 a 1000 caracteres.</p>
          <button type="submit">Guardar dato <span aria-hidden="true">→</span></button>
        </form>
      </section>
      <section class="tarjeta listado">
        <div class="cabecera-listado">
          <div><p class="subtitulo">02 / CONSULTA</p><h2>Prácticas guardadas</h2></div>
          <a class="actualizar" href="{{ url_for('inicio') }}">Actualizar</a>
        </div>
        <p class="ayuda">Hasta 100 registros, ordenados por número.</p>
        {% if registros %}
          <div class="tabla-contenedor">
            <table>
              <caption class="solo-lectores">Prácticas guardadas en MongoDB</caption>
              <thead><tr><th scope="col">N.º</th><th scope="col">Nombre</th><th scope="col">Lenguaje</th><th scope="col">Dato guardado</th></tr></thead>
              <tbody>{% for registro in registros %}
                <tr><td>{{ registro['_id'] }}</td><td>{{ registro.get('nombre', 'Sin nombre') }}</td><td>{{ registro.get('lenguaje', 'Sin especificar') }}</td><td class="dato-guardado">{{ registro.get('dato', 'Sin dato registrado') }}</td></tr>
              {% endfor %}</tbody>
            </table>
          </div>
        {% elif conectado %}
          <div class="vacio"><strong>Tu primer registro empieza aquí</strong><p>Completa el formulario y pulsa «Guardar dato».</p></div>
        {% else %}
          <div class="vacio"><strong>No se pudieron cargar los registros</strong><p>Cuando el servidor esté disponible, pulsa «Actualizar».</p></div>
        {% endif %}
      </section>
    </div>
    <footer>Práctica 08 · Conexión, registro y consulta</footer>
  </main>
</body>
</html>
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-09-conexion-mongodb-atlas/.env.example" <<'FIN_CODIGO_INTERFACES'
Mongo_User='hector1985'
Mongo_Password=''
Mongo_Closter='utvt.qqqotrr.mongodb.net'
Mongo_DB='Einar_Ivan_Lazcano_Luna'
Mongo_Collection='datos'
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-09-conexion-mongodb-atlas/.gitignore" <<'FIN_CODIGO_INTERFACES'
.env
.env.*
.env-*
!.env.example
__pycache__/
*.pyc
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-09-conexion-mongodb-atlas/09_conexion_mongodb_atlas.py" <<'FIN_CODIGO_INTERFACES'
"""Práctica 9: interfaz web local y conexión privada con MongoDB Atlas."""

import atexit
import secrets
from datetime import datetime, timezone
from pathlib import Path

from flask import Flask, jsonify, render_template, request, session
from pymongo import MongoClient
from pymongo.errors import ConfigurationError, ConnectionFailure, OperationFailure, PyMongoError

from configuracion import cargar_configuracion

DIRECTORIO = Path(__file__).resolve().parent
FILTRO = {"_id": "practica_09"}
PROYECCION = {"nombre": 1, "practica": 1, "dato": 1, "actualizado_en": 1}


def mensaje_error(error):
    """Traducir errores conocidos sin publicar la URI ni mensajes del driver."""
    if isinstance(error, OperationFailure):
        if error.code == 18:
            return "Atlas rechazó las credenciales. Revisa el usuario y la contraseña en tu .env."
        if error.code == 13:
            return "Faltan permisos. Pide al profesor acceso de lectura y escritura a tu base."
        return "Atlas rechazó la operación. Revisa los permisos con el profesor."
    if isinstance(error, ConfigurationError):
        return "No se pudo configurar Atlas. Revisa el dominio del clúster y la resolución DNS."
    if isinstance(error, ConnectionFailure):
        return "No hay comunicación con Atlas. Comprueba Internet y que tu IP esté autorizada."
    return "No se pudo completar la operación en MongoDB Atlas."


def serializar(documento):
    if documento is None:
        return None
    fecha = documento.get("actualizado_en")
    if isinstance(fecha, datetime):
        if fecha.tzinfo is None:
            fecha = fecha.replace(tzinfo=timezone.utc)
        fecha = fecha.isoformat()
    else:
        fecha = None
    return {"id": str(documento["_id"]),
            "nombre": str(documento.get("nombre", "")),
            "practica": 9, "dato": str(documento.get("dato", "")),
            "actualizado_en": fecha}


def crear_app(coleccion=None):
    """Permitir una colección simulada para probar sin acceder al clúster."""
    app = Flask(__name__, template_folder=str(DIRECTORIO / "templates"),
                static_folder=str(DIRECTORIO / "static"))
    app.config.update(SECRET_KEY=secrets.token_hex(32), MAX_CONTENT_LENGTH=16384,
                      SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Strict")
    error_configuracion = None
    mongo_db, mongo_collection = "", ""
    cliente = None
    if coleccion is None:
        try:
            # El enlace se construye en Python y nunca se envía al navegador.
            mongo_url, mongo_db, mongo_collection = cargar_configuracion()
        except ValueError as error:
            error_configuracion = str(error)  # Mensaje controlado de configuracion.py.
        else:
            try:
                cliente = MongoClient(mongo_url, serverSelectionTimeoutMS=10000,
                                      connectTimeoutMS=10000, socketTimeoutMS=10000,
                                      maxPoolSize=5, tz_aware=True)
                coleccion = cliente[mongo_db][mongo_collection]
                atexit.register(cliente.close)
            except (PyMongoError, ValueError) as error:
                error_configuracion = mensaje_error(error)
                if cliente is not None:
                    cliente.close()
    else:
        mongo_db, mongo_collection = "Einar_Ivan_Lazcano_Luna", "datos"

    def error_json(mensaje, estado=503, **extras):
        return jsonify(ok=False, mensaje=mensaje, **extras), estado

    @app.after_request
    def cabeceras(respuesta):
        respuesta.headers["Cache-Control"] = "no-store"
        respuesta.headers["X-Content-Type-Options"] = "nosniff"
        respuesta.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self'; "
            "img-src 'self' data:; connect-src 'self'; base-uri 'none'; "
            "form-action 'self'; frame-ancestors 'none'"
        )
        return respuesta

    @app.get("/")
    def inicio():
        session.setdefault("csrf", secrets.token_hex(32))
        return render_template("index.html", base=mongo_db, coleccion=mongo_collection)

    @app.get("/api/documento")
    def consultar():
        if error_configuracion:
            return error_json(error_configuracion)
        try:
            documento = coleccion.find_one(FILTRO, PROYECCION)
            return jsonify(ok=True, documento=serializar(documento))
        except PyMongoError as error:
            return error_json(mensaje_error(error))

    @app.post("/api/documento")
    def guardar():
        token = request.form.get("csrf", "")
        esperado = session.get("csrf", "")
        if not token or not secrets.compare_digest(token.encode(), esperado.encode()):
            return error_json("El formulario expiró. Recarga la página e inténtalo de nuevo.", 400)
        dato = request.form.get("dato", "").strip()
        if not 1 <= len(dato) <= 1000:
            return error_json("Escribe un dato de entre 1 y 1000 caracteres.", 400)
        if error_configuracion:
            return error_json(error_configuracion)
        documento = {"nombre": "Einar Ivan Lazcano Luna", "practica": 9,
                     "dato": dato, "actualizado_en": datetime.now(timezone.utc)}
        try:
            resultado = coleccion.update_one(FILTRO, {"$set": documento}, upsert=True)
        except PyMongoError as error:
            return error_json(mensaje_error(error) + " Consulta el documento antes de reintentar el guardado.")

        # Diferenciar una escritura confirmada de una consulta posterior fallida.
        mensaje = ("Tu dato se guardó en Atlas." if resultado.upserted_id is not None
                   else "Tu dato se actualizó en Atlas.")
        try:
            guardado = coleccion.find_one(FILTRO, PROYECCION)
        except PyMongoError:
            return error_json("El guardado se confirmó, pero no se pudo consultar el resultado. Pulsa Actualizar.", guardado=True)
        if guardado is None:
            return error_json("El guardado se confirmó, pero el documento ya no aparece. Pulsa Actualizar.", guardado=True)
        return jsonify(ok=True, mensaje=mensaje, documento=serializar(guardado))

    @app.errorhandler(413)
    def contenido_grande(error):
        return error_json("El formulario es demasiado grande. Escribe hasta 1000 caracteres.", 413)

    return app


if __name__ == "__main__":
    print("Abre http://localhost:5001 en tu navegador. Detén la página con Ctrl+C.")
    crear_app().run(host="127.0.0.1", port=5001, debug=False)
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-09-conexion-mongodb-atlas/README.md" <<'FIN_CODIGO_INTERFACES'
# Práctica 9: HTML, CSS, JavaScript, Python y MongoDB Atlas

Programa independiente de la práctica 8. Aquí la conexión es al clúster del profesor.

## Archivos

| Archivo | Función |
| --- | --- |
| `.env` | Usuario, contraseña, dominio, base y colección. Se crea únicamente en tu laptop. |
| `.env.example` | Ejemplo de configuración sin contraseña. |
| `configuracion.py` | Lee el .env y construye `mongo_url`. |
| `09_conexion_mongodb_atlas.py` | Servidor Flask, conexión y API para guardar y consultar. |
| `templates/index.html` | Estructura de la página y formulario. |
| `static/estilos.css` | Diseño adaptable a escritorio y móvil. |
| `static/app.js` | Guardado y consulta con fetch sin recargar, contador y estados. |
| `preparar_env.py` | Solicita la contraseña oculta y crea .env con permisos 600. |
| `requirements.txt` | Flask, PyMongo y python-dotenv. |
| `ejecutar.sh` | Ejecuta con el Python de .venv del proyecto. |

## Variables

```dotenv
Mongo_User='hector1985'
Mongo_Password=''
Mongo_Closter='utvt.qqqotrr.mongodb.net'
Mongo_DB='Einar_Ivan_Lazcano_Luna'
Mongo_Collection='datos'
```

La contraseña real se solicita en la terminal mediante `preparar_env.py`.
Se conserva `Mongo_Closter` como nombre de variable indicado en el enunciado.
MongoDB no permite espacios en los nombres de bases: por eso se usan guiones bajos.
El documento mantiene el nombre completo con espacios.
La colección es un contenedor llamado `datos`; el dato es el contenido del documento.

## Ejecutar en WSL

Desde `~/universidad/fundamentos-ia`:

```bash
.venv/bin/python -m pip install -r unidad-01-introduccion-ia/practicas/practica-09-conexion-mongodb-atlas/requirements.txt
.venv/bin/python unidad-01-introduccion-ia/practicas/practica-09-conexion-mongodb-atlas/preparar_env.py
bash unidad-01-introduccion-ia/practicas/practica-09-conexion-mongodb-atlas/ejecutar.sh
```

Abre http://localhost:5001 en el navegador. El puerto 5001 permite conservar
la práctica 8 en el puerto 5000. Mantén la terminal abierta y detén el servidor
con Ctrl+C. El servidor escucha en 127.0.0.1 con el depurador desactivado.

Escribe el dato en el formulario y pulsa Guardar en Atlas. El servidor escribe
solamente en la base y colección indicadas en .env. El documento conserva
`_id: practica_09`: cada guardado actualiza ese documento, sin duplicarlo.
El dato debe tener entre 1 y 1000 caracteres después de quitar espacios de los
extremos. La validación se realiza también en Python. No elimina documentos.
La base y colección se crean en la primera escritura. Abrir la página solamente
consulta. El botón Actualizar vuelve a leer el documento sin modificar el texto
que estés escribiendo. Ver documento JSON muestra los campos del documento.

Si la conexión se pierde después de confirmar la escritura, la página diferencia
ese caso de un guardado no confirmado. Pulsa Actualizar antes de reintentar.
Tras un error, la última consulta visible se identifica como posiblemente antigua.
No se configura ninguna escritura automática ni reintento de la interfaz.

## Arquitectura y credenciales

El navegador envía el formulario a Flask mediante fetch. Python construye
`mongo_url` y usa PyMongo para comunicarse con Atlas. La respuesta es JSON con el
documento; JavaScript lo muestra mediante textContent. La contraseña, el usuario
de acceso y la URI completa no se incluyen en HTML, JavaScript ni respuestas JSON.
Los nombres de base y colección sí se muestran como información de la práctica.
`.env` no se publica como archivo estático. El formulario incorpora un token CSRF.

## Construcción del enlace

El enlace se construye en memoria con este formato, nunca se imprime completo:

```text
mongodb+srv://<usuario>:<contraseña-codificada>@<clúster>/<base>?retryWrites=true&w=majority&authSource=admin&appName=Practica09
```

`quote_plus` codifica los caracteres especiales del usuario y la contraseña.
La conexión SRV activa TLS; la verificación de certificados permanece habilitada.
La colección se selecciona con `cliente[mongo_db][mongo_collection]`, por lo que
no se añade como segmento adicional a la URI.

El archivo .env se lee por su ruta junto a configuracion.py, independientemente
del directorio desde el que ejecutes el programa. No se interpretan expresiones
`${...}` dentro de la contraseña. Los mensajes del driver no se imprimen con la URI.

## Acceso a Atlas

El profesor debe autorizar tu IP pública en Network Access y conceder al usuario
permisos de lectura y escritura sobre `Einar_Ivan_Lazcano_Luna`. Si no cuentas con
permisos administrativos, solicita al profesor esos cambios. El script no modifica
usuarios, permisos, listas de IP ni otras bases del clúster.

Para comprobarlo visualmente, el profesor puede consultar esa base en Atlas.
También puedes usar Compass con el host de Atlas y sus campos de autenticación.
Si guardaste en Atlas, los datos no aparecerán en la conexión local de la práctica 8.

## Git

`.env` queda excluido mediante .gitignore; `.env.example` sí puede subirse.
Desde el proyecto, comprueba la regla con:

```bash
git check-ignore unidad-01-introduccion-ia/practicas/practica-09-conexion-mongodb-atlas/.env
```

No compartas el .env ni una URL completa que contenga la contraseña.

## Validación de la entrega

Se verifican la lectura del .env, codificación de credenciales con valores ficticios,
validación de nombres y el flujo de guardado con una conexión simulada. No se prueba
la contraseña ni se escribe en el clúster del profesor desde el entorno de preparación.
Se prueban además los endpoints web con una colección simulada y la sintaxis de
JavaScript. El navegador del entorno de preparación bloquea las direcciones locales,
por lo que no se ha confirmado visualmente el diseño en ese navegador.
La ejecución en tu laptop confirma los permisos y la creación real de la base.

## Referencias

- https://www.mongodb.com/docs/manual/reference/limits/
- https://www.mongodb.com/docs/atlas/security/add-ip-address-to-list/
- https://www.mongodb.com/docs/languages/python/pymongo-driver/current/databases-collections/
- https://bbc2.github.io/python-dotenv/
- https://flask.palletsprojects.com/en/stable/patterns/javascript/
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-09-conexion-mongodb-atlas/configuracion.py" <<'FIN_CODIGO_INTERFACES'
"""Leer .env y construir la variable mongo_url sin mostrar credenciales."""

import re
from pathlib import Path
from urllib.parse import quote_plus

from dotenv import dotenv_values

ARCHIVO_ENV = Path(__file__).resolve().parent / ".env"


def cargar_configuracion(archivo=ARCHIVO_ENV):
    if not Path(archivo).is_file():
        raise ValueError("Falta el archivo .env. Ejecuta preparar_env.py primero.")
    # La configuración procede de este .env. No se expanden expresiones ${...}.
    valores = dotenv_values(archivo, interpolate=False)
    nombres = ("Mongo_User", "Mongo_Password", "Mongo_Closter", "Mongo_DB", "Mongo_Collection")
    if any(not isinstance(valores.get(nombre), str) or not valores[nombre] for nombre in nombres):
        raise ValueError("Completa las cinco variables de MongoDB en el archivo .env.")

    usuario = valores["Mongo_User"].strip()
    contrasena = valores["Mongo_Password"]
    cluster = valores["Mongo_Closter"].strip()
    base = valores["Mongo_DB"].strip()
    coleccion = valores["Mongo_Collection"].strip()
    if not usuario:
        raise ValueError("Mongo_User no puede estar vacío.")
    if not re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?\.mongodb\.net", cluster):
        raise ValueError("Mongo_Closter debe ser el dominio de Atlas, sin protocolo ni barras.")
    if not base or len(base.encode("utf-8")) >= 64 or any(c in base for c in '\\/. "$\x00'):
        raise ValueError("Mongo_DB debe tener menos de 64 bytes y no contener espacios, barras, puntos, comillas ni $.")
    if (not coleccion or "$" in coleccion or "\x00" in coleccion
            or coleccion.startswith("system.") or ".system." in coleccion
            or len(f"{base}.{coleccion}".encode("utf-8")) > 235):
        raise ValueError("Mongo_Collection contiene un nombre no permitido o demasiado largo.")

    mongo_url = (
        f"mongodb+srv://{quote_plus(usuario)}:{quote_plus(contrasena)}@{cluster}/"
        f"{quote_plus(base)}?retryWrites=true&w=majority&authSource=admin&appName=Practica09"
    )
    return mongo_url, base, coleccion
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-09-conexion-mongodb-atlas/ejecutar.sh" <<'FIN_CODIGO_INTERFACES'
#!/usr/bin/env bash
set -euo pipefail
directorio="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
proyecto="$(cd -- "$directorio/../../.." && pwd)"
exec "$proyecto/.venv/bin/python" "$directorio/09_conexion_mongodb_atlas.py"
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-09-conexion-mongodb-atlas/preparar_env.py" <<'FIN_CODIGO_INTERFACES'
"""Crear .env localmente, solicitando la contraseña de forma oculta."""

import os
import tempfile
import warnings
from getpass import GetPassWarning, getpass
from pathlib import Path

from dotenv import set_key

from configuracion import ARCHIVO_ENV, cargar_configuracion


def main():
    if ARCHIVO_ENV.exists():
        try:
            cargar_configuracion()
        except ValueError as error:
            print(error)
            print("Corrige tu .env en VS Code y vuelve a ejecutar este programa.")
            return 1
        print("El archivo .env ya existe y se conservó.")
        return 0

    try:
        print("Introduce la contraseña entregada por el profesor; no se mostrará al escribir.")
        with warnings.catch_warnings():
            warnings.simplefilter("error", GetPassWarning)
            contrasena = getpass("Mongo_Password: ")
        if not contrasena:
            print("La contraseña no puede estar vacía.")
            return 1
        valores = {
            "Mongo_User": "hector1985",
            "Mongo_Password": contrasena,
            "Mongo_Closter": "utvt.qqqotrr.mongodb.net",
            "Mongo_DB": "Einar_Ivan_Lazcano_Luna",
            "Mongo_Collection": "datos",
        }
        descriptor, nombre = tempfile.mkstemp(prefix=".env-", dir=ARCHIVO_ENV.parent)
        temporal = Path(nombre)
        os.close(descriptor)
        try:
            for clave, valor in valores.items():
                set_key(temporal, clave, valor, quote_mode="always")
            cargar_configuracion(temporal)
            os.chmod(temporal, 0o600)
            # La creación exclusiva evita sobrescribir una configuración existente.
            os.link(temporal, ARCHIVO_ENV)
        finally:
            temporal.unlink(missing_ok=True)
    except GetPassWarning:
        print("Ejecuta este programa en la terminal WSL para introducir la contraseña de forma oculta.")
        return 1
    except (OSError, ValueError):
        print("No se pudo crear .env. Revisa la carpeta y sus permisos.")
        return 1
    except (KeyboardInterrupt, EOFError):
        print("\nConfiguración cancelada.")
        return 130
    print("Archivo .env creado. La contraseña y el enlace completo no se muestran en pantalla.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-09-conexion-mongodb-atlas/requirements.txt" <<'FIN_CODIGO_INTERFACES'
pymongo>=4.6,<5
python-dotenv>=1,<2
Flask>=3.1,<4
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-09-conexion-mongodb-atlas/static/app.js" <<'FIN_CODIGO_INTERFACES'
"use strict";

const formulario = document.querySelector("#formulario");
const entrada = document.querySelector("#dato");
const guardar = document.querySelector("#guardar");
const actualizar = document.querySelector("#actualizar");
const aviso = document.querySelector("#aviso");
const conexion = document.querySelector("#conexion");
const estadoConsulta = document.querySelector("#consulta-estado");
let ocupado = false;
let ultimoDocumento = null;

function mostrarAviso(texto, tipo = "error") {
  aviso.textContent = texto;
  aviso.className = `aviso ${tipo}`;
  aviso.hidden = false;
}

function cambiarEstado(texto, clase) {
  conexion.textContent = texto;
  conexion.className = `estado ${clase}`;
}

function marcarOcupado(valor) {
  ocupado = valor;
  guardar.disabled = valor;
  actualizar.disabled = valor;
  formulario.setAttribute("aria-busy", String(valor));
}

function mostrarDocumento(documento) {
  ultimoDocumento = documento;
  document.querySelector("#documento").hidden = !documento;
  document.querySelector("#vacio").hidden = Boolean(documento);
  estadoConsulta.hidden = true;
  if (!documento) return;
  document.querySelector("#dato-guardado").textContent = documento.dato;
  document.querySelector("#autor").textContent = documento.nombre;
  const fecha = document.querySelector("#fecha");
  const instante = documento.actualizado_en ? new Date(documento.actualizado_en) : null;
  fecha.textContent = instante && !Number.isNaN(instante.getTime())
    ? new Intl.DateTimeFormat("es-MX", { dateStyle: "medium", timeStyle: "short" }).format(instante)
    : "Sin fecha registrada";
  if (instante && !Number.isNaN(instante.getTime())) fecha.dateTime = instante.toISOString();
  else fecha.removeAttribute("datetime");
  document.querySelector("#json").textContent = JSON.stringify({
    _id: documento.id, nombre: documento.nombre, practica: documento.practica,
    dato: documento.dato, actualizado_en: documento.actualizado_en,
  }, null, 2);
}

async function solicitar(url, opciones = {}) {
  const respuesta = await fetch(url, { credentials: "same-origin", cache: "no-store", ...opciones });
  const datos = await respuesta.json();
  if (!respuesta.ok || !datos.ok) {
    const error = new Error(datos.mensaje || "No se pudo completar la operación.");
    error.estado = respuesta.status;
    error.guardado = Boolean(datos.guardado);
    throw error;
  }
  return datos;
}

function fallo(error, esGuardado = false) {
  const mensaje = error.estado ? error.message
    : "No se pudo contactar con Python. Comprueba que la terminal del servidor siga abierta."
      + (esGuardado ? " Pulsa Actualizar antes de volver a guardar." : "");
  mostrarAviso(mensaje, error.guardado ? "atencion" : "error");
  if (error.estado === 400 || error.estado === 413) return;
  cambiarEstado("Conexión por comprobar", "desconectado");
  estadoConsulta.textContent = ultimoDocumento
    ? "Se muestra la última consulta correcta; puede haber cambios pendientes de consultar."
    : "No se pudo consultar el documento. Pulsa Actualizar para reintentar.";
  estadoConsulta.hidden = false;
  document.querySelector("#vacio").hidden = true;
}

async function consultar() {
  if (ocupado) return;
  marcarOcupado(true);
  aviso.hidden = true;
  cambiarEstado("Comprobando conexión…", "esperando");
  try {
    const datos = await solicitar(document.querySelector(".consulta").dataset.url);
    mostrarDocumento(datos.documento);
    cambiarEstado("Atlas conectado", "conectado");
  } catch (error) {
    fallo(error);
  } finally {
    marcarOcupado(false);
  }
}

entrada.addEventListener("input", () => {
  const cantidad = [...entrada.value].length;
  entrada.setCustomValidity(cantidad > 1000 ? "Escribe hasta 1000 caracteres." : "");
  document.querySelector("#contador").textContent = `${cantidad} / 1000`;
});

formulario.addEventListener("submit", async (evento) => {
  evento.preventDefault();
  if (ocupado) return;
  if (!entrada.value.trim()) {
    entrada.setCustomValidity("Escribe un dato; no puede contener solamente espacios.");
    entrada.reportValidity();
    return;
  }
  marcarOcupado(true);
  aviso.hidden = true;
  guardar.textContent = "Guardando…";
  try {
    const datos = await solicitar(formulario.action, { method: "POST", body: new FormData(formulario) });
    mostrarDocumento(datos.documento);
    cambiarEstado("Atlas conectado", "conectado");
    mostrarAviso(datos.mensaje, "exito");
  } catch (error) {
    fallo(error, true);
  } finally {
    guardar.textContent = "Guardar en Atlas ↗";
    marcarOcupado(false);
  }
});

actualizar.addEventListener("click", consultar);
consultar();
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-09-conexion-mongodb-atlas/static/estilos.css" <<'FIN_CODIGO_INTERFACES'
:root {
  font-family: "Segoe UI", system-ui, sans-serif;
  color: #243047;
  background: #f6f7fb;
  line-height: 1.5;
  font-synthesis: none;
  --acento: #5c46d9;
}
* { box-sizing: border-box; }
body { margin: 0; }
[hidden] { display: none !important; }
button, textarea { font: inherit; }
a { color: inherit; }
.aplicacion { display: flex; min-height: 100vh; }
.lateral { width: 250px; flex-shrink: 0; background: #fff; border-right: 1px solid #e4e7ef; padding: 32px 22px 24px; display: flex; flex-direction: column; }
.marca { display: flex; align-items: center; gap: 12px; text-decoration: none; font-weight: 750; font-size: 27px; letter-spacing: -1px; }
.marca-icono { width: 42px; height: 42px; background: #5c46d9; color: #fff; display: grid; place-items: center; border-radius: 12px; font-size: 32px; line-height: 1; padding-bottom: 7px; }
.marca-subtitulo { display: block; font-size: 8px; letter-spacing: 1.3px; color: #7b8394; font-weight: 650; }
.lateral-contenido { margin-top: 56px; }
.etiqueta { font-size: 10px; font-weight: 750; letter-spacing: 1.6px; color: #81899c; margin: 0 0 15px; }
.seleccion { display: flex; align-items: center; gap: 10px; margin: 0 -7px; padding: 14px 11px; border-radius: 10px; background: #f0edff; color: #5342b6; font-size: 13px; font-weight: 650; }
.numero { border: 1px solid #d1c8fb; border-radius: 6px; font-size: 11px; padding: 5px; }
small { display: block; font-size: 11px; font-weight: 400; color: #8a839d; margin-top: 2px; }
.lateral-contenido .destino { margin-top: 36px; border-top: 1px solid #edf0f5; padding-top: 26px; }
.destino p { font-size: 11px; color: #7c8598; margin: 16px 0; }
.destino strong { font-size: 12px; font-weight: 500; color: #4a556d; display: block; margin-top: 5px; overflow-wrap: anywhere; }
.perfil { display: flex; align-items: center; gap: 10px; margin-top: auto; padding-top: 32px; font-size: 12px; font-weight: 650; }
.avatar { background: #f2ede4; color: #796845; border-radius: 50%; width: 36px; height: 36px; display: grid; place-items: center; font-size: 11px; }
main { flex: 1; min-width: 0; padding: 27px 48px; max-width: 1320px; margin: 0 auto; }
.barra-superior { display: flex; align-items: center; justify-content: space-between; gap: 14px; font-size: 11px; color: #8590a2; padding-bottom: 23px; border-bottom: 1px solid #e3e7ef; }
.barra-superior strong { font-weight: 550; color: #56617b; }
.separador { margin: 0 13px; color: #b4bdca; }
.local { background: #eeedf7; color: #7c728f; border-radius: 20px; padding: 5px 9px; font-size: 9px; letter-spacing: .9px; }
.encabezado { padding: 36px 0 29px; }
.encabezado .etiqueta { color: #8173c1; margin-bottom: 10px; }
h1 { font-size: clamp(30px, 3.4vw, 46px); letter-spacing: -1.8px; font-weight: 700; line-height: 1.18; margin: 0 0 10px; }
h1 span { color: var(--acento); }
.encabezado > p:not(.etiqueta) { color: #7b8599; font-size: 14px; margin: 0; }
.estado { display: inline-flex; align-items: center; gap: 7px; margin-top: 21px; border: 1px solid #dedfe8; border-radius: 20px; padding: 5px 10px; font-size: 10px; font-weight: 600; }
.estado::before { content: ""; width: 6px; height: 6px; border-radius: 50%; background: currentColor; }
.conectado { color: #257957; background: #edf7f1; border-color: #cee6d7; }
.esperando { color: #77628d; background: #f2eef8; }
.desconectado { color: #995029; background: #fff3e8; border-color: #ecd8c2; }
.columnas { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); gap: 24px; align-items: start; }
.tarjeta { padding: 27px; background: #fff; border: 1px solid #e3e6ef; border-radius: 15px; box-shadow: 0 5px 16px #26336505; }
.titulo-tarjeta { display: flex; align-items: flex-start; gap: 10px; margin-bottom: 28px; }
.paso { color: #7765c6; background: #f1eeff; border-radius: 7px; padding: 6px 7px; font-size: 11px; font-weight: 650; }
h2 { font-size: 17px; font-weight: 650; letter-spacing: -.4px; margin: 0; }
.titulo-tarjeta p { font-size: 11px; color: #8890a3; margin: 5px 0 0; }
label { display: block; font-size: 12px; font-weight: 600; margin-bottom: 10px; }
textarea { width: 100%; padding: 14px; background: #fcfcfe; border: 1px solid #dce0ec; border-radius: 9px; color: #35425b; font-size: 13px; line-height: 1.8; min-height: 185px; resize: vertical; }
textarea::placeholder { color: #a4abc0; }
textarea:focus-visible, button:focus-visible, a:focus-visible, summary:focus-visible { outline: 3px solid #a899f7; outline-offset: 3px; }
.bajo-campo { display: flex; justify-content: space-between; margin-top: 6px; font-size: 10px; color: #8e95a7; gap: 12px; }
.boton-principal { display: flex; justify-content: space-between; align-items: center; width: 100%; margin-top: 23px; padding: 13px 15px; color: #fff; background: var(--acento); font-size: 12px; font-weight: 650; border: 0; border-radius: 8px; cursor: pointer; }
.boton-principal:hover { background: #4d37c6; }
button:disabled { opacity: .6; cursor: wait; }
.nota { color: #8e96a6; font-size: 10px; margin: 12px 0 0; text-align: center; }
.consulta .titulo-tarjeta { gap: 8px; }
.consulta .titulo-tarjeta > div { flex: 1; }
.boton-secundario { border: 1px solid #e3e2f0; background: #fff; color: #6d5bb6; border-radius: 6px; padding: 6px 8px; font-size: 10px; cursor: pointer; }
.boton-secundario:hover { background: #f5f2ff; }
.consulta-estado { font-size: 12px; color: #8a7597; background: #f6f3fa; border-radius: 7px; padding: 12px; }
.vacio { min-height: 272px; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; padding: 25px; background: #fcfcfe; border: 1px dashed #dcddea; border-radius: 10px; }
.vacio-icono { width: 45px; height: 45px; display: grid; place-items: center; background: #eee9ff; color: #8e7ecd; border-radius: 12px; font-size: 25px; margin-bottom: 12px; }
h3 { font-size: 14px; font-weight: 600; margin: 8px 0; }
.vacio p { font-size: 11px; color: #989caf; max-width: 220px; margin: 0; }
.documento-cabecera { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
.insignia { background: #f1effb; color: #7c6cb2; border-radius: 5px; padding: 5px 8px; font-size: 9px; font-weight: 650; letter-spacing: .6px; }
.confirmado { color: #43856a; font-size: 10px; }
.dato-guardado { white-space: pre-wrap; overflow-wrap: anywhere; font-size: 16px; color: #3c4761; line-height: 1.75; margin: 24px 0; }
.metadatos { border-top: 1px solid #eceef5; padding-top: 18px; display: grid; gap: 14px; margin-bottom: 22px; }
dt { font-size: 10px; color: #949cad; }
dd { font-size: 12px; margin: 4px 0 0; color: #5c6680; }
details { border-top: 1px solid #eceef5; padding-top: 15px; }
summary { cursor: pointer; font-size: 11px; color: #7e6abf; }
pre { white-space: pre-wrap; overflow-wrap: anywhere; font-size: 11px; line-height: 1.6; color: #54617c; background: #f6f7fc; padding: 14px; border-radius: 7px; max-height: 300px; overflow: auto; }
.aviso { margin: 0 0 20px; padding: 13px 16px; font-size: 12px; border-radius: 9px; }
.exito { color: #27654d; background: #e9f5ee; border: 1px solid #cce5d6; }
.error { color: #963c34; background: #fff0eb; border: 1px solid #f0d1c7; }
.atencion { color: #856124; background: #fff7e5; border: 1px solid #eddfb8; }
footer { display: flex; align-items: center; gap: 7px; margin-top: 27px; color: #9da4b6; font-size: 10px; }
.pie-punto { background: #8a9ac1; width: 4px; height: 4px; border-radius: 50%; }
.pie-derecho { margin-left: auto; }
@media (max-width: 1150px) {
  .lateral { width: 215px; padding: 28px 18px; }
  main { padding: 25px 26px; }
  .columnas { gap: 18px; }
  .tarjeta { padding: 22px; }
  .consulta .titulo-tarjeta { flex-wrap: wrap; }
}
@media (max-width: 930px) {
  .columnas { grid-template-columns: 1fr; }
  .consulta .titulo-tarjeta { flex-wrap: nowrap; }
}
@media (max-width: 620px) {
  .aplicacion { display: block; }
  .lateral { width: 100%; padding: 17px 20px; border-right: 0; border-bottom: 1px solid #e4e7ef; flex-direction: row; align-items: center; justify-content: space-between; }
  .lateral-contenido { display: none; }
  .perfil { padding: 0; margin: 0; }
  .perfil > div { display: none; }
  .marca { font-size: 23px; }
  .marca-subtitulo { font-size: 7px; }
  .marca-icono { width: 35px; height: 35px; }
  main { padding: 20px 18px; }
  .encabezado > p:not(.etiqueta) { font-size: 12px; }
  .tarjeta { padding: 21px; }
  .barra-superior { font-size: 10px; }
  .local { font-size: 8px; }
  .pie-derecho { display: none; }
}
FIN_CODIGO_INTERFACES
cat > "$preparada/practica-09-conexion-mongodb-atlas/templates/index.html" <<'FIN_CODIGO_INTERFACES'
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Mi espacio en Atlas · Práctica 09</title>
  <link rel="stylesheet" href="{{ url_for('static', filename='estilos.css') }}">
  <script src="{{ url_for('static', filename='app.js') }}" defer></script>
</head>
<body>
  <div class="aplicacion">
    <aside class="lateral">
      <a class="marca" href="{{ url_for('inicio') }}"><span class="marca-icono" aria-hidden="true">a.</span><span>atlas<span class="marca-subtitulo">CUADERNO DE PRÁCTICAS</span></span></a>
      <div class="lateral-contenido">
        <p class="etiqueta">FUNDAMENTOS DE IA</p>
        <div class="seleccion"><span class="numero">09</span><div>Mi espacio en Atlas<small>Conexión con la nube</small></div></div>
        <div class="destino">
          <span class="etiqueta">DESTINO DE TUS DATOS</span>
          <p>Base de datos<strong>{{ base or 'Pendiente de configurar' }}</strong></p>
          <p>Colección<strong>{{ coleccion or 'Pendiente de configurar' }}</strong></p>
        </div>
      </div>
      <div class="perfil"><span class="avatar">EL</span><div>Einar Lazcano<small>Estudiante</small></div></div>
    </aside>
    <main>
      <div class="barra-superior"><span>Mis prácticas <span class="separador">/</span> <strong>Práctica 09</strong></span><span class="local">ENTORNO LOCAL</span></div>
      <section class="encabezado">
        <p class="etiqueta">TU PRIMER DATO EN LA NUBE</p>
        <h1>Mi espacio en Atlas<span>.</span></h1>
        <p>Escribe, guarda y consulta. Tus datos, conectados desde Python.</p>
        <span id="conexion" class="estado esperando" role="status">Comprobando conexión…</span>
      </section>
      <div id="aviso" class="aviso" role="status" aria-live="polite" tabindex="-1" hidden></div>
      <noscript><p class="aviso error">Activa JavaScript para guardar y consultar desde esta página.</p></noscript>
      <div class="columnas">
        <section class="tarjeta editor" aria-labelledby="titulo-editor">
          <div class="titulo-tarjeta"><span class="paso">01</span><div><h2 id="titulo-editor">Escribe tu dato</h2><p>Una idea, un aprendizaje o una nota.</p></div></div>
          <form id="formulario" action="{{ url_for('guardar') }}" method="post">
            <input type="hidden" name="csrf" value="{{ session['csrf'] }}">
            <label for="dato">¿Qué quieres guardar?</label>
            <textarea id="dato" name="dato" rows="7" required aria-describedby="contador pista" placeholder="Hoy aprendí a conectar Python con MongoDB Atlas…"></textarea>
            <div class="bajo-campo"><span>Máximo 1000 caracteres</span><span id="contador">0 / 1000</span></div>
            <button id="guardar" class="boton-principal" type="submit">Guardar en Atlas <span aria-hidden="true">↗</span></button>
            <p id="pista" class="nota">Cada guardado actualiza el documento de esta práctica.</p>
          </form>
        </section>
        <section class="tarjeta consulta" aria-labelledby="titulo-consulta" data-url="{{ url_for('consultar') }}">
          <div class="titulo-tarjeta"><span class="paso">02</span><div><h2 id="titulo-consulta">Tu dato guardado</h2><p>Consultado directamente desde Atlas.</p></div><button id="actualizar" class="boton-secundario" type="button" aria-label="Actualizar documento">Actualizar</button></div>
          <p id="consulta-estado" class="consulta-estado">Consultando tu documento…</p>
          <div id="vacio" class="vacio" hidden><div class="vacio-icono" aria-hidden="true">↗</div><h3>Aquí empieza tu colección</h3><p>Guarda tu primer dato y aparecerá en este espacio.</p></div>
          <article id="documento" hidden>
            <div class="documento-cabecera"><span class="insignia">PRÁCTICA 09</span><span class="confirmado">Guardado</span></div>
            <p id="dato-guardado" class="dato-guardado"></p>
            <dl class="metadatos"><div><dt>Autor</dt><dd id="autor"></dd></div><div><dt>Última actualización</dt><dd><time id="fecha"></time></dd></div></dl>
            <details><summary>Ver documento JSON</summary><pre id="json"></pre></details>
          </article>
        </section>
      </div>
      <footer><span class="pie-punto" aria-hidden="true"></span> Python · MongoDB Atlas <span class="pie-derecho">Aprender haciendo.</span></footer>
    </main>
  </div>
</body>
</html>
FIN_CODIGO_INTERFACES

if [[ ! -x "$proyecto/.venv/bin/python" ]]; then
  python3 -m venv "$proyecto/.venv"
fi
"$proyecto/.venv/bin/python" -m pip install 'Flask>=3.1,<4' 'pymongo>=4.6,<5' 'python-dotenv>=1,<2'
"$proyecto/.venv/bin/python" - "$proyecto" "$preparada" <<'FIN_INSTALACION_PYTHON'
import ast
import os
from pathlib import Path
import shutil
import sys
import tempfile

import flask
import pymongo
import dotenv

proyecto = Path(sys.argv[1])
preparada = Path(sys.argv[2])
practicas = proyecto / 'unidad-01-introduccion-ia' / 'practicas'
nombres = sorted(p.name for p in preparada.iterdir())

# Verificar todos los destinos antes de cambiar el primero.
for nombre in nombres:
    destino = practicas / nombre
    if destino.is_symlink() or (destino.exists() and not destino.is_dir()):
        raise SystemExit(f'El destino debe ser una carpeta normal: {destino}')
    for archivo in (preparada / nombre).glob('*.py'):
        ast.parse(archivo.read_text(encoding='utf-8'))
    (preparada / nombre / 'ejecutar.sh').chmod(0o755)

atlas = 'practica-09-conexion-mongodb-atlas'
configuracion = practicas / atlas / '.env'
if configuracion.is_symlink() or (configuracion.exists() and not configuracion.is_file()):
    raise SystemExit('El archivo .env de Atlas debe ser un archivo normal.')
if configuracion.is_file():
    copia = preparada / atlas / '.env'
    shutil.copyfile(configuracion, copia)
    copia.chmod(0o600)

carpeta_respaldos = proyecto.parent / f'{proyecto.name}-respaldos'
carpeta_respaldos.mkdir(exist_ok=True)
respaldo = Path(tempfile.mkdtemp(prefix='interfaces-', dir=carpeta_respaldos))
anteriores = []
instaladas = []
try:
    for nombre in nombres:
        destino = practicas / nombre
        if destino.exists():
            os.replace(destino, respaldo / nombre)
            anteriores.append(nombre)
        os.replace(preparada / nombre, destino)
        instaladas.append(nombre)
except BaseException:
    print(f'La instalación se interrumpió. Respaldo: {respaldo}', file=sys.stderr)
    for nombre in reversed(instaladas):
        os.replace(practicas / nombre, preparada / nombre)
    for nombre in reversed(anteriores):
        os.replace(respaldo / nombre, practicas / nombre)
    raise

print(f'Interfaces instaladas. Versiones anteriores: {respaldo}')
print('Cada práctica es independiente. Para iniciarla, usa su archivo ejecutar.sh.')
for numero, nombre in enumerate(nombres, start=1):
    puerto = 5100 + numero if numero <= 7 else 5000 if numero == 8 else 5001
    print(f'{numero}. http://localhost:{puerto}')
    print(f'   bash unidad-01-introduccion-ia/practicas/{nombre}/ejecutar.sh')
if not (practicas / atlas / '.env').is_file():
    print('Antes de utilizar Atlas, configura la contraseña en tu terminal:')
    print(f'.venv/bin/python unidad-01-introduccion-ia/practicas/{atlas}/preparar_env.py')
print('Mantén abierta la terminal de cada servidor; Ctrl+C lo detiene.')
FIN_INSTALACION_PYTHON
