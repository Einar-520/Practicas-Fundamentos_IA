# Interfaces de Fundamentos de IA

Las prácticas 1 a 7 usan Python con Flask, HTML, CSS y JavaScript. Cada carpeta
contiene un programa independiente. Las reglas y prioridades de los programas
optimizados se conservan. Los formularios validan sus entradas en Python y
presentan los resultados en español.

| Práctica | Contenido | Dirección |
| --- | --- | --- |
| 1 | Tabla de verdad: cuatro combinaciones y todos los operadores | http://localhost:5101 |
| 2 | Evaluación para presentar examen | http://localhost:5102 |
| 3 | Examen con lista oficial obligatoria | http://localhost:5103 |
| 4 | Diagnóstico del equipo y daño físico | http://localhost:5104 |
| 5 | Diagnóstico completo con reporte TXT descargable | http://localhost:5105 |
| 6 | Sistema experto de salud con tres síntomas | http://localhost:5106 |
| 7 | Sistema experto mejorado con siete síntomas | http://localhost:5107 |
| 8 | Guardar y consultar un dato en MongoDB local | http://localhost:5000 |
| 9 | Guardar y consultar un dato en MongoDB Atlas | http://localhost:5001 |

## Instalar en WSL

Coloca instalar_interfaces_practicas.sh dentro de ~/universidad/fundamentos-ia.
En la terminal WSL de VS Code ejecuta:

```bash
cd ~/universidad/fundamentos-ia
bash instalar_interfaces_practicas.sh
```

El instalador actualiza las nueve carpetas indicadas, crea primero un respaldo
de las versiones anteriores en ~/universidad/fundamentos-ia-respaldos y conserva
el .env existente de la práctica 9. No cambia otras carpetas de prácticas ni
realiza operaciones de Git. Instala las dependencias en la .venv del proyecto.
Requiere Python 3 con venv, pip y acceso a Internet para instalar dependencias.

Para otra ubicación: bash instalar_interfaces_practicas.sh /ruta/al/proyecto.

## Abrir una práctica

Ejemplo para la práctica 1, desde la raíz del proyecto:

```bash
bash unidad-01-introduccion-ia/practicas/practica-01-tablas-de-verdad/ejecutar.sh
```

Abre su dirección en el navegador y mantén abierta la terminal. Detén el servidor
con Ctrl+C. Para otra práctica, ejecuta el archivo ejecutar.sh de su carpeta.
Puedes mantener varias abiertas usando terminales separadas y sus distintos puertos.
En VS Code selecciona el intérprete ~/universidad/fundamentos-ia/.venv/bin/python.

## Guardado en las prácticas 8 y 9

La práctica 8 necesita MongoDB Server local en 127.0.0.1:27017. Compass permite
consultar la base fundamentos_ia y su colección practicas. Completa el formulario,
incluido el campo Dato, y pulsa Guardar dato. Reutilizar el número actualiza ese
documento. La tabla muestra el dato consultado desde MongoDB.

La práctica 9 usa la base Einar_Ivan_Lazcano_Luna y la colección datos del clúster
del profesor. La contraseña se configura localmente, y no viene en esta entrega:

```bash
.venv/bin/python unidad-01-introduccion-ia/practicas/practica-09-conexion-mongodb-atlas/preparar_env.py
bash unidad-01-introduccion-ia/practicas/practica-09-conexion-mongodb-atlas/ejecutar.sh
```

Lee el README de esa carpeta para la configuración y los permisos de Atlas.
El navegador no recibe credenciales. El botón Guardar en Atlas actualiza un
documento de la práctica; no elimina documentos ni modifica otras bases.

## Verificación

Se compararon 16 804 combinaciones y límites de las prácticas 1 a 7 con sus
programas originales. Se verificaron validación, formularios y respuestas de
Flask. El JavaScript se prueba en un DOM simulado. El guardado de 8 y 9 se
comprueba con colecciones simuladas, sin escribir en el MongoDB de tu laptop ni
en Atlas. La conexión real debe comprobarse al ejecutarlas en tu equipo.
No se pudo realizar una revisión visual en el navegador de este entorno.
