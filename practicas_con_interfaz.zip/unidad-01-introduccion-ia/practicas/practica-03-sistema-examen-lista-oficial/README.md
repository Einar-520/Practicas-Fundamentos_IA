# Práctica 3: Examen con lista oficial

La lista oficial es obligatoria, incluso cuando existe autorización especial.

Desde la raíz del proyecto:

```bash
bash unidad-01-introduccion-ia/practicas/practica-03-sistema-examen-lista-oficial/ejecutar.sh
```

Abre http://localhost:5103. Detén el servidor con Ctrl+C.

Programa independiente: todo el código, HTML, CSS y JavaScript está en esta carpeta.
Las funciones de las reglas se conservan del programa optimizado. Los campos
se validan en Python. Los resultados no se guardan en una base de datos.

Flask devuelve JSON; JavaScript muestra texto sin interpretarlo como HTML.
La práctica 5 permite descargar su reporte en TXT.
