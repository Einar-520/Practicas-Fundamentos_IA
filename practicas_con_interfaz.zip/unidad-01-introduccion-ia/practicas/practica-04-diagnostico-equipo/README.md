# Práctica 4: Diagnóstico de equipo

Evalúa electricidad, encendido, imagen y presencia de daños físicos.

Desde la raíz del proyecto:

```bash
bash unidad-01-introduccion-ia/practicas/practica-04-diagnostico-equipo/ejecutar.sh
```

Abre http://localhost:5104. Detén el servidor con Ctrl+C.

Programa independiente: todo el código, HTML, CSS y JavaScript está en esta carpeta.
Las funciones de las reglas se conservan del programa optimizado. Los campos
se validan en Python. Los resultados no se guardan en una base de datos.

Flask devuelve JSON; JavaScript muestra texto sin interpretarlo como HTML.
La práctica 5 permite descargar su reporte en TXT.
